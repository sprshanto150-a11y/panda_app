# PANDA APP - Android Native Project & APK Guide

This Android native project was generated using `@capacitor/android` for **PANDA APP (Earn • Share • Grow)**.

- **Package ID**: `com.pandaapp.earnsharegrow`
- **Application Name**: `PANDA APP`
- **Web Root**: `dist/`
- **Native Platform**: Android (Java/Kotlin + Chromium WebView)

---

## 🚀 How to Build your Android APK

### Option 1: Automatic Single-Command Sync
From the project root directory, run:
```bash
npm run build:apk
```
This builds the latest frontend bundle (`dist`) and syncs all assets and plugins to `android/`.

---

### Option 2: Build Debug APK via Command Line (Terminal)
If you have the Android SDK & Java JDK installed on your machine:
```bash
cd android
./gradlew assembleDebug
```
Your compiled APK file will be located at:
```
android/app/build/outputs/apk/debug/app-debug.apk
```
You can transfer this `.apk` file directly to any Android smartphone to install and test!

---

### Option 3: Open in Android Studio
To inspect the code, test on emulators, or build a signed release bundle (`.aab` / `.apk`) for the Google Play Store:
```bash
npx cap open android
```
In Android Studio:
1. Go to **Build** > **Generate Signed Bundle / APK...**
2. Choose **APK** (for direct distribution) or **Android App Bundle** (for Google Play Console)
3. Select or create your Keystore credentials
4. Select `release` build variant and click **Finish**

---

## 🔒 Testnet & Payment Safety Policy
- All demo balances and simulated transactions are clearly tagged with `isSandboxDemo: true`.
- Real money deposits and withdrawals remain locked until official merchant credentials and server verification are configured in `/server/db.ts`.
