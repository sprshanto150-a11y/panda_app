package com.pandaapp.earnsharegrow;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
