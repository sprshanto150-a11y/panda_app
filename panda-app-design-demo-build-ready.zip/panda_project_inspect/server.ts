import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  getDb,
  saveDb,
  hashPassword,
  checkLinkSafety,
  UserRecord,
  TransactionRecord,
  TaskRecord,
  PostRecord,
  PromotionPackage,
  PromotionPostRecord,
} from './server/db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isProduction = process.env.NODE_ENV === 'production';
const PORT = parseInt(process.env.PORT || '3000', 10);

async function createServer() {
  const app = express();

  app.use(cors());
  app.use(express.json());

  // Static assets folder
  app.use('/assets', express.static(path.join(__dirname, 'public/assets')));

  // --- API ROUTES ---

  // Health check & System settings
  app.get('/api/health', (_req, res) => {
    const db = getDb();
    res.json({
      status: 'ok',
      version: '1.0.0',
      isSandboxDemoMode: db.settings.isSandboxDemoMode,
      maintenanceMode: db.settings.maintenanceMode,
    });
  });

  app.get('/api/settings', (_req, res) => {
    const db = getDb();
    res.json({
      isSandboxDemoMode: db.settings.isSandboxDemoMode,
      sandboxNotice: db.settings.sandboxNotice,
      nagadAgentNumber: db.settings.nagadAgentNumber,
      binancePayId: db.settings.binancePayId,
      minDepositBDT: db.settings.minDepositBDT,
      maxDepositBDT: db.settings.maxDepositBDT,
      minDepositUSD: db.settings.minDepositUSD,
      minWithdrawBDT: db.settings.minWithdrawBDT,
      maxWithdrawBDT: db.settings.maxWithdrawBDT,
      minWithdrawUSD: db.settings.minWithdrawUSD,
    });
  });

  // --- AUTHENTICATION ---
  app.post('/api/auth/register', (req, res) => {
    const { name, phone, email, password, referralCode } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email and password are required' });
    }

    const db = getDb();
    const existing = db.users.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() || (phone && u.phone === phone)
    );
    if (existing) {
      return res.status(400).json({ error: 'User with this email or phone already exists' });
    }

    const newId = 'PANDA' + Math.floor(1000 + Math.random() * 9000);
    const generatedRef = newId;

    const newUser: UserRecord = {
      id: newId,
      name: name.trim(),
      username: name.toLowerCase().replace(/\s+/g, '_') + Math.floor(10 + Math.random() * 90),
      email: email.trim().toLowerCase(),
      phone: phone ? phone.trim() : '01700000000',
      passwordHash: hashPassword(password),
      avatar: '/assets/app/user_rahim.png',
      bdtBalance: 0.0,
      usdBalance: 0.0,
      referralCode: generatedRef,
      referredBy: referralCode ? referralCode.trim() : undefined,
      role: 'user',
      isBanned: false,
      followers: 0,
      following: 0,
      postsCount: 0,
      createdAt: new Date().toISOString(),
    };

    // If referred by someone, credit test referral reward
    if (newUser.referredBy) {
      const referrer = db.users.find((u) => u.referralCode === newUser.referredBy);
      if (referrer) {
        referrer.bdtBalance += 50.0;
        referrer.followers += 1;
        db.transactions.unshift({
          id: 'TXN-' + Math.floor(1000 + Math.random() * 9000),
          userId: referrer.id,
          userName: referrer.name,
          type: 'referral',
          title: 'Referral Bonus',
          method: 'System',
          amount: 50,
          currency: 'BDT',
          status: 'Completed',
          timestamp: 'Just now',
          createdAt: new Date().toISOString(),
          reference: `Bonus for inviting ${newUser.name}`,
          isSandboxDemo: true,
        });
      }
    }

    db.users.push(newUser);
    saveDb(db);

    const { passwordHash: _, ...safeUser } = newUser;
    res.json({ success: true, user: safeUser, token: 'demo_token_' + newUser.id });
  });

  app.post('/api/auth/login', (req, res) => {
    const { emailOrUsername, password } = req.body;
    if (!emailOrUsername || !password) {
      return res.status(400).json({ error: 'Email/Username and password are required' });
    }

    const db = getDb();
    const query = emailOrUsername.trim().toLowerCase();

    // Special admin shortcut
    if ((query === 'admin' || query === 'admin@panda.app') && password === 'admin123') {
      const adminUser = db.users.find((u) => u.role === 'admin') || db.users[1];
      const { passwordHash: _, ...safeAdmin } = adminUser;
      return res.json({ success: true, user: safeAdmin, token: 'demo_token_admin' });
    }

    const user = db.users.find(
      (u) =>
        u.email.toLowerCase() === query ||
        u.username.toLowerCase() === query ||
        u.id.toLowerCase() === query
    );

    if (!user) {
      return res.status(401).json({ error: 'Invalid username/email or password' });
    }

    if (user.passwordHash !== hashPassword(password)) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    if (user.isBanned) {
      return res.status(403).json({ error: 'This account has been suspended by administration.' });
    }

    const { passwordHash: _, ...safeUser } = user;
    res.json({ success: true, user: safeUser, token: 'demo_token_' + user.id });
  });

  app.post('/api/auth/google', (req, res) => {
    const db = getDb();
    // Default to Rahim demo user
    const user = db.users.find((u) => u.id === 'PANDA1025') || db.users[0];
    const { passwordHash: _, ...safeUser } = user;
    res.json({ success: true, user: safeUser, token: 'demo_token_google' });
  });

  app.get('/api/auth/me', (req, res) => {
    const userId = (req.headers['x-user-id'] as string) || (req.query.userId as string) || 'PANDA1025';
    const db = getDb();
    const user = db.users.find((u) => u.id === userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    const { passwordHash: _, ...safeUser } = user;
    res.json(safeUser);
  });

  app.put('/api/user/profile', (req, res) => {
    const userId = (req.headers['x-user-id'] as string) || (req.body.userId as string) || 'PANDA1025';
    const { name, phone, email } = req.body;
    const db = getDb();
    const user = db.users.find((u) => u.id === userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (name) user.name = name.trim();
    if (phone) user.phone = phone.trim();
    if (email) user.email = email.trim();

    saveDb(db);
    const { passwordHash: _, ...safeUser } = user;
    res.json({ success: true, user: safeUser });
  });

  // --- WALLET & TRANSACTIONS ---
  app.get('/api/wallet/transactions', (req, res) => {
    const userId = (req.query.userId as string) || 'PANDA1025';
    const db = getDb();
    const userTransactions = db.transactions.filter(
      (t) => t.userId === userId || t.userId === 'PANDA1025'
    );
    res.json(userTransactions);
  });

  app.post('/api/wallet/deposit', (req, res) => {
    const { userId = 'PANDA1025', amount, method, accountNumber, trxId } = req.body;
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt <= 0) {
      return res.status(400).json({ error: 'Invalid deposit amount' });
    }

    const isBDT = method === 'Nagad';
    const db = getDb();
    const user = db.users.find((u) => u.id === userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    // Validate limits
    if (isBDT && (amt < db.settings.minDepositBDT || amt > db.settings.maxDepositBDT)) {
      return res.status(400).json({
        error: `Deposit must be between ৳${db.settings.minDepositBDT} and ৳${db.settings.maxDepositBDT}`,
      });
    }
    if (!isBDT && amt < db.settings.minDepositUSD) {
      return res.status(400).json({
        error: `Deposit must be at least $${db.settings.minDepositUSD}`,
      });
    }

    const generatedTrx = trxId || (isBDT ? 'NGD' : 'BIN') + Math.floor(100000 + Math.random() * 900000);

    const newTxn: TransactionRecord = {
      id: 'TXN-' + Math.floor(1000 + Math.random() * 9000),
      userId: user.id,
      userName: user.name,
      type: 'deposit',
      title: isBDT ? 'Deposit (Nagad)' : 'Deposit (Binance)',
      method: isBDT ? 'Nagad' : 'Binance',
      amount: amt,
      currency: isBDT ? 'BDT' : 'USD',
      status: 'Pending',
      timestamp: 'Just now',
      createdAt: new Date().toISOString(),
      accountNumber: accountNumber || user.phone,
      trxId: generatedTrx,
      isSandboxDemo: true,
      adminNote: 'Testnet Sandbox transaction. Pending administrator verification.',
    };

    db.transactions.unshift(newTxn);
    saveDb(db);

    res.json({
      success: true,
      transaction: newTxn,
      message: 'Deposit request created. Marked as sandbox testnet demo.',
    });
  });

  app.post('/api/wallet/withdraw', (req, res) => {
    const { userId = 'PANDA1025', amount, method, destinationAccount } = req.body;
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt <= 0) {
      return res.status(400).json({ error: 'Invalid withdrawal amount' });
    }

    const isBDT = method === 'Nagad';
    const db = getDb();
    const user = db.users.find((u) => u.id === userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    // Limits & Balance checks
    if (isBDT) {
      if (amt < db.settings.minWithdrawBDT || amt > db.settings.maxWithdrawBDT) {
        return res.status(400).json({
          error: `Nagad withdrawal must be between ৳${db.settings.minWithdrawBDT} and ৳${db.settings.maxWithdrawBDT}`,
        });
      }
      if (user.bdtBalance < amt) {
        return res.status(400).json({ error: 'Insufficient BDT balance' });
      }
      user.bdtBalance -= amt;
    } else {
      if (amt < db.settings.minWithdrawUSD) {
        return res.status(400).json({
          error: `Binance withdrawal must be at least $${db.settings.minWithdrawUSD}`,
        });
      }
      if (user.usdBalance < amt) {
        return res.status(400).json({ error: 'Insufficient USD balance' });
      }
      user.usdBalance -= amt;
    }

    const newTxn: TransactionRecord = {
      id: 'TXN-' + Math.floor(1000 + Math.random() * 9000),
      userId: user.id,
      userName: user.name,
      type: 'withdraw',
      title: isBDT ? 'Withdraw to Nagad' : 'Withdraw to Binance',
      method: isBDT ? 'Nagad' : 'Binance',
      amount: amt,
      currency: isBDT ? 'BDT' : 'USD',
      status: 'Approved',
      timestamp: 'Just now',
      createdAt: new Date().toISOString(),
      accountNumber: destinationAccount,
      trxId: (isBDT ? 'NGD-WD-' : 'BIN-WD-') + Math.floor(100000 + Math.random() * 900000),
      isSandboxDemo: true,
      adminNote: 'Processed via Testnet Simulation Engine.',
    };

    db.transactions.unshift(newTxn);
    saveDb(db);

    res.json({
      success: true,
      transaction: newTxn,
      updatedBalance: isBDT ? user.bdtBalance : user.usdBalance,
      message: `Withdrawal of ${isBDT ? '৳' + amt : '$' + amt} processed successfully in sandbox mode.`,
    });
  });

  // --- EXPANDABLE EARNING TASKS ---
  app.get('/api/tasks', (req, res) => {
    const userId = (req.query.userId as string) || 'PANDA1025';
    const db = getDb();
    const today = new Date().toISOString().slice(0, 10);

    const userCompletions = db.taskCompletions.filter(
      (c) => c.userId === userId && c.completedAt.slice(0, 10) === today
    );

    const tasksWithStatus = db.tasks.map((task) => {
      const isCompletedToday = userCompletions.some((c) => c.taskId === task.id);
      return {
        ...task,
        watched: isCompletedToday,
        completedToday: isCompletedToday,
      };
    });

    res.json(tasksWithStatus);
  });

  app.post('/api/tasks/complete', (req, res) => {
    const { userId = 'PANDA1025', taskId, customBonus } = req.body;
    const db = getDb();
    const user = db.users.find((u) => u.id === userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const task = db.tasks.find((t) => t.id === taskId);
    if (!task) return res.status(404).json({ error: 'Task not found' });

    const reward = customBonus ? parseFloat(customBonus) : task.rewardAmount;
    if (task.currency === 'BDT') {
      user.bdtBalance += reward;
    } else {
      user.usdBalance += reward;
    }

    db.taskCompletions.push({
      id: 'TC-' + Date.now(),
      userId: user.id,
      taskId: task.id,
      rewardClaimed: reward,
      currency: task.currency,
      completedAt: new Date().toISOString(),
    });

    db.transactions.unshift({
      id: 'TXN-' + Math.floor(1000 + Math.random() * 9000),
      userId: user.id,
      userName: user.name,
      type: 'task_reward',
      title: `Earned: ${task.title}`,
      method: 'Task',
      amount: reward,
      currency: task.currency,
      status: 'Completed',
      timestamp: 'Just now',
      createdAt: new Date().toISOString(),
      isSandboxDemo: true,
    });

    saveDb(db);

    res.json({
      success: true,
      reward,
      currency: task.currency,
      newBdtBalance: user.bdtBalance,
      newUsdBalance: user.usdBalance,
    });
  });

  // --- REFERRAL SYSTEM ---
  app.get('/api/referrals', (req, res) => {
    const userId = (req.query.userId as string) || 'PANDA1025';
    const db = getDb();
    const user = db.users.find((u) => u.id === userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    // Find direct referrals (Level 1)
    const level1 = db.users.filter((u) => u.referredBy === user.referralCode);
    const level1Ids = new Set(level1.map((u) => u.referralCode));

    // Level 2 referrals
    const level2 = db.users.filter((u) => u.referredBy && level1Ids.has(u.referredBy));

    res.json({
      referralCode: user.referralCode,
      referralLink: `https://panda.app/join?ref=${user.referralCode}`,
      stats: {
        totalInvites: level1.length + level2.length,
        level1Count: level1.length,
        level2Count: level2.length,
        totalCommissionBDT: level1.length * 50 + level2.length * 20,
      },
      team: level1.map((m) => ({
        id: m.id,
        name: m.name,
        date: m.createdAt.slice(0, 10),
        earned: '৳50',
        status: 'Active',
      })),
    });
  });

  // --- COMMUNITY POSTS ---
  app.get('/api/posts', (_req, res) => {
    const db = getDb();
    res.json(db.posts);
  });

  app.post('/api/posts', (req, res) => {
    const { userId = 'PANDA1025', content, tag, proofAmount } = req.body;
    if (!content || !content.trim()) {
      return res.status(400).json({ error: 'Post content cannot be empty' });
    }

    const db = getDb();
    const user = db.users.find((u) => u.id === userId) || db.users[0];

    const newPost: PostRecord = {
      id: 'post-' + Date.now(),
      authorId: user.id,
      authorName: user.name,
      authorAvatar: user.avatar,
      content: content.trim(),
      timeAgo: 'Just now',
      likes: 1,
      likedBy: [user.id],
      tag: tag || 'Member Update',
      proofAmount,
      createdAt: new Date().toISOString(),
    };

    user.postsCount += 1;
    db.posts.unshift(newPost);
    saveDb(db);

    res.json({ success: true, post: newPost });
  });

  app.post('/api/posts/:id/like', (req, res) => {
    const { id } = req.params;
    const { userId = 'PANDA1025' } = req.body;
    const db = getDb();
    const post = db.posts.find((p) => p.id === id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    const likedIndex = post.likedBy.indexOf(userId);
    if (likedIndex > -1) {
      post.likedBy.splice(likedIndex, 1);
      post.likes = Math.max(0, post.likes - 1);
    } else {
      post.likedBy.push(userId);
      post.likes += 1;
    }

    saveDb(db);
    res.json({ success: true, likes: post.likes, isLiked: likedIndex === -1 });
  });

  // --- ADMIN DASHBOARD & CONTROLS ---
  app.get('/api/admin/overview', (_req, res) => {
    const db = getDb();
    const totalUsers = db.users.length;
    const totalBDTLiability = db.users.reduce((sum, u) => sum + u.bdtBalance, 0);
    const totalUSDLiability = db.users.reduce((sum, u) => sum + u.usdBalance, 0);
    const pendingDeposits = db.transactions.filter(
      (t) => t.type === 'deposit' && t.status === 'Pending'
    ).length;
    const pendingWithdrawals = db.transactions.filter(
      (t) => t.type === 'withdraw' && t.status === 'Pending'
    ).length;

    res.json({
      totalUsers,
      totalBDTLiability,
      totalUSDLiability,
      pendingDeposits,
      pendingWithdrawals,
      totalTransactions: db.transactions.length,
      settings: db.settings,
    });
  });

  app.get('/api/admin/users', (_req, res) => {
    const db = getDb();
    const safeUsers = db.users.map(({ passwordHash: _, ...u }) => u);
    res.json(safeUsers);
  });

  app.post('/api/admin/users/:id/adjust-balance', (req, res) => {
    const { id } = req.params;
    const { bdtDelta = 0, usdDelta = 0, note = 'Admin balance adjustment' } = req.body;
    const db = getDb();
    const user = db.users.find((u) => u.id === id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    user.bdtBalance = Math.max(0, user.bdtBalance + parseFloat(bdtDelta));
    user.usdBalance = Math.max(0, user.usdBalance + parseFloat(usdDelta));

    db.transactions.unshift({
      id: 'TXN-' + Math.floor(1000 + Math.random() * 9000),
      userId: user.id,
      userName: user.name,
      type: 'task_reward',
      title: 'Admin Balance Adjustment',
      method: 'System',
      amount: Math.abs(parseFloat(bdtDelta)) || Math.abs(parseFloat(usdDelta)),
      currency: parseFloat(bdtDelta) !== 0 ? 'BDT' : 'USD',
      status: 'Completed',
      timestamp: 'Just now',
      createdAt: new Date().toISOString(),
      adminNote: note,
      isSandboxDemo: true,
    });

    saveDb(db);
    const { passwordHash: _, ...safeUser } = user;
    res.json({ success: true, user: safeUser });
  });

  app.post('/api/admin/users/:id/toggle-ban', (req, res) => {
    const { id } = req.params;
    const db = getDb();
    const user = db.users.find((u) => u.id === id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    user.isBanned = !user.isBanned;
    saveDb(db);
    res.json({ success: true, isBanned: user.isBanned });
  });

  app.get('/api/admin/transactions', (_req, res) => {
    const db = getDb();
    res.json(db.transactions);
  });

  app.post('/api/admin/transactions/:id/approve', (req, res) => {
    const { id } = req.params;
    const db = getDb();
    const txn = db.transactions.find((t) => t.id === id);
    if (!txn) return res.status(404).json({ error: 'Transaction not found' });

    if (txn.status === 'Approved' || txn.status === 'Completed') {
      return res.status(400).json({ error: 'Transaction is already approved' });
    }

    txn.status = 'Completed';
    txn.adminNote = 'Approved by administrator in sandbox mode';

    // If it was a pending deposit, credit user balance
    if (txn.type === 'deposit') {
      const user = db.users.find((u) => u.id === txn.userId);
      if (user) {
        if (txn.currency === 'BDT') {
          user.bdtBalance += txn.amount;
        } else {
          user.usdBalance += txn.amount;
        }
      }
    }

    saveDb(db);
    res.json({ success: true, transaction: txn });
  });

  app.post('/api/admin/transactions/:id/reject', (req, res) => {
    const { id } = req.params;
    const { reason = 'Invalid transaction details' } = req.body;
    const db = getDb();
    const txn = db.transactions.find((t) => t.id === id);
    if (!txn) return res.status(404).json({ error: 'Transaction not found' });

    txn.status = 'Rejected';
    txn.adminNote = reason;

    // If it was a withdraw, refund the deducted balance
    if (txn.type === 'withdraw') {
      const user = db.users.find((u) => u.id === txn.userId);
      if (user) {
        if (txn.currency === 'BDT') {
          user.bdtBalance += txn.amount;
        } else {
          user.usdBalance += txn.amount;
        }
      }
    }

    saveDb(db);
    res.json({ success: true, transaction: txn });
  });

  // Task creation by Admin (Expandable Earning Methods!)
  app.post('/api/admin/tasks', (req, res) => {
    const { title, type, sponsor, rewardAmount, currency, category, durationSec, linkUrl } = req.body;
    if (!title || !rewardAmount) {
      return res.status(400).json({ error: 'Title and reward amount are required' });
    }

    const db = getDb();
    const newTask: TaskRecord = {
      id: 'TASK-' + Math.floor(100 + Math.random() * 900),
      title: title.trim(),
      type: type || 'video_ad',
      sponsor: sponsor || 'Partner Sponsor',
      rewardAmount: parseFloat(rewardAmount),
      currency: currency || 'BDT',
      category: category || 'Custom Earn',
      durationSec: durationSec ? parseInt(durationSec, 10) : 10,
      linkUrl: linkUrl || undefined,
      isActive: true,
    };

    db.tasks.push(newTask);
    saveDb(db);
    res.json({ success: true, task: newTask });
  });

  app.put('/api/admin/settings', (req, res) => {
    const db = getDb();
    db.settings = { ...db.settings, ...req.body };
    saveDb(db);
    res.json({ success: true, settings: db.settings });
  });

  // ==========================================
  // --- PANDA PROMOTION & BOOST ENDPOINTS ---
  // ==========================================

  // 1. Get active promotion packages
  app.get('/api/promotions/packages', (_req, res) => {
    const db = getDb();
    const activePackages = db.packages.filter((p) => p.isActive);
    res.json(activePackages);
  });

  // 2. Public post feed with pinned & sponsored sorting
  app.get('/api/promotions/feed', (_req, res) => {
    const db = getDb();
    const now = Date.now();

    // Map and update remaining days & completion status
    const feed = db.promotions
      .filter((p) => !p.isBlocked)
      .map((p) => {
        let daysRemaining = 0;
        let isExpired = false;

        if (p.promotionStatus === 'active' && p.promotionEndDate) {
          const endMs = new Date(p.promotionEndDate).getTime();
          const diffMs = endMs - now;
          if (diffMs > 0) {
            daysRemaining = Math.max(1, Math.ceil(diffMs / 86400000));
          } else {
            isExpired = true;
          }
        }

        const effectiveStatus = isExpired ? 'completed' : p.promotionStatus;
        const isCurrentlyPromoted = effectiveStatus === 'active';

        return {
          ...p,
          promotionStatus: effectiveStatus,
          isPromoted: isCurrentlyPromoted,
          daysRemaining: isCurrentlyPromoted ? daysRemaining : 0,
        };
      })
      .sort((a, b) => {
        // Pinned to top first
        if (a.isPinnedToTop && !b.isPinnedToTop) return -1;
        if (!a.isPinnedToTop && b.isPinnedToTop) return 1;

        // Active promoted posts next
        if (a.isPromoted && !b.isPromoted) return -1;
        if (!a.isPromoted && b.isPromoted) return 1;

        // Most recent next
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });

    res.json(feed);
  });

  // 3. Create a new public post with link (website, Facebook, YouTube, etc.)
  app.post('/api/promotions/posts', (req, res) => {
    const {
      userId = 'PANDA1025',
      content,
      linkType = 'website',
      linkUrl,
      linkTitle,
      mediaUrl,
    } = req.body;

    if (!content || !content.trim()) {
      return res.status(400).json({ error: 'Post description is required' });
    }
    if (!linkUrl || !linkUrl.trim()) {
      return res.status(400).json({ error: 'A valid website or social media link is required' });
    }

    // Anti-phishing & Spam protection scan
    const safetyCheck = checkLinkSafety(linkUrl, content);
    if (!safetyCheck.isSafe) {
      return res.status(400).json({
        error: `Security Alert: Link rejected by Panda Anti-Fraud engine. Reason: ${safetyCheck.reason}`,
      });
    }

    const db = getDb();
    const user = db.users.find((u) => u.id === userId) || db.users[0];

    const newPost: PromotionPostRecord = {
      id: 'PROM-' + Math.floor(1000 + Math.random() * 9000),
      userId: user.id,
      userName: user.name,
      userAvatar: user.avatar,
      content: content.trim(),
      mediaUrl: mediaUrl || undefined,
      linkType: linkType as any,
      linkUrl: linkUrl.trim(),
      linkTitle: linkTitle ? linkTitle.trim() : `${linkType.toUpperCase()} Link`,
      isPromoted: false,
      isPinnedToTop: false,
      promotionStatus: 'none',
      viewsCount: 1,
      clicksCount: 0,
      likesCount: 0,
      likedBy: [],
      reportsCount: 0,
      reports: [],
      isBlocked: false,
      createdAt: new Date().toISOString(),
    };

    user.postsCount += 1;
    db.promotions.unshift(newPost);
    saveDb(db);

    res.json({
      success: true,
      post: newPost,
      message: 'Post published successfully to Panda Promotion Public Feed!',
    });
  });

  // 4. Boost / Promote a post using a Package (Deducts from user wallet)
  app.post('/api/promotions/boost', (req, res) => {
    const { userId = 'PANDA1025', postId, packageId } = req.body;

    const db = getDb();
    const user = db.users.find((u) => u.id === userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const post = db.promotions.find((p) => p.id === postId);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    const pkg = db.packages.find((p) => p.id === packageId && p.isActive);
    if (!pkg) return res.status(404).json({ error: 'Selected promotion package is not available' });

    // Verify wallet balance
    if (user.bdtBalance < pkg.priceBDT) {
      return res.status(400).json({
        error: `Insufficient wallet balance. You need ৳${pkg.priceBDT} BDT. Current balance: ৳${user.bdtBalance.toFixed(2)}`,
      });
    }

    // Deduct package price from user's wallet
    user.bdtBalance -= pkg.priceBDT;

    const startDate = new Date();
    const endDate = new Date(startDate.getTime() + pkg.durationDays * 86400000);

    // Update post with promotion package details
    post.isPromoted = true;
    post.promotionPackageId = pkg.id;
    post.packageName = pkg.name;
    // Set to active upon successful payment deduction
    post.promotionStatus = 'active';
    post.promotionStartDate = startDate.toISOString();
    post.promotionEndDate = endDate.toISOString();
    post.promotionDurationDays = pkg.durationDays;
    post.totalCostBDT = pkg.priceBDT;
    post.totalCostUSD = pkg.priceUSD;

    // Record wallet transaction
    db.transactions.unshift({
      id: 'TXN-' + Math.floor(1000 + Math.random() * 9000),
      userId: user.id,
      userName: user.name,
      type: 'promotion_boost',
      title: `Panda Promotion: ${pkg.name}`,
      method: 'System',
      amount: pkg.priceBDT,
      currency: 'BDT',
      status: 'Completed',
      timestamp: 'Just now',
      createdAt: new Date().toISOString(),
      reference: `Boost for Post #${post.id} (${pkg.durationDays} Days for ৳${pkg.priceBDT})`,
      isSandboxDemo: true,
      adminNote: 'Deducted from wallet balance for promotion package',
    });

    saveDb(db);

    res.json({
      success: true,
      post,
      newBdtBalance: user.bdtBalance,
      message: `Post boosted successfully with ${pkg.name} for ${pkg.durationDays} days!`,
    });
  });

  // 5. Track link click analytics
  app.post('/api/promotions/posts/:id/click', (req, res) => {
    const { id } = req.params;
    const db = getDb();
    const post = db.promotions.find((p) => p.id === id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    post.clicksCount += 1;
    saveDb(db);
    res.json({ success: true, clicksCount: post.clicksCount });
  });

  // 6. Track view analytics
  app.post('/api/promotions/posts/:id/view', (req, res) => {
    const { id } = req.params;
    const db = getDb();
    const post = db.promotions.find((p) => p.id === id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    post.viewsCount += 1;
    saveDb(db);
    res.json({ success: true, viewsCount: post.viewsCount });
  });

  // 7. Like / Unlike promotion post
  app.post('/api/promotions/posts/:id/like', (req, res) => {
    const { id } = req.params;
    const { userId = 'PANDA1025' } = req.body;
    const db = getDb();
    const post = db.promotions.find((p) => p.id === id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    if (!post.likedBy) post.likedBy = [];

    const index = post.likedBy.indexOf(userId);
    if (index > -1) {
      post.likedBy.splice(index, 1);
      post.likesCount = Math.max(0, post.likesCount - 1);
    } else {
      post.likedBy.push(userId);
      post.likesCount += 1;
    }

    saveDb(db);
    res.json({ success: true, likesCount: post.likesCount, isLiked: index === -1 });
  });

  // 8. Report spam/fraud on a post
  app.post('/api/promotions/posts/:id/report', (req, res) => {
    const { id } = req.params;
    const { userId = 'PANDA1025', reason = 'Spam or malicious content' } = req.body;
    const db = getDb();
    const post = db.promotions.find((p) => p.id === id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    if (!post.reports) post.reports = [];
    post.reports.push({
      userId,
      reason,
      timestamp: new Date().toISOString(),
    });
    post.reportsCount = post.reports.length;

    // Automatic spam protection: If 3 or more users report, auto-block for admin review
    if (post.reportsCount >= 3) {
      post.isBlocked = true;
      post.adminNote = 'Auto-blocked: multiple user fraud reports';
    }

    saveDb(db);
    res.json({
      success: true,
      message: 'Thank you for reporting. Our security team will review this link.',
      reportsCount: post.reportsCount,
    });
  });

  // 9. Get current user's promotions and analytics
  app.get('/api/promotions/my-promotions', (req, res) => {
    const userId = (req.query.userId as string) || 'PANDA1025';
    const db = getDb();
    const now = Date.now();

    const myPosts = db.promotions
      .filter((p) => p.userId === userId)
      .map((p) => {
        let daysRemaining = 0;
        if (p.promotionStatus === 'active' && p.promotionEndDate) {
          const diffMs = new Date(p.promotionEndDate).getTime() - now;
          if (diffMs > 0) {
            daysRemaining = Math.max(1, Math.ceil(diffMs / 86400000));
          }
        }
        return {
          ...p,
          daysRemaining,
        };
      });

    res.json(myPosts);
  });

  // 10. Admin: Manage promotions
  app.get('/api/admin/promotions', (_req, res) => {
    const db = getDb();
    res.json(db.promotions);
  });

  app.post('/api/admin/promotions/:id/approve', (req, res) => {
    const { id } = req.params;
    const db = getDb();
    const post = db.promotions.find((p) => p.id === id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    const pkg = db.packages.find((p) => p.id === post.promotionPackageId) || db.packages[0];
    const duration = post.promotionDurationDays || pkg.durationDays || 7;

    post.promotionStatus = 'active';
    post.isPromoted = true;
    post.promotionStartDate = new Date().toISOString();
    post.promotionEndDate = new Date(Date.now() + duration * 86400000).toISOString();
    post.adminNote = 'Approved by administrator';

    saveDb(db);
    res.json({ success: true, post });
  });

  app.post('/api/admin/promotions/:id/reject', (req, res) => {
    const { id } = req.params;
    const { reason = 'Rejected by administrator' } = req.body;
    const db = getDb();
    const post = db.promotions.find((p) => p.id === id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    post.promotionStatus = 'rejected';
    post.isPromoted = false;
    post.adminNote = reason;

    // Refund promotion cost if it was paid
    if (post.totalCostBDT) {
      const user = db.users.find((u) => u.id === post.userId);
      if (user) {
        user.bdtBalance += post.totalCostBDT;
        db.transactions.unshift({
          id: 'TXN-' + Math.floor(1000 + Math.random() * 9000),
          userId: user.id,
          userName: user.name,
          type: 'task_reward',
          title: 'Promotion Refund',
          method: 'System',
          amount: post.totalCostBDT,
          currency: 'BDT',
          status: 'Completed',
          timestamp: 'Just now',
          createdAt: new Date().toISOString(),
          reference: `Refund for rejected promotion #${post.id}`,
          isSandboxDemo: true,
        });
      }
    }

    saveDb(db);
    res.json({ success: true, post });
  });

  app.post('/api/admin/promotions/:id/toggle-pause', (req, res) => {
    const { id } = req.params;
    const db = getDb();
    const post = db.promotions.find((p) => p.id === id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    if (post.promotionStatus === 'active') {
      post.promotionStatus = 'paused';
    } else if (post.promotionStatus === 'paused') {
      post.promotionStatus = 'active';
    }

    saveDb(db);
    res.json({ success: true, post });
  });

  app.post('/api/admin/promotions/:id/toggle-pin', (req, res) => {
    const { id } = req.params;
    const db = getDb();
    const post = db.promotions.find((p) => p.id === id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    post.isPinnedToTop = !post.isPinnedToTop;
    saveDb(db);
    res.json({ success: true, isPinnedToTop: post.isPinnedToTop });
  });

  app.post('/api/admin/promotions/:id/block', (req, res) => {
    const { id } = req.params;
    const db = getDb();
    const post = db.promotions.find((p) => p.id === id);
    if (!post) return res.status(404).json({ error: 'Post not found' });

    post.isBlocked = !post.isBlocked;
    saveDb(db);
    res.json({ success: true, isBlocked: post.isBlocked });
  });

  app.delete('/api/admin/promotions/:id', (req, res) => {
    const { id } = req.params;
    const db = getDb();
    const index = db.promotions.findIndex((p) => p.id === id);
    if (index === -1) return res.status(404).json({ error: 'Post not found' });

    db.promotions.splice(index, 1);
    saveDb(db);
    res.json({ success: true, message: 'Post deleted' });
  });

  // 11. Admin: Manage Packages (Add, Edit, Toggle)
  app.get('/api/admin/packages', (_req, res) => {
    const db = getDb();
    res.json(db.packages);
  });

  app.post('/api/admin/packages', (req, res) => {
    const { name, durationDays, priceBDT, priceUSD, estimatedReach, badgeText, features } = req.body;
    if (!name || !priceBDT || !durationDays) {
      return res.status(400).json({ error: 'Name, price, and duration are required' });
    }

    const db = getDb();
    const newPkg: PromotionPackage = {
      id: 'PKG-' + Math.floor(100 + Math.random() * 900),
      name: name.trim(),
      durationDays: parseInt(durationDays, 10),
      priceBDT: parseFloat(priceBDT),
      priceUSD: priceUSD ? parseFloat(priceUSD) : parseFloat(priceBDT) / 100,
      estimatedReach: estimatedReach || `${parseInt(durationDays, 10) * 500} - ${parseInt(durationDays, 10) * 1500} Views`,
      badgeText: badgeText || 'Special Offer',
      features: Array.isArray(features) ? features : ['Promoted Badge', 'Priority Placement', 'Click Analytics'],
      isActive: true,
    };

    db.packages.push(newPkg);
    saveDb(db);
    res.json({ success: true, package: newPkg });
  });

  app.put('/api/admin/packages/:id', (req, res) => {
    const { id } = req.params;
    const { name, durationDays, priceBDT, priceUSD, estimatedReach, badgeText, features } = req.body;
    const db = getDb();
    const pkg = db.packages.find((p) => p.id === id);
    if (!pkg) return res.status(404).json({ error: 'Package not found' });

    if (name) pkg.name = name.trim();
    if (durationDays) pkg.durationDays = parseInt(durationDays, 10);
    if (priceBDT !== undefined) pkg.priceBDT = parseFloat(priceBDT);
    if (priceUSD !== undefined) pkg.priceUSD = parseFloat(priceUSD);
    if (estimatedReach) pkg.estimatedReach = estimatedReach;
    if (badgeText) pkg.badgeText = badgeText;
    if (features && Array.isArray(features)) pkg.features = features;

    saveDb(db);
    res.json({ success: true, package: pkg });
  });

  app.post('/api/admin/packages/:id/toggle', (req, res) => {
    const { id } = req.params;
    const db = getDb();
    const pkg = db.packages.find((p) => p.id === id);
    if (!pkg) return res.status(404).json({ error: 'Package not found' });

    pkg.isActive = !pkg.isActive;
    saveDb(db);
    res.json({ success: true, isActive: pkg.isActive });
  });

  // Mount Vite middlewares in development or serve static in production
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PANDA APP Full-Stack server running on http://localhost:${PORT}`);
  });
}

createServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
