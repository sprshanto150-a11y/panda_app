import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface UserRecord {
  id: string;
  name: string;
  username: string;
  email: string;
  phone: string;
  passwordHash: string;
  avatar: string;
  bdtBalance: number;
  usdBalance: number;
  referralCode: string;
  referredBy?: string;
  role: 'user' | 'admin';
  isBanned: boolean;
  followers: number;
  following: number;
  postsCount: number;
  createdAt: string;
}

export interface TransactionRecord {
  id: string;
  userId: string;
  userName: string;
  type: 'deposit' | 'withdraw' | 'referral' | 'task_reward' | 'promotion_boost';
  title: string;
  method: 'Nagad' | 'Binance' | 'System' | 'Task';
  amount: number;
  currency: 'BDT' | 'USD';
  status: 'Pending' | 'Approved' | 'Completed' | 'Rejected';
  timestamp: string;
  createdAt: string;
  trxId?: string;
  accountNumber?: string;
  reference?: string;
  isSandboxDemo: boolean;
  adminNote?: string;
}

export interface TaskRecord {
  id: string;
  title: string;
  type: 'video_ad' | 'spin_wheel' | 'math_quiz' | 'social_task' | 'daily_checkin';
  sponsor: string;
  rewardAmount: number;
  currency: 'BDT' | 'USD';
  category: string;
  durationSec?: number;
  linkUrl?: string;
  isActive: boolean;
}

export interface TaskCompletionRecord {
  id: string;
  userId: string;
  taskId: string;
  rewardClaimed: number;
  currency: 'BDT' | 'USD';
  completedAt: string;
}

export interface PostRecord {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  content: string;
  timeAgo: string;
  likes: number;
  likedBy: string[];
  tag?: string;
  proofAmount?: string;
  createdAt: string;
}

// --- PANDA PROMOTION DATA STRUCTURES ---
export interface PromotionPackage {
  id: string;
  name: string;
  durationDays: number;
  priceBDT: number;
  priceUSD: number;
  estimatedReach: string;
  badgeText: string;
  features: string[];
  isActive: boolean;
}

export interface PromotionPostRecord {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  mediaUrl?: string;
  linkType: 'website' | 'facebook' | 'youtube' | 'instagram' | 'telegram' | 'other';
  linkUrl: string;
  linkTitle?: string;
  isPromoted: boolean;
  isPinnedToTop: boolean;
  promotionPackageId?: string;
  packageName?: string;
  promotionStatus: 'none' | 'pending_approval' | 'active' | 'paused' | 'completed' | 'rejected';
  promotionStartDate?: string;
  promotionEndDate?: string;
  promotionDurationDays?: number;
  totalCostBDT?: number;
  totalCostUSD?: number;
  viewsCount: number;
  clicksCount: number;
  likesCount: number;
  likedBy: string[];
  reportsCount: number;
  reports: { userId: string; reason: string; timestamp: string }[];
  isBlocked: boolean;
  adminNote?: string;
  createdAt: string;
}

export interface SystemSettings {
  isSandboxDemoMode: boolean;
  sandboxNotice: string;
  nagadAgentNumber: string;
  binancePayId: string;
  minDepositBDT: number;
  maxDepositBDT: number;
  minDepositUSD: number;
  minWithdrawBDT: number;
  maxWithdrawBDT: number;
  minWithdrawUSD: number;
  dailyAdLimit: number;
  maintenanceMode: boolean;
}

export interface DatabaseSchema {
  users: UserRecord[];
  transactions: TransactionRecord[];
  tasks: TaskRecord[];
  taskCompletions: TaskCompletionRecord[];
  posts: PostRecord[];
  promotions: PromotionPostRecord[];
  packages: PromotionPackage[];
  settings: SystemSettings;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password + '_panda_salt_2026').digest('hex');
}

// Spam & Phishing Domain / Content Safety Checker
const BLOCKED_DOMAINS = [
  'free-money',
  'hack-bkash',
  'hack-nagad',
  'grabify.link',
  'iplogger.org',
  'bit.ly/fake',
  'phish',
  'malware',
  'stealer',
  'carding',
];

const SPAM_KEYWORDS = [
  'free money hack',
  '100% guaranteed jackpot lottery',
  'send 500 get 50000 instant',
  'nagad otp pin bypass',
  'bkash secret pin hack',
];

export function checkLinkSafety(url: string, content: string): { isSafe: boolean; reason?: string } {
  try {
    const lowerUrl = url.toLowerCase();
    const lowerContent = content.toLowerCase();

    // Check blocked domains
    for (const bad of BLOCKED_DOMAINS) {
      if (lowerUrl.includes(bad)) {
        return { isSafe: false, reason: `Link matches untrusted domain filter: ${bad}` };
      }
    }

    // Check spam keywords
    for (const kw of SPAM_KEYWORDS) {
      if (lowerContent.includes(kw) || lowerUrl.includes(kw)) {
        return { isSafe: false, reason: `Content contains prohibited spam phrase: "${kw}"` };
      }
    }

    // Check valid URL protocol
    if (!lowerUrl.startsWith('http://') && !lowerUrl.startsWith('https://')) {
      return { isSafe: false, reason: 'URL must start with https:// or http://' };
    }

    return { isSafe: true };
  } catch {
    return { isSafe: false, reason: 'Malformed URL' };
  }
}

const defaultPackages: PromotionPackage[] = [
  {
    id: 'PKG-7D-5TK',
    name: 'Starter Boost (7 Days)',
    durationDays: 7,
    priceBDT: 5,
    priceUSD: 0.05,
    estimatedReach: '1,500 - 3,500 Targeted Views',
    badgeText: 'Most Popular',
    features: [
      '7 Days Active Promotion',
      'Promoted / Sponsored Glow Badge',
      'Verified Click Tracking',
      'Public Feed Showcase',
    ],
    isActive: true,
  },
  {
    id: 'PKG-14D-10TK',
    name: 'Growth Boost (14 Days)',
    durationDays: 14,
    priceBDT: 10,
    priceUSD: 0.10,
    estimatedReach: '5,000 - 10,000 Targeted Views',
    badgeText: 'Best Value',
    features: [
      '14 Days Active Promotion',
      'Priority Feed Placement',
      'High Click-Through Rate',
      'Live Views & Clicks Analytics',
      'Social Share Amplifier',
    ],
    isActive: true,
  },
  {
    id: 'PKG-30D-20TK',
    name: 'Viral King Boost (30 Days)',
    durationDays: 30,
    priceBDT: 20,
    priceUSD: 0.20,
    estimatedReach: '15,000 - 35,000 Targeted Views',
    badgeText: 'VIP Viral',
    features: [
      '30 Days Unlimited Boost',
      'Pinned Near Top of Feed',
      'VIP Sponsored Crown Accent',
      'Website / YouTube / Facebook Tracking',
      '24/7 Dedicated Support',
    ],
    isActive: true,
  },
];

const defaultPromotions: PromotionPostRecord[] = [
  {
    id: 'PROM-101',
    userId: 'PANDA1025',
    userName: 'Rahim',
    userAvatar: '/assets/app/user_rahim.png',
    content: 'Check out my YouTube Channel for daily verified earning methods, crypto signals, and Panda App tips! Subscribe now and learn how to earn daily 🚀🔥',
    linkType: 'youtube',
    linkUrl: 'https://youtube.com/@rahim_earner',
    linkTitle: 'Rahim Official YouTube Channel',
    isPromoted: true,
    isPinnedToTop: true,
    promotionPackageId: 'PKG-7D-5TK',
    packageName: 'Starter Boost (7 Days)',
    promotionStatus: 'active',
    promotionStartDate: new Date().toISOString(),
    promotionEndDate: new Date(Date.now() + 7 * 86400000).toISOString(),
    promotionDurationDays: 7,
    totalCostBDT: 5,
    totalCostUSD: 0.05,
    viewsCount: 1420,
    clicksCount: 218,
    likesCount: 54,
    likedBy: ['PANDA1011', 'PANDA1088'],
    reportsCount: 0,
    reports: [],
    isBlocked: false,
    adminNote: 'Approved by admin for top feed broadcast',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'PROM-102',
    userId: 'PANDA1011',
    userName: 'Karim',
    userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
    content: 'Follow my official Facebook Page for daily updates, payment proofs, and exclusive giveaways! Join our growing community of 15,000 members 🐼',
    linkType: 'facebook',
    linkUrl: 'https://facebook.com/karim_earner_pro',
    linkTitle: 'Karim Pro - Official Facebook Page',
    isPromoted: true,
    isPinnedToTop: false,
    promotionPackageId: 'PKG-14D-10TK',
    packageName: 'Growth Boost (14 Days)',
    promotionStatus: 'active',
    promotionStartDate: new Date(Date.now() - 2 * 86400000).toISOString(),
    promotionEndDate: new Date(Date.now() + 12 * 86400000).toISOString(),
    promotionDurationDays: 14,
    totalCostBDT: 10,
    totalCostUSD: 0.10,
    viewsCount: 890,
    clicksCount: 112,
    likesCount: 38,
    likedBy: ['PANDA1025'],
    reportsCount: 0,
    reports: [],
    isBlocked: false,
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
  },
  {
    id: 'PROM-103',
    userId: 'PANDA1088',
    userName: 'Asif',
    userAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=120&auto=format&fit=crop&q=80',
    content: 'Visit my tech blog and portfolio website to see my latest web development & mobile app projects! Free resources available for developers 🌐💻',
    linkType: 'website',
    linkUrl: 'https://asif-portfolio.dev',
    linkTitle: 'Asif Tech Portfolio & Blog',
    isPromoted: false,
    isPinnedToTop: false,
    promotionStatus: 'none',
    viewsCount: 340,
    clicksCount: 42,
    likesCount: 19,
    likedBy: [],
    reportsCount: 0,
    reports: [],
    isBlocked: false,
    createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
  },
];

const initialDatabase: DatabaseSchema = {
  users: [
    {
      id: 'PANDA1025',
      name: 'Rahim',
      username: 'rahim_earner',
      email: 'rahim@panda.app',
      phone: '01712345678',
      passwordHash: hashPassword('panda123'),
      avatar: '/assets/app/user_rahim.png',
      bdtBalance: 0.0,
      usdBalance: 0.0,
      referralCode: 'PANDA1025',
      referredBy: 'PANDA1001',
      role: 'user',
      isBanned: false,
      followers: 120,
      following: 50,
      postsCount: 25,
      createdAt: '2026-10-01T08:00:00.000Z',
    },
    {
      id: 'PANDA-ADMIN',
      name: 'System Admin',
      username: 'admin',
      email: 'admin@panda.app',
      phone: '01887654321',
      passwordHash: hashPassword('admin123'),
      avatar: '/assets/app/panda_head.png',
      bdtBalance: 100000.0,
      usdBalance: 5000.0,
      referralCode: 'PANDAADMIN',
      role: 'admin',
      isBanned: false,
      followers: 5000,
      following: 10,
      postsCount: 100,
      createdAt: '2026-09-01T00:00:00.000Z',
    },
    {
      id: 'PANDA1011',
      name: 'Karim',
      username: 'karim_pro',
      email: 'karim@panda.app',
      phone: '01811223344',
      passwordHash: hashPassword('panda123'),
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
      bdtBalance: 3500.0,
      usdBalance: 45.0,
      referralCode: 'PANDA1011',
      role: 'user',
      isBanned: false,
      followers: 85,
      following: 30,
      postsCount: 14,
      createdAt: '2026-10-05T12:00:00.000Z',
    },
    {
      id: 'PANDA1088',
      name: 'Asif',
      username: 'asif_king',
      email: 'asif@panda.app',
      phone: '01999887766',
      passwordHash: hashPassword('panda123'),
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=120&auto=format&fit=crop&q=80',
      bdtBalance: 2000.0,
      usdBalance: 20.0,
      referralCode: 'PANDA1088',
      role: 'user',
      isBanned: false,
      followers: 64,
      following: 40,
      postsCount: 8,
      createdAt: '2026-10-10T14:30:00.000Z',
    },
  ],
  transactions: [
    {
      id: 'TXN-101',
      userId: 'PANDA1025',
      userName: 'Rahim',
      type: 'deposit',
      title: 'Deposit (Nagad)',
      method: 'Nagad',
      amount: 500,
      currency: 'BDT',
      status: 'Pending',
      timestamp: 'Today, 2:30 PM',
      createdAt: new Date().toISOString(),
      accountNumber: '01887654321',
      trxId: '9J8A7K6L5M',
      isSandboxDemo: true,
      adminNote: 'Awaiting admin review in sandbox testnet',
    },
    {
      id: 'TXN-102',
      userId: 'PANDA1025',
      userName: 'Rahim',
      type: 'referral',
      title: 'Referral Reward',
      method: 'System',
      amount: 50,
      currency: 'BDT',
      status: 'Completed',
      timestamp: 'Yesterday, 8:15 PM',
      createdAt: new Date(Date.now() - 86400000).toISOString(),
      reference: 'New member join bonus: Sakib',
      isSandboxDemo: true,
    },
    {
      id: 'TXN-103',
      userId: 'PANDA1025',
      userName: 'Rahim',
      type: 'withdraw',
      title: 'Withdraw to Nagad',
      method: 'Nagad',
      amount: 200,
      currency: 'BDT',
      status: 'Approved',
      timestamp: 'Nov 05, 11:40 AM',
      createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
      accountNumber: '01712345678',
      trxId: '8H7G6F5D4S',
      isSandboxDemo: true,
    },
    {
      id: 'TXN-104',
      userId: 'PANDA1025',
      userName: 'Rahim',
      type: 'task_reward',
      title: 'Ad Video Bonus',
      method: 'Task',
      amount: 10,
      currency: 'BDT',
      status: 'Completed',
      timestamp: 'Nov 04, 04:20 PM',
      createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
      isSandboxDemo: true,
    },
    {
      id: 'TXN-105',
      userId: 'PANDA1025',
      userName: 'Rahim',
      type: 'promotion_boost',
      title: 'Panda Promotion: 7 Days Starter Boost',
      method: 'System',
      amount: 5,
      currency: 'BDT',
      status: 'Completed',
      timestamp: 'Today, 10:00 AM',
      createdAt: new Date().toISOString(),
      reference: 'YouTube Channel Boost (7 Days for ৳5)',
      isSandboxDemo: true,
    },
  ],
  tasks: [
    {
      id: 'TASK-01',
      title: 'Binance Pay Quick Tour',
      type: 'video_ad',
      sponsor: 'Binance Official',
      rewardAmount: 10,
      currency: 'BDT',
      category: 'Crypto & Fintech',
      durationSec: 10,
      isActive: true,
    },
    {
      id: 'TASK-02',
      title: 'Nagad Super Cashback Offer',
      type: 'video_ad',
      sponsor: 'Nagad Bangladesh',
      rewardAmount: 8,
      currency: 'BDT',
      category: 'Mobile Financial Services',
      durationSec: 8,
      isActive: true,
    },
    {
      id: 'TASK-03',
      title: 'Lucky Panda Daily Spin Wheel',
      type: 'spin_wheel',
      sponsor: 'Panda Rewards',
      rewardAmount: 15,
      currency: 'BDT',
      category: 'Daily Game',
      isActive: true,
    },
    {
      id: 'TASK-04',
      title: 'Quick Math Brain Challenge',
      type: 'math_quiz',
      sponsor: 'EduTech Academy',
      rewardAmount: 12,
      currency: 'BDT',
      category: 'Skill Challenge',
      durationSec: 15,
      isActive: true,
    },
    {
      id: 'TASK-05',
      title: 'Join Official Telegram Community',
      type: 'social_task',
      sponsor: 'Panda Ecosystem',
      rewardAmount: 0.15,
      currency: 'USD',
      category: 'Community',
      linkUrl: 'https://t.me/pandaapp',
      isActive: true,
    },
  ],
  taskCompletions: [],
  posts: [
    {
      id: 'post-1',
      authorId: 'PANDA1011',
      authorName: 'Karim',
      authorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
      content: 'Just completed test withdrawal of ৳1,500 in sandbox mode! The automated approval was super clean! 🚀🔥',
      timeAgo: '15m ago',
      likes: 34,
      likedBy: ['PANDA1025'],
      tag: 'Payment Proof',
      proofAmount: '৳1,500 Nagad (Sandbox)',
      createdAt: new Date().toISOString(),
    },
  ],
  promotions: defaultPromotions,
  packages: defaultPackages,
  settings: {
    isSandboxDemoMode: true,
    sandboxNotice: 'DEMO TESTNET ACTIVE: All balances, deposits and withdrawals are test simulations. Real money transfers are strictly disabled until official merchant API keys and server verification are configured.',
    nagadAgentNumber: '01887654321',
    binancePayId: '92817402',
    minDepositBDT: 50,
    maxDepositBDT: 50000,
    minDepositUSD: 5,
    minWithdrawBDT: 100,
    maxWithdrawBDT: 10000,
    minWithdrawUSD: 5,
    dailyAdLimit: 10,
    maintenanceMode: false,
  },
};

export function getDb(): DatabaseSchema {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(initialDatabase, null, 2), 'utf-8');
    return initialDatabase;
  }

  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as DatabaseSchema;
    // Ensure promotions and packages exist if older file was loaded
    if (!parsed.promotions) parsed.promotions = defaultPromotions;
    if (!parsed.packages) parsed.packages = defaultPackages;
    return parsed;
  } catch (err) {
    console.error('Failed to parse db.json, recreating with initial database:', err);
    fs.writeFileSync(DB_FILE, JSON.stringify(initialDatabase, null, 2), 'utf-8');
    return initialDatabase;
  }
}

export function saveDb(data: DatabaseSchema): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const tempFile = `${DB_FILE}.tmp`;
  fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tempFile, DB_FILE);
}
