/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { SideDrawer } from './components/SideDrawer';
import { NotificationModal } from './components/NotificationModal';
import { SupportModal } from './components/SupportModal';
import { DesignCompareModal } from './components/DesignCompareModal';

// Screens
import { SplashScreen } from './screens/SplashScreen';
import { LoginScreen } from './screens/LoginScreen';
import { RegisterScreen } from './screens/RegisterScreen';
import { HomeScreen } from './screens/HomeScreen';
import { WalletScreen } from './screens/WalletScreen';
import { DepositScreen } from './screens/DepositScreen';
import { WithdrawScreen } from './screens/WithdrawScreen';
import { LeaderboardScreen } from './screens/LeaderboardScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { AdsScreen } from './screens/AdsScreen';
import { ReferralScreen } from './screens/ReferralScreen';
import { PeopleScreen } from './screens/PeopleScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { AdminScreen } from './screens/AdminScreen';
import { SpinWheelScreen } from './screens/SpinWheelScreen';
import { MathQuizScreen } from './screens/MathQuizScreen';
import { ApkGuideScreen } from './screens/ApkGuideScreen';
import { PandaPromotionScreen } from './screens/PandaPromotionScreen';

import { ScreenType } from './types';
import { Smartphone, Layers, Sparkles, Monitor, ShieldAlert, Rocket } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { screen, setScreen, setIsDesignModalOpen, isAdmin } = useApp();
  const [useBezel, setUseBezel] = useState(true);

  const screenList: { id: ScreenType; label: string }[] = [
    { id: 'splash', label: '1. Splash' },
    { id: 'login', label: '2. Login' },
    { id: 'register', label: '3. Register' },
    { id: 'home', label: '4. Home' },
    { id: 'promotion', label: '🔥 5. Panda Promotion' },
    { id: 'wallet', label: '6. Wallet' },
    { id: 'deposit', label: '7. Deposit' },
    { id: 'withdraw', label: '8. Withdraw' },
    { id: 'leaderboard', label: '9. Leaderboard' },
    { id: 'profile', label: '10. Profile' },
    { id: 'ads', label: '11. Ads' },
    { id: 'spin', label: '12. Spin Wheel' },
    { id: 'quiz', label: '13. Math Quiz' },
    { id: 'referral', label: '14. Referral' },
    { id: 'people', label: '15. Community' },
    { id: 'admin', label: '⚡ Admin Portal' },
    { id: 'apk_guide', label: '📱 APK Hub' },
  ];

  const renderActiveScreen = () => {
    switch (screen) {
      case 'splash':
        return <SplashScreen />;
      case 'login':
        return <LoginScreen />;
      case 'register':
        return <RegisterScreen />;
      case 'home':
        return <HomeScreen />;
      case 'promotion':
        return <PandaPromotionScreen />;
      case 'wallet':
        return <WalletScreen />;
      case 'deposit':
        return <DepositScreen />;
      case 'withdraw':
        return <WithdrawScreen />;
      case 'leaderboard':
        return <LeaderboardScreen />;
      case 'profile':
        return <ProfileScreen />;
      case 'ads':
        return <AdsScreen />;
      case 'spin':
        return <SpinWheelScreen />;
      case 'quiz':
        return <MathQuizScreen />;
      case 'referral':
        return <ReferralScreen />;
      case 'people':
        return <PeopleScreen />;
      case 'settings':
        return <SettingsScreen />;
      case 'admin':
        return <AdminScreen />;
      case 'apk_guide':
        return <ApkGuideScreen />;
      default:
        return <HomeScreen />;
    }
  };

  return (
    <div className="min-h-screen bg-[#03081e] text-white flex flex-col items-center">
      {/* Desktop Top Control & Screen Switcher Bar */}
      <div className="w-full bg-[#050e2d]/95 backdrop-blur-md border-b border-[#133273] px-4 py-2.5 z-30 sticky top-0">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Logo & title */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full overflow-hidden border border-cyan-400 p-0.5 shadow-[0_0_10px_rgba(0,229,255,0.5)]">
              <img
                src="/assets/app/panda_head.png"
                alt="Panda App"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <span className="font-heading font-black text-sm text-white tracking-wider flex items-center gap-1.5">
                PANDA APP
                <span className="text-[10px] text-amber-300 font-semibold px-1.5 py-0.2 rounded bg-amber-500/20 border border-amber-500/40">
                  Earn • Share • Grow
                </span>
              </span>
            </div>
          </div>

          {/* Quick jump to all screens */}
          <div className="hidden lg:flex items-center gap-1 overflow-x-auto py-1">
            {screenList.map((s) => (
              <button
                key={s.id}
                onClick={() => setScreen(s.id)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  screen === s.id
                    ? 'bg-gradient-to-r from-blue-600 to-cyan-500 text-white shadow-sm shadow-blue-500/40'
                    : 'text-slate-300 hover:text-white hover:bg-blue-900/40'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>

          {/* Right Action Tools */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsDesignModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-500/50 hover:border-amber-400 text-amber-300 text-xs font-bold transition-all shadow-sm group"
            >
              <Layers className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
              <span>Compare Design Sheet</span>
            </button>

            <button
              onClick={() => setUseBezel(!useBezel)}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-[#091f54] border border-blue-500/40 hover:border-cyan-400 text-xs text-slate-200 transition-colors"
              title="Toggle mobile device frame"
            >
              {useBezel ? <Monitor className="w-3.5 h-3.5" /> : <Smartphone className="w-3.5 h-3.5" />}
              <span>{useBezel ? 'Full Width' : 'Phone Frame'}</span>
            </button>
          </div>
        </div>

        {/* Mobile Horizontal Screen Carousel */}
        <div className="flex lg:hidden items-center gap-1.5 overflow-x-auto pt-2 pb-0.5 no-scrollbar">
          {screenList.map((s) => (
            <button
              key={s.id}
              onClick={() => setScreen(s.id)}
              className={`px-2 py-0.5 rounded-lg text-[11px] font-semibold whitespace-nowrap shrink-0 transition-all ${
                screen === s.id
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-white bg-[#081742]'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Container */}
      <main className="w-full flex-1 flex justify-center items-start py-2 sm:py-6 px-1 sm:px-4">
        {useBezel ? (
          /* Phone Bezel Frame */
          <div className="relative w-full max-w-[420px] bg-[#020718] rounded-[42px] border-[8px] border-[#0c1c45] shadow-[0_0_50px_rgba(0,102,255,0.25)] overflow-hidden flex flex-col min-h-[820px]">
            {/* Top speaker notch */}
            <div className="w-full flex items-center justify-center pt-2 pb-1 bg-[#040b25] z-30">
              <div className="w-24 h-4 bg-[#0a1738] rounded-full flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-[#152a5c] mr-2" />
                <div className="w-10 h-1 rounded-full bg-[#152a5c]" />
              </div>
            </div>

            {/* App Header */}
            <Header />

            {/* Scrollable Viewport */}
            <div className="flex-1 overflow-y-auto relative bg-[#03091e]">
              {renderActiveScreen()}
            </div>

            {/* Bottom Nav */}
            <BottomNav />
          </div>
        ) : (
          /* Responsive Full Width Container */
          <div className="w-full max-w-md bg-[#03091e] border border-[#133273] rounded-2xl overflow-hidden flex flex-col shadow-2xl relative min-h-[800px]">
            <Header />
            <div className="flex-1 overflow-y-auto">
              {renderActiveScreen()}
            </div>
            <BottomNav />
          </div>
        )}
      </main>

      {/* Modals & Drawers */}
      <SideDrawer />
      <NotificationModal />
      <SupportModal />
      <DesignCompareModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
