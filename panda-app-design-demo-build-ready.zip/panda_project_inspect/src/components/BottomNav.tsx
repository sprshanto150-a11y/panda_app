import React from 'react';
import { Home, Users, Trophy, Wallet, User } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ScreenType } from '../types';

export const BottomNav: React.FC = () => {
  const { screen, setScreen } = useApp();

  // Hide bottom nav on splash, login, register screens
  if (screen === 'splash' || screen === 'login' || screen === 'register') {
    return null;
  }

  const navItems: { label: string; icon: React.ReactNode; target: ScreenType }[] = [
    { label: 'Home', icon: <Home className="w-5 h-5" />, target: 'home' },
    { label: 'People', icon: <Users className="w-5 h-5" />, target: 'people' },
    { label: 'Rank', icon: <Trophy className="w-5 h-5" />, target: 'leaderboard' },
    { label: 'Wallet', icon: <Wallet className="w-5 h-5" />, target: 'wallet' },
    { label: 'Profile', icon: <User className="w-5 h-5" />, target: 'profile' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 max-w-md mx-auto bg-[#050e2d]/95 backdrop-blur-md border-t border-[#133273] px-3 py-2">
      <div className="grid grid-cols-5 items-center">
        {navItems.map((item) => {
          const isActive =
            screen === item.target ||
            (item.target === 'wallet' && (screen === 'deposit' || screen === 'withdraw')) ||
            (item.target === 'people' && screen === 'referral') ||
            (item.target === 'home' && screen === 'ads');

          return (
            <button
              key={item.label}
              onClick={() => setScreen(item.target)}
              className="flex flex-col items-center justify-center py-1 transition-all duration-200 group active:scale-95"
            >
              <div
                className={`transition-colors duration-200 ${
                  isActive ? 'text-[#ffcc00] filter drop-shadow-[0_0_8px_rgba(255,204,0,0.6)]' : 'text-slate-400 group-hover:text-slate-200'
                }`}
              >
                {item.icon}
              </div>
              <span
                className={`text-[10px] font-medium tracking-tight mt-1 transition-colors ${
                  isActive ? 'text-[#ffcc00] font-semibold' : 'text-slate-400 group-hover:text-slate-200'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
