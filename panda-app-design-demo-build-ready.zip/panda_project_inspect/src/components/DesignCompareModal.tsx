import React from 'react';
import { X, ExternalLink, Layers, CheckCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ScreenType } from '../types';

export const DesignCompareModal: React.FC = () => {
  const { isDesignModalOpen, setIsDesignModalOpen, setScreen } = useApp();

  if (!isDesignModalOpen) return null;

  const screens: { id: ScreenType; label: string; desc: string }[] = [
    { id: 'splash', label: '1. Splash Screen', desc: 'King Panda mascot, logo, and loading progress bar' },
    { id: 'login', label: '2. Welcome Back (Login)', desc: 'Email/Username, password, and Google login' },
    { id: 'register', label: '3. Create Account (Register)', desc: 'Full Name, Phone, Email, Referral code' },
    { id: 'home', label: '4. Home Dashboard', desc: 'BDT/USD balances, 6-icon grid, promo banner, top earners' },
    { id: 'wallet', label: '5. My Wallet', desc: 'Total balance, BDT/USD switch, deposit shortcuts, history' },
    { id: 'deposit', label: '6. Deposit Screen', desc: 'Nagad (৳50-৳50,000) & Binance ($5 min) payment methods' },
    { id: 'withdraw', label: '7. Withdraw Screen', desc: 'Nagad number & Binance Pay ID cashout inputs' },
    { id: 'leaderboard', label: '8. Leaderboard', desc: 'Top 3 animated podiums (Rahim, Karim, Asif) & ranks' },
    { id: 'profile', label: '9. My Profile', desc: 'Stats (120 followers, 50 following), menu shortcuts' },
    { id: 'ads', label: '10. Watch Ads & Earn', desc: 'Daily video tasks to earn real wallet rewards' },
    { id: 'referral', label: '11. Referral System', desc: 'Share code PANDA1025, commission bonus breakdown' },
    { id: 'people', label: '12. Community Feed', desc: 'Live earning proofs & follow active members' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5">
      <div
        className="fixed inset-0 bg-black/85 backdrop-blur-md"
        onClick={() => setIsDesignModalOpen(false)}
      />
      <div className="relative w-full max-w-4xl bg-[#061239] border border-[#1d4bb0] rounded-2xl p-5 shadow-2xl z-10 max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#153477]">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-cyan-400" />
            <div>
              <h3 className="font-heading font-bold text-white text-base">
                Design Reference & All 10 Mockup Screens
              </h3>
              <p className="text-xs text-slate-300">
                Created directly according to the attached blueprint image
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsDesignModalOpen(false)}
            className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-white rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4">
          {/* Image Banner */}
          <div className="rounded-xl overflow-hidden border border-blue-500/40 bg-black/50 p-2 text-center">
            <p className="text-xs text-cyan-300 mb-2 font-medium">
              Original Design Mockup (from prompt attachment):
            </p>
            <div className="max-h-72 overflow-y-auto rounded-lg border border-slate-700 bg-slate-950">
              <img
                src="/assets/aistudio/file_0000000088b88208a36e75d614a95215_c3e55c85.png"
                alt="Original Design"
                className="w-full h-auto object-contain"
              />
            </div>
          </div>

          {/* Quick Screen Jump Grid */}
          <div>
            <h4 className="text-sm font-semibold text-white mb-2 flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              Click any screen below to preview and test interactively:
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {screens.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setScreen(item.id);
                    setIsDesignModalOpen(false);
                  }}
                  className="p-3 rounded-xl bg-[#091a4f] border border-[#173b88] hover:border-cyan-400 hover:bg-[#0c246e] text-left transition-all group"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-cyan-300 group-hover:text-white">
                      {item.label}
                    </span>
                    <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-cyan-400" />
                  </div>
                  <p className="text-[11px] text-slate-300 mt-1 line-clamp-2 leading-relaxed">
                    {item.desc}
                  </p>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-[#153477] flex justify-end">
          <button
            onClick={() => setIsDesignModalOpen(false)}
            className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md shadow-blue-600/30 transition-colors"
          >
            Continue Testing App
          </button>
        </div>
      </div>
    </div>
  );
};
