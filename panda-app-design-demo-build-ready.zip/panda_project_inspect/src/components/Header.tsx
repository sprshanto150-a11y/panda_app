import React from 'react';
import { Menu, Bell, ChevronLeft, MoreHorizontal, Settings } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Header: React.FC = () => {
  const {
    screen,
    setScreen,
    goBack,
    setIsDrawerOpen,
    setIsNotificationOpen,
  } = useApp();

  // Hidden on splash, login, register
  if (screen === 'splash' || screen === 'login' || screen === 'register') {
    return null;
  }

  const isHome = screen === 'home';

  const getTitle = () => {
    switch (screen) {
      case 'promotion':
        return 'PANDA PROMOTION';
      case 'wallet':
        return 'My Wallet';
      case 'deposit':
        return 'Deposit';
      case 'withdraw':
        return 'Withdraw';
      case 'leaderboard':
        return 'Leaderboard';
      case 'profile':
        return 'My Profile';
      case 'ads':
        return 'Watch Ads & Earn';
      case 'referral':
        return 'Referral Program';
      case 'people':
        return 'Community & People';
      case 'admin':
        return 'Admin Dashboard';
      case 'spin':
        return 'Lucky Spin Wheel';
      case 'quiz':
        return 'Math Brain Challenge';
      case 'apk_guide':
        return 'Android APK Hub';
      case 'settings':
        return 'Settings';
      default:
        return 'PANDA APP';
    }
  };

  return (
    <header className="sticky top-0 z-30 max-w-md mx-auto bg-[#040b25]/95 backdrop-blur-md border-b border-[#133273] px-4 py-3 flex items-center justify-between">
      {isHome ? (
        <button
          onClick={() => setIsDrawerOpen(true)}
          className="w-10 h-10 -ml-1 flex items-center justify-center text-slate-200 hover:text-white rounded-xl active:bg-blue-900/30 transition-colors"
          aria-label="Open menu"
        >
          <Menu className="w-6 h-6" />
        </button>
      ) : (
        <button
          onClick={goBack}
          className="w-10 h-10 -ml-1 flex items-center justify-center text-slate-200 hover:text-white rounded-xl active:bg-blue-900/30 transition-colors"
          aria-label="Go back"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
      )}

      {isHome ? (
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full overflow-hidden border border-blue-400/50 shadow-[0_0_10px_rgba(0,149,255,0.4)]">
            <img
              src="/assets/app/panda_head.png"
              alt="Panda"
              className="w-full h-full object-cover"
              onError={(e) => {
                // fallback to mascot full
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </div>
          <span className="font-heading text-lg font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-100 to-blue-300 drop-shadow-[0_0_12px_rgba(0,149,255,0.5)]">
            PANDA APP
          </span>
        </div>
      ) : (
        <h1 className="font-heading text-base font-bold text-white tracking-wide">
          {getTitle()}
        </h1>
      )}

      <div className="flex items-center gap-1">
        {isHome && (
          <button
            onClick={() => setIsNotificationOpen(true)}
            className="relative w-10 h-10 flex items-center justify-center text-slate-200 hover:text-white rounded-xl active:bg-blue-900/30 transition-colors"
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          </button>
        )}

        {screen === 'profile' && (
          <button
            onClick={() => setScreen('settings')}
            className="w-10 h-10 flex items-center justify-center text-slate-200 hover:text-white rounded-xl active:bg-blue-900/30 transition-colors"
            aria-label="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
        )}

        {(screen === 'wallet' || screen === 'leaderboard') && (
          <button
            onClick={() => setIsDrawerOpen(true)}
            className="w-10 h-10 flex items-center justify-center text-slate-300 hover:text-white rounded-xl active:bg-blue-900/30 transition-colors"
            aria-label="More options"
          >
            <MoreHorizontal className="w-5 h-5" />
          </button>
        )}

        {/* Placeholder spacer for centered title if no right action */}
        {!isHome && screen !== 'profile' && screen !== 'wallet' && screen !== 'leaderboard' && (
          <div className="w-10 h-10" />
        )}
      </div>
    </header>
  );
};
