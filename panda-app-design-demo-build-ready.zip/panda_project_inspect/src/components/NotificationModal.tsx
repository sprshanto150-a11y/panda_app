import React from 'react';
import { X, CheckCircle, Clock, Bell, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const NotificationModal: React.FC = () => {
  const { isNotificationOpen, setIsNotificationOpen } = useApp();

  if (!isNotificationOpen) return null;

  const notifications = [
    {
      id: 1,
      title: 'Nagad Deposit Received',
      message: 'Your deposit of ৳500 has been verified and added to your BDT balance.',
      time: '10m ago',
      type: 'success',
    },
    {
      id: 2,
      title: 'Daily Ads Refreshed',
      message: '4 new high-paying sponsored ads are available to watch and earn today!',
      time: '2h ago',
      type: 'info',
    },
    {
      id: 3,
      title: 'Leaderboard Ranking Update',
      message: 'Congratulations! You are holding Rank #1 in All Time top earners.',
      time: '5h ago',
      type: 'reward',
    },
    {
      id: 4,
      title: 'Referral Bonus Credited',
      message: 'You earned ৳50 commission from Sakib who registered using your code PANDA1025.',
      time: '1d ago',
      type: 'success',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="fixed inset-0 bg-black/75 backdrop-blur-sm"
        onClick={() => setIsNotificationOpen(false)}
      />
      <div className="relative w-full max-w-sm bg-[#061239] border border-[#1b4396] rounded-2xl p-5 shadow-2xl z-10 max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-[#153477]">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-yellow-400" />
            <h3 className="font-heading font-bold text-white text-base">Notifications</h3>
          </div>
          <button
            onClick={() => setIsNotificationOpen(false)}
            className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-white rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto py-3 space-y-3">
          {notifications.map((item) => (
            <div
              key={item.id}
              className="p-3 rounded-xl bg-[#091a4f]/70 border border-[#173b88] hover:border-blue-400/40 transition-colors"
            >
              <div className="flex items-start gap-2.5">
                {item.type === 'success' ? (
                  <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                ) : item.type === 'reward' ? (
                  <Sparkles className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                ) : (
                  <Clock className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                )}
                <div>
                  <h4 className="text-sm font-semibold text-white">{item.title}</h4>
                  <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">{item.message}</p>
                  <span className="text-[10px] text-slate-400 mt-1 block">{item.time}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={() => setIsNotificationOpen(false)}
          className="w-full mt-2 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 text-white font-medium text-xs hover:from-blue-500 hover:to-blue-400 transition-all shadow-md shadow-blue-600/30"
        >
          Mark All as Read
        </button>
      </div>
    </div>
  );
};
