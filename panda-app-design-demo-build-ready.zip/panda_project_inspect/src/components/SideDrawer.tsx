import {
  X,
  User,
  Wallet,
  ArrowDownCircle,
  ArrowUpCircle,
  Users,
  Trophy,
  Tv,
  HelpCircle,
  LogOut,
  Sparkles,
  Share2,
  ShieldCheck,
  Smartphone,
  Rocket,
  Flame,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const SideDrawer: React.FC = () => {
  const {
    isDrawerOpen,
    setIsDrawerOpen,
    user,
    setScreen,
    logout,
    setIsSupportOpen,
    setIsDesignModalOpen,
  } = useApp();

  if (!isDrawerOpen) return null;

  const navigateTo = (target: any) => {
    setIsDrawerOpen(false);
    setScreen(target);
  };

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
        onClick={() => setIsDrawerOpen(false)}
      />

      {/* Drawer Panel */}
      <div className="relative w-72 max-w-[80%] h-full bg-[#050e2d] border-r border-[#153477] shadow-2xl flex flex-col z-10 overflow-y-auto">
        {/* Drawer Header */}
        <div className="p-4 bg-gradient-to-b from-[#0a1b4d] to-[#050e2d] border-b border-[#153477]">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <img
                src="/assets/app/panda_head.png"
                alt="Panda"
                className="w-7 h-7 object-cover rounded-full border border-blue-400"
              />
              <span className="font-heading font-black text-sm text-white tracking-wide">
                PANDA APP
              </span>
            </div>
            <button
              onClick={() => setIsDrawerOpen(false)}
              className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-white rounded-lg active:bg-blue-900/30"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center gap-3 mt-2">
            <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-cyan-400 shadow-[0_0_12px_rgba(0,229,255,0.4)]">
              <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
            </div>
            <div>
              <h2 className="text-white font-bold text-sm leading-tight">{user.name}</h2>
              <p className="text-xs text-cyan-300 font-mono">ID: {user.id}</p>
              <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-300">
                <span className="text-emerald-400 font-semibold">৳{user.bdtBalance.toFixed(2)}</span>
                <span>•</span>
                <span className="text-cyan-400 font-semibold">${user.usdBalance.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Links */}
        <div className="flex-1 py-3 px-3 space-y-1">
          <button
            onClick={() => navigateTo('home')}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-blue-900/30 text-sm font-medium transition-colors"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            Home Dashboard
          </button>

          <button
            onClick={() => navigateTo('promotion')}
            className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl bg-gradient-to-r from-cyan-950/70 to-blue-950/70 border border-cyan-500/30 text-cyan-200 hover:text-white hover:bg-blue-900/40 text-sm font-semibold transition-colors"
          >
            <div className="flex items-center gap-3">
              <Rocket className="w-4 h-4 text-cyan-400" />
              <span>Panda Promotion</span>
            </div>
            <span className="text-[10px] bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950 px-1.5 py-0.2 rounded font-extrabold flex items-center gap-0.5">
              <Flame className="w-2.5 h-2.5" /> ৳৫
            </span>
          </button>

          <button
            onClick={() => navigateTo('wallet')}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-blue-900/30 text-sm font-medium transition-colors"
          >
            <Wallet className="w-4 h-4 text-blue-400" />
            My Wallet
          </button>

          <button
            onClick={() => navigateTo('deposit')}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-blue-900/30 text-sm font-medium transition-colors"
          >
            <ArrowDownCircle className="w-4 h-4 text-emerald-400" />
            Deposit (Nagad / Binance)
          </button>

          <button
            onClick={() => navigateTo('withdraw')}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-blue-900/30 text-sm font-medium transition-colors"
          >
            <ArrowUpCircle className="w-4 h-4 text-yellow-400" />
            Withdraw Funds
          </button>

          <button
            onClick={() => navigateTo('ads')}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-blue-900/30 text-sm font-medium transition-colors"
          >
            <Tv className="w-4 h-4 text-orange-400" />
            Watch Ads & Earn
          </button>

          <button
            onClick={() => navigateTo('referral')}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-blue-900/30 text-sm font-medium transition-colors"
          >
            <Share2 className="w-4 h-4 text-purple-400" />
            Refer & Earn
          </button>

          <button
            onClick={() => navigateTo('leaderboard')}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-blue-900/30 text-sm font-medium transition-colors"
          >
            <Trophy className="w-4 h-4 text-yellow-400" />
            Leaderboard
          </button>

          <button
            onClick={() => navigateTo('people')}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-blue-900/30 text-sm font-medium transition-colors"
          >
            <Users className="w-4 h-4 text-cyan-400" />
            Community & Follow
          </button>

          <button
            onClick={() => navigateTo('spin')}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-blue-900/30 text-sm font-medium transition-colors"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            Lucky Spin Wheel
          </button>

          <button
            onClick={() => navigateTo('quiz')}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-blue-900/30 text-sm font-medium transition-colors"
          >
            <Sparkles className="w-4 h-4 text-purple-400" />
            Math Brain Quiz
          </button>

          <button
            onClick={() => navigateTo('profile')}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-blue-900/30 text-sm font-medium transition-colors"
          >
            <User className="w-4 h-4 text-blue-300" />
            My Profile
          </button>

          <button
            onClick={() => navigateTo('admin')}
            className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl bg-red-950/40 border border-red-500/40 text-red-300 hover:text-white hover:bg-red-900/50 text-sm font-semibold transition-colors"
          >
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-4 h-4 text-red-400" />
              <span>Admin Dashboard</span>
            </div>
            <span className="text-[10px] bg-red-500/30 px-1.5 py-0.5 rounded text-red-200 font-mono">
              Portal
            </span>
          </button>

          <button
            onClick={() => navigateTo('apk_guide')}
            className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 hover:text-white hover:bg-emerald-900/50 text-sm font-semibold transition-colors"
          >
            <div className="flex items-center gap-3">
              <Smartphone className="w-4 h-4 text-emerald-400" />
              <span>Android APK Hub</span>
            </div>
            <span className="text-[10px] bg-emerald-500/30 px-1.5 py-0.5 rounded text-emerald-200 font-mono">
              Capacitor
            </span>
          </button>

          <div className="pt-2 border-t border-[#153477] my-2">
            <button
              onClick={() => {
                setIsDrawerOpen(false);
                setIsDesignModalOpen(true);
              }}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-amber-300 hover:bg-amber-500/10 text-sm font-medium transition-colors"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              View Original Design Sheet
            </button>

            <button
              onClick={() => {
                setIsDrawerOpen(false);
                setIsSupportOpen(true);
              }}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-blue-900/30 text-sm font-medium transition-colors"
            >
              <HelpCircle className="w-4 h-4 text-teal-400" />
              24/7 Help & Support
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#153477] bg-[#03081e]">
          <button
            onClick={() => {
              setIsDrawerOpen(false);
              logout();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-red-500/10 text-red-400 hover:bg-red-500/20 text-sm font-medium transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Log Out
          </button>
        </div>
      </div>
    </div>
  );
};
