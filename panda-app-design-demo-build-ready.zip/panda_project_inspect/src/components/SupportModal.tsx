import React from 'react';
import { X, MessageCircle, Send, PhoneCall, HelpCircle, ShieldCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const SupportModal: React.FC = () => {
  const { isSupportOpen, setIsSupportOpen } = useApp();

  if (!isSupportOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="fixed inset-0 bg-black/75 backdrop-blur-sm"
        onClick={() => setIsSupportOpen(false)}
      />
      <div className="relative w-full max-w-sm bg-[#061239] border border-[#1b4396] rounded-2xl p-5 shadow-2xl z-10 max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between pb-3 border-b border-[#153477]">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-cyan-400" />
            <h3 className="font-heading font-bold text-white text-base">24/7 Help & Support</h3>
          </div>
          <button
            onClick={() => setIsSupportOpen(false)}
            className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-white rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-4 space-y-3 overflow-y-auto">
          <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/60 to-emerald-900/40 border border-emerald-500/30 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-white">WhatsApp Live Chat</h4>
              <p className="text-xs text-slate-300">Instant agent support in Bengali & English</p>
            </div>
            <a
              href="https://wa.me/8801700000000"
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 text-xs font-semibold bg-emerald-500 text-black rounded-lg hover:bg-emerald-400 transition-colors"
            >
              Chat
            </a>
          </div>

          <div className="p-3.5 rounded-xl bg-gradient-to-r from-blue-950/60 to-blue-900/40 border border-blue-500/30 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 shrink-0">
              <Send className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-white">Telegram Community</h4>
              <p className="text-xs text-slate-300">@PandaApp_Official Channel & Group</p>
            </div>
            <a
              href="https://t.me/"
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 text-xs font-semibold bg-blue-500 text-white rounded-lg hover:bg-blue-400 transition-colors"
            >
              Join
            </a>
          </div>

          <div className="p-3.5 rounded-xl bg-gradient-to-r from-purple-950/60 to-purple-900/40 border border-purple-500/30 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-400 shrink-0">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-white">Helpline Hotline</h4>
              <p className="text-xs text-slate-300">Available 10:00 AM - 10:00 PM</p>
            </div>
            <span className="text-xs font-mono text-purple-300">09612-PANDA</span>
          </div>

          <div className="p-3 rounded-xl bg-[#091a4f]/70 border border-[#173b88] text-xs text-slate-300 space-y-2">
            <div className="flex items-center gap-2 text-cyan-300 font-semibold">
              <ShieldCheck className="w-4 h-4" />
              Frequently Asked Questions
            </div>
            <p>
              <strong className="text-white">Q: How long does Nagad deposit take?</strong><br />
              A: Automated verification usually completes within 1-5 minutes!
            </p>
            <p>
              <strong className="text-white">Q: What is the minimum withdrawal?</strong><br />
              A: Nagad is ৳100 BDT, Binance Pay is $5 USD.
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsSupportOpen(false)}
          className="w-full mt-2 py-2.5 rounded-xl bg-[#143477] text-white text-xs font-medium hover:bg-[#1a439c] transition-colors"
        >
          Close
        </button>
      </div>
    </div>
  );
};
