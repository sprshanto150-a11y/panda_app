import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  ScreenType,
  UserProfile,
  Transaction,
  Earner,
  AdTask,
  CommunityPost,
  CurrencyType,
  SystemSettings,
  PromotionPackage,
  PromotionPost,
} from '../types';

interface AppContextType {
  screen: ScreenType;
  setScreen: (screen: ScreenType) => void;
  goBack: () => void;
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  isLoggedIn: boolean;
  isAdmin: boolean;
  login: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  loginWithGoogle: () => Promise<void>;
  register: (name: string, phone: string, email: string, pass: string, refCode?: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  transactions: Transaction[];
  addDeposit: (amount: number, method: 'Nagad' | 'Binance', senderAccount: string, trxId?: string) => Promise<{ success: boolean; message: string; error?: string }>;
  addWithdraw: (amount: number, method: 'Nagad' | 'Binance', destinationAccount: string) => Promise<{ success: boolean; message: string }>;
  earners: Earner[];
  earnerPeriod: 'all' | 'weekly' | 'monthly';
  setEarnerPeriod: (period: 'all' | 'weekly' | 'monthly') => void;
  posts: CommunityPost[];
  addPost: (content: string) => Promise<void>;
  toggleLikePost: (id: string) => Promise<void>;
  adTasks: AdTask[];
  watchAd: (adId: string) => Promise<boolean>;
  completeCustomTask: (taskId: string, rewardOverride?: number) => Promise<boolean>;
  toggleFollowUser: () => void;
  isDrawerOpen: boolean;
  setIsDrawerOpen: (open: boolean) => void;
  isNotificationOpen: boolean;
  setIsNotificationOpen: (open: boolean) => void;
  isSupportOpen: boolean;
  setIsSupportOpen: (open: boolean) => void;
  isDesignModalOpen: boolean;
  setIsDesignModalOpen: (open: boolean) => void;
  selectedWalletTab: CurrencyType;
  setSelectedWalletTab: (tab: CurrencyType) => void;
  triggerConfetti: () => void;
  systemSettings: SystemSettings;
  // Admin Methods
  adminAllUsers: UserProfile[];
  adminAllTransactions: Transaction[];
  adminApproveTransaction: (txnId: string) => Promise<boolean>;
  adminRejectTransaction: (txnId: string, reason?: string) => Promise<boolean>;
  adminAdjustBalance: (userId: string, bdtDelta: number, usdDelta: number, note: string) => Promise<boolean>;
  adminToggleBan: (userId: string) => Promise<boolean>;
  adminCreateTask: (task: Partial<AdTask>) => Promise<boolean>;
  refreshAdminData: () => Promise<void>;
  // --- PANDA PROMOTION METHODS & STATE ---
  promotions: PromotionPost[];
  packages: PromotionPackage[];
  myPromotions: PromotionPost[];
  loadPromotionsData: () => Promise<void>;
  createPromotionPost: (content: string, linkType: string, linkUrl: string, linkTitle?: string, mediaUrl?: string) => Promise<{ success: boolean; error?: string; message?: string }>;
  boostPost: (postId: string, packageId: string) => Promise<{ success: boolean; error?: string; message?: string }>;
  trackClick: (postId: string) => Promise<void>;
  trackView: (postId: string) => Promise<void>;
  likePromotionPost: (postId: string) => Promise<void>;
  reportPromotionPost: (postId: string, reason: string) => Promise<{ success: boolean; message: string }>;
  // Admin Promotion Controls
  adminAllPromotions: PromotionPost[];
  adminAllPackages: PromotionPackage[];
  adminApprovePromotion: (id: string) => Promise<boolean>;
  adminRejectPromotion: (id: string, reason?: string) => Promise<boolean>;
  adminTogglePausePromotion: (id: string) => Promise<boolean>;
  adminTogglePinPromotion: (id: string) => Promise<boolean>;
  adminBlockPromotion: (id: string) => Promise<boolean>;
  adminDeletePromotion: (id: string) => Promise<boolean>;
  adminCreatePackage: (pkg: Partial<PromotionPackage>) => Promise<boolean>;
  adminUpdatePackage: (id: string, pkg: Partial<PromotionPackage>) => Promise<boolean>;
  adminTogglePackage: (id: string) => Promise<boolean>;
}

const defaultUser: UserProfile = {
  id: 'PANDA1025',
  name: 'Rahim',
  username: 'rahim_earner',
  email: 'rahim@panda.app',
  phone: '01712345678',
  avatar: '/assets/app/user_rahim.png',
  bdtBalance: 0.0,
  usdBalance: 0.0,
  referralCode: 'PANDA1025',
  role: 'user',
  followers: 120,
  following: 50,
  postsCount: 25,
  isFollowing: false,
};

const defaultSettings: SystemSettings = {
  isSandboxDemoMode: true,
  sandboxNotice: 'DEMO TESTNET ACTIVE: All balances, deposits and withdrawals are test simulations. Real money transfers are strictly disabled until official merchant API keys and server verification are configured.',
  nagadAgentNumber: '01887654321',
  binancePayId: '92817402',
  minDepositBDT: 50,
  maxDepositBDT: 50000,
  minDepositUSD: 5,
  minWithdrawBDT: 100,
  maxWithdrawBDT: 10000,
  minWithdrawUSD: 5,
};

const defaultTransactions: Transaction[] = [
  {
    id: 'TXN-101',
    type: 'deposit',
    title: 'Deposit (Nagad)',
    method: 'Nagad',
    amount: 500,
    currency: 'BDT',
    status: 'Pending',
    timestamp: 'Today, 2:30 PM',
    accountNumber: '01887654321',
    trxId: '9J8A7K6L5M',
    isSandboxDemo: true,
  },
  {
    id: 'TXN-102',
    type: 'referral',
    title: 'Referral Reward',
    method: 'System',
    amount: 50,
    currency: 'BDT',
    status: 'Completed',
    timestamp: 'Yesterday, 8:15 PM',
    reference: 'New member join bonus: Sakib',
    isSandboxDemo: true,
  },
  {
    id: 'TXN-103',
    type: 'withdraw',
    title: 'Withdraw to Nagad',
    method: 'Nagad',
    amount: 200,
    currency: 'BDT',
    status: 'Approved',
    timestamp: 'Nov 05, 11:40 AM',
    accountNumber: '01712345678',
    trxId: '8H7G6F5D4S',
    isSandboxDemo: true,
  },
  {
    id: 'TXN-104',
    type: 'ads_reward',
    title: 'Ad Video Bonus',
    method: 'Task',
    amount: 10,
    currency: 'BDT',
    status: 'Completed',
    timestamp: 'Nov 04, 04:20 PM',
    isSandboxDemo: true,
  },
];

const allTimeEarners: Earner[] = [
  { rank: 1, id: 'PANDA1025', name: 'Rahim', earningsBDT: 5000, avatar: '/assets/app/user_rahim.png', isCurrentUser: true, badge: 'gold' },
  { rank: 2, id: 'PANDA1011', name: 'Karim', earningsBDT: 3500, avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80', badge: 'silver' },
  { rank: 3, id: 'PANDA1088', name: 'Asif', earningsBDT: 2000, avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=120&auto=format&fit=crop&q=80', badge: 'bronze' },
  { rank: 4, id: 'PANDA1042', name: 'Hasan', earningsBDT: 1800, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80' },
  { rank: 5, id: 'PANDA1093', name: 'Rifat', earningsBDT: 1500, avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80' },
  { rank: 6, id: 'PANDA1055', name: 'Sakib', earningsBDT: 1200, avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=120&auto=format&fit=crop&q=80' },
  { rank: 7, id: 'PANDA1067', name: 'Minhaz', earningsBDT: 1000, avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=120&auto=format&fit=crop&q=80' },
  { rank: 8, id: 'PANDA1074', name: 'Tanvir', earningsBDT: 900, avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80' },
];

const weeklyEarners: Earner[] = [
  { rank: 1, id: 'PANDA1011', name: 'Karim', earningsBDT: 1850, avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80', badge: 'gold' },
  { rank: 2, id: 'PANDA1025', name: 'Rahim', earningsBDT: 1400, avatar: '/assets/app/user_rahim.png', isCurrentUser: true, badge: 'silver' },
  { rank: 3, id: 'PANDA1042', name: 'Hasan', earningsBDT: 950, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80', badge: 'bronze' },
  { rank: 4, id: 'PANDA1088', name: 'Asif', earningsBDT: 820, avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=120&auto=format&fit=crop&q=80' },
];

const monthlyEarners: Earner[] = [
  { rank: 1, id: 'PANDA1025', name: 'Rahim', earningsBDT: 4200, avatar: '/assets/app/user_rahim.png', isCurrentUser: true, badge: 'gold' },
  { rank: 2, id: 'PANDA1011', name: 'Karim', earningsBDT: 3100, avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80', badge: 'silver' },
  { rank: 3, id: 'PANDA1088', name: 'Asif', earningsBDT: 1850, avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=120&auto=format&fit=crop&q=80', badge: 'bronze' },
];

const defaultPromotionPackages: PromotionPackage[] = [
  {
    id: 'PKG-7D-5TK',
    name: 'Starter Boost (7 Days)',
    durationDays: 7,
    priceBDT: 5,
    priceUSD: 0.05,
    estimatedReach: '1,500 - 3,500 Targeted Views',
    badgeText: 'Most Popular',
    features: ['7 Days Active Promotion', 'Promoted / Sponsored Glow Badge', 'Verified Click Tracking', 'Public Feed Showcase'],
    isActive: true,
  },
  {
    id: 'PKG-14D-10TK',
    name: 'Growth Boost (14 Days)',
    durationDays: 14,
    priceBDT: 10,
    priceUSD: 0.10,
    estimatedReach: '5,000 - 10,000 Targeted Views',
    badgeText: 'Best Value',
    features: ['14 Days Active Promotion', 'Priority Feed Placement', 'High Click-Through Rate', 'Live Views & Clicks Analytics'],
    isActive: true,
  },
  {
    id: 'PKG-30D-20TK',
    name: 'Viral King Boost (30 Days)',
    durationDays: 30,
    priceBDT: 20,
    priceUSD: 0.20,
    estimatedReach: '15,000 - 35,000 Targeted Views',
    badgeText: 'VIP Viral',
    features: ['30 Days Unlimited Boost', 'Pinned Near Top of Feed', 'VIP Sponsored Crown Accent', 'Website / YouTube / Facebook Tracking'],
    isActive: true,
  },
];

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [screen, setScreenState] = useState<ScreenType>('home');
  const [screenHistory, setScreenHistory] = useState<ScreenType[]>(['home']);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
  const [systemSettings] = useState<SystemSettings>(defaultSettings);

  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('panda_user');
      return saved ? JSON.parse(saved) : defaultUser;
    } catch {
      return defaultUser;
    }
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem('panda_transactions');
      return saved ? JSON.parse(saved) : defaultTransactions;
    } catch {
      return defaultTransactions;
    }
  });

  const [adTasks, setAdTasks] = useState<AdTask[]>([]);
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [earnerPeriod, setEarnerPeriod] = useState<'all' | 'weekly' | 'monthly'>('all');
  const [selectedWalletTab, setSelectedWalletTab] = useState<CurrencyType>('BDT');

  // Panda Promotion state
  const [promotions, setPromotions] = useState<PromotionPost[]>([]);
  const [packages, setPackages] = useState<PromotionPackage[]>(defaultPromotionPackages);
  const [myPromotions, setMyPromotions] = useState<PromotionPost[]>([]);
  const [adminAllPromotions, setAdminAllPromotions] = useState<PromotionPost[]>([]);
  const [adminAllPackages, setAdminAllPackages] = useState<PromotionPackage[]>(defaultPromotionPackages);

  // Admin state
  const [adminAllUsers, setAdminAllUsers] = useState<UserProfile[]>([]);
  const [adminAllTransactions, setAdminAllTransactions] = useState<Transaction[]>([]);

  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [isDesignModalOpen, setIsDesignModalOpen] = useState(false);

  const triggerConfetti = () => {
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#00e5ff', '#0062ff', '#f0b90b', '#00c853', '#ffffff'],
      });
    } catch {}
  };

  const loadPromotionsData = async () => {
    try {
      const [feedRes, pkgRes, myRes] = await Promise.all([
        fetch('/api/promotions/feed'),
        fetch('/api/promotions/packages'),
        fetch(`/api/promotions/my-promotions?userId=${user.id}`),
      ]);
      if (feedRes.ok) setPromotions(await feedRes.json());
      if (pkgRes.ok) setPackages(await pkgRes.json());
      if (myRes.ok) setMyPromotions(await myRes.json());
    } catch {}
  };

  // Sync to API on mount and fetch tasks & transactions
  const loadInitialData = async () => {
    try {
      // 1. Fetch user data
      const meRes = await fetch(`/api/auth/me?userId=${user.id}`);
      if (meRes.ok) {
        const meData = await meRes.json();
        setUser((prev) => ({ ...prev, ...meData }));
      }

      // 2. Fetch transactions
      const txRes = await fetch(`/api/wallet/transactions?userId=${user.id}`);
      if (txRes.ok) {
        const txData = await txRes.json();
        if (Array.isArray(txData)) {
          setTransactions(txData);
        }
      }

      // 3. Fetch tasks
      const taskRes = await fetch(`/api/tasks?userId=${user.id}`);
      if (taskRes.ok) {
        const taskData = await taskRes.json();
        if (Array.isArray(taskData)) {
          setAdTasks(taskData);
        }
      }

      // 4. Fetch community posts
      const postRes = await fetch('/api/posts');
      if (postRes.ok) {
        const postData = await postRes.json();
        if (Array.isArray(postData)) {
          setPosts(postData);
        }
      }

      // 5. Fetch Panda Promotions feed
      await loadPromotionsData();
    } catch {
      // Offline fallback
    }
  };

  useEffect(() => {
    loadInitialData();
  }, [user.id]);

  useEffect(() => {
    localStorage.setItem('panda_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('panda_transactions', JSON.stringify(transactions));
  }, [transactions]);

  const setScreen = (newScreen: ScreenType) => {
    setScreenState(newScreen);
    setScreenHistory((prev) => [...prev, newScreen]);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goBack = () => {
    if (screenHistory.length > 1) {
      const newHistory = [...screenHistory];
      newHistory.pop();
      const prev = newHistory[newHistory.length - 1];
      setScreenHistory(newHistory);
      setScreenState(prev || 'home');
    } else {
      setScreenState('home');
    }
  };

  const login = async (emailOrUsername: string, pass: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emailOrUsername, password: pass }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Login failed' };
      }
      setUser(data.user);
      setIsLoggedIn(true);
      triggerConfetti();
      setScreen(data.user.role === 'admin' ? 'admin' : 'home');
      return { success: true };
    } catch {
      setIsLoggedIn(true);
      setScreen('home');
      return { success: true };
    }
  };

  const loginWithGoogle = async () => {
    try {
      const res = await fetch('/api/auth/google', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      }
    } catch {}
    setIsLoggedIn(true);
    triggerConfetti();
    setScreen('home');
  };

  const register = async (name: string, phone: string, email: string, pass: string, refCode?: string) => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, phone, email, password: pass, referralCode: refCode }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Registration failed' };
      }
      setUser(data.user);
      setIsLoggedIn(true);
      triggerConfetti();
      setScreen('home');
      return { success: true };
    } catch {
      const newUser: UserProfile = {
        ...defaultUser,
        id: 'PANDA' + Math.floor(1000 + Math.random() * 9000),
        name: name.trim() || 'New Earner',
        phone: phone.trim() || '01700000000',
        email: email.trim() || 'user@panda.app',
        referredBy: refCode || undefined,
        bdtBalance: 0.0,
        usdBalance: 0.0,
      };
      setUser(newUser);
      setIsLoggedIn(true);
      triggerConfetti();
      setScreen('home');
      return { success: true };
    }
  };

  const logout = () => {
    setIsLoggedIn(false);
    setScreen('login');
  };

  const addDeposit = async (amount: number, method: 'Nagad' | 'Binance', senderAccount: string, trxId?: string) => {
    try {
      const res = await fetch('/api/wallet/deposit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, amount, method, accountNumber: senderAccount, trxId }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, message: data.error || 'Deposit error', error: data.error };
      }

      setTransactions((prev) => [data.transaction, ...prev]);

      // Sandbox auto-approval demo simulation
      setTimeout(() => {
        setTransactions((prev) =>
          prev.map((t) => (t.id === data.transaction.id ? { ...t, status: 'Completed' } : t))
        );
        setUser((prev) => ({
          ...prev,
          bdtBalance: method === 'Nagad' ? prev.bdtBalance + amount : prev.bdtBalance,
          usdBalance: method === 'Binance' ? prev.usdBalance + amount : prev.usdBalance,
        }));
        triggerConfetti();
      }, 4000);

      return { success: true, message: data.message };
    } catch {
      const isBDT = method === 'Nagad';
      const newTxn: Transaction = {
        id: 'TXN-' + Math.floor(1000 + Math.random() * 9000),
        type: 'deposit',
        title: isBDT ? 'Deposit (Nagad)' : 'Deposit (Binance)',
        method,
        amount,
        currency: isBDT ? 'BDT' : 'USD',
        status: 'Pending',
        timestamp: 'Just now',
        accountNumber: senderAccount,
        trxId: trxId || (isBDT ? 'NGD' : 'BIN') + Math.floor(100000 + Math.random() * 900000),
        isSandboxDemo: true,
      };
      setTransactions((prev) => [newTxn, ...prev]);
      return { success: true, message: 'Deposit recorded (Sandbox Mode)' };
    }
  };

  const addWithdraw = async (
    amount: number,
    method: 'Nagad' | 'Binance',
    destinationAccount: string
  ): Promise<{ success: boolean; message: string }> => {
    try {
      const res = await fetch('/api/wallet/withdraw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, amount, method, destinationAccount }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, message: data.error || 'Withdrawal failed' };
      }

      setTransactions((prev) => [data.transaction, ...prev]);
      if (method === 'Nagad') {
        setUser((prev) => ({ ...prev, bdtBalance: prev.bdtBalance - amount }));
      } else {
        setUser((prev) => ({ ...prev, usdBalance: prev.usdBalance - amount }));
      }

      triggerConfetti();
      return { success: true, message: data.message };
    } catch {
      const isBDT = method === 'Nagad';
      if (isBDT && user.bdtBalance < amount) {
        return { success: false, message: 'Insufficient BDT balance' };
      }
      if (!isBDT && user.usdBalance < amount) {
        return { success: false, message: 'Insufficient USD balance' };
      }

      setUser((prev) => ({
        ...prev,
        bdtBalance: isBDT ? prev.bdtBalance - amount : prev.bdtBalance,
        usdBalance: !isBDT ? prev.usdBalance - amount : prev.usdBalance,
      }));

      const newTxn: Transaction = {
        id: 'TXN-' + Math.floor(1000 + Math.random() * 9000),
        type: 'withdraw',
        title: isBDT ? 'Withdraw to Nagad' : 'Withdraw to Binance',
        method,
        amount,
        currency: isBDT ? 'BDT' : 'USD',
        status: 'Approved',
        timestamp: 'Just now',
        accountNumber: destinationAccount,
        isSandboxDemo: true,
      };
      setTransactions((prev) => [newTxn, ...prev]);
      triggerConfetti();
      return { success: true, message: `Withdrawal of ${isBDT ? '৳' + amount : '$' + amount} approved in sandbox mode!` };
    }
  };

  const watchAd = async (adId: string): Promise<boolean> => {
    return completeCustomTask(adId);
  };

  const completeCustomTask = async (taskId: string, rewardOverride?: number): Promise<boolean> => {
    try {
      const res = await fetch('/api/tasks/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, taskId, customBonus: rewardOverride }),
      });
      const data = await res.json();
      if (res.ok) {
        setUser((prev) => ({
          ...prev,
          bdtBalance: data.newBdtBalance,
          usdBalance: data.newUsdBalance,
        }));
        setAdTasks((prev) =>
          prev.map((t) => (t.id === taskId ? { ...t, watched: true, completedToday: true } : t))
        );
        triggerConfetti();
        return true;
      }
    } catch {}

    const task = adTasks.find((t) => t.id === taskId);
    if (!task) return false;
    const reward = rewardOverride || task.rewardAmount;
    if (task.currency === 'BDT') {
      setUser((prev) => ({ ...prev, bdtBalance: prev.bdtBalance + reward }));
    } else {
      setUser((prev) => ({ ...prev, usdBalance: prev.usdBalance + reward }));
    }
    triggerConfetti();
    return true;
  };

  const addPost = async (content: string) => {
    try {
      const res = await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, content }),
      });
      if (res.ok) {
        const data = await res.json();
        setPosts((prev) => [data.post, ...prev]);
        setUser((prev) => ({ ...prev, postsCount: prev.postsCount + 1 }));
        return;
      }
    } catch {}

    const newPost: CommunityPost = {
      id: 'post-' + Date.now(),
      authorId: user.id,
      authorName: user.name,
      authorAvatar: user.avatar,
      content,
      timeAgo: 'Just now',
      likes: 1,
      isLiked: true,
      tag: 'Member Update',
    };
    setPosts((prev) => [newPost, ...prev]);
    setUser((prev) => ({ ...prev, postsCount: prev.postsCount + 1 }));
  };

  const toggleLikePost = async (id: string) => {
    try {
      const res = await fetch(`/api/posts/${id}/like`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id }),
      });
      if (res.ok) {
        const data = await res.json();
        setPosts((prev) =>
          prev.map((p) => (p.id === id ? { ...p, likes: data.likes, isLiked: data.isLiked } : p))
        );
        return;
      }
    } catch {}

    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          return {
            ...p,
            isLiked: !p.isLiked,
            likes: p.isLiked ? p.likes - 1 : p.likes + 1,
          };
        }
        return p;
      })
    );
  };

  const toggleFollowUser = () => {
    setUser((prev) => {
      const isNowFollowing = !prev.isFollowing;
      return {
        ...prev,
        isFollowing: isNowFollowing,
        followers: isNowFollowing ? prev.followers + 1 : prev.followers - 1,
      };
    });
  };

  // --- PANDA PROMOTION CLIENT METHODS ---
  const createPromotionPost = async (
    content: string,
    linkType: string,
    linkUrl: string,
    linkTitle?: string,
    mediaUrl?: string
  ): Promise<{ success: boolean; error?: string; message?: string }> => {
    try {
      const res = await fetch('/api/promotions/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          content,
          linkType,
          linkUrl,
          linkTitle,
          mediaUrl,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Failed to publish post' };
      }
      await loadPromotionsData();
      triggerConfetti();
      return { success: true, message: data.message };
    } catch {
      return { success: false, error: 'Network error publishing post' };
    }
  };

  const boostPost = async (
    postId: string,
    packageId: string
  ): Promise<{ success: boolean; error?: string; message?: string }> => {
    try {
      const res = await fetch('/api/promotions/boost', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, postId, packageId }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Failed to boost post' };
      }
      setUser((prev) => ({ ...prev, bdtBalance: data.newBdtBalance }));
      await loadPromotionsData();
      await loadInitialData();
      triggerConfetti();
      return { success: true, message: data.message };
    } catch {
      return { success: false, error: 'Network error boosting post' };
    }
  };

  const trackClick = async (postId: string) => {
    try {
      await fetch(`/api/promotions/posts/${postId}/click`, { method: 'POST' });
    } catch {}
  };

  const trackView = async (postId: string) => {
    try {
      await fetch(`/api/promotions/posts/${postId}/view`, { method: 'POST' });
    } catch {}
  };

  const likePromotionPost = async (postId: string) => {
    try {
      const res = await fetch(`/api/promotions/posts/${postId}/like`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id }),
      });
      if (res.ok) {
        const data = await res.json();
        setPromotions((prev) =>
          prev.map((p) =>
            p.id === postId ? { ...p, likesCount: data.likesCount, likedBy: data.isLiked ? [...p.likedBy, user.id] : p.likedBy.filter((u) => u !== user.id) } : p
          )
        );
      }
    } catch {}
  };

  const reportPromotionPost = async (postId: string, reason: string): Promise<{ success: boolean; message: string }> => {
    try {
      const res = await fetch(`/api/promotions/posts/${postId}/report`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, reason }),
      });
      const data = await res.json();
      return { success: res.ok, message: data.message || 'Report submitted' };
    } catch {
      return { success: false, message: 'Failed to report' };
    }
  };

  // Admin Methods
  const refreshAdminData = async () => {
    try {
      const [usersRes, txRes, promRes, pkgRes] = await Promise.all([
        fetch('/api/admin/users'),
        fetch('/api/admin/transactions'),
        fetch('/api/admin/promotions'),
        fetch('/api/admin/packages'),
      ]);
      if (usersRes.ok) setAdminAllUsers(await usersRes.json());
      if (txRes.ok) setAdminAllTransactions(await txRes.json());
      if (promRes.ok) setAdminAllPromotions(await promRes.json());
      if (pkgRes.ok) setAdminAllPackages(await pkgRes.json());
    } catch {}
  };

  const adminApproveTransaction = async (txnId: string) => {
    try {
      const res = await fetch(`/api/admin/transactions/${txnId}/approve`, { method: 'POST' });
      if (res.ok) {
        await refreshAdminData();
        await loadInitialData();
        triggerConfetti();
        return true;
      }
    } catch {}
    return false;
  };

  const adminRejectTransaction = async (txnId: string, reason?: string) => {
    try {
      const res = await fetch(`/api/admin/transactions/${txnId}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason }),
      });
      if (res.ok) {
        await refreshAdminData();
        await loadInitialData();
        return true;
      }
    } catch {}
    return false;
  };

  const adminAdjustBalance = async (userId: string, bdtDelta: number, usdDelta: number, note: string) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}/adjust-balance`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bdtDelta, usdDelta, note }),
      });
      if (res.ok) {
        await refreshAdminData();
        await loadInitialData();
        triggerConfetti();
        return true;
      }
    } catch {}
    return false;
  };

  const adminToggleBan = async (userId: string) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}/toggle-ban`, { method: 'POST' });
      if (res.ok) {
        await refreshAdminData();
        return true;
      }
    } catch {}
    return false;
  };

  const adminCreateTask = async (task: Partial<AdTask>) => {
    try {
      const res = await fetch('/api/admin/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(task),
      });
      if (res.ok) {
        await loadInitialData();
        triggerConfetti();
        return true;
      }
    } catch {}
    return false;
  };

  // Admin Promotion Handlers
  const adminApprovePromotion = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/promotions/${id}/approve`, { method: 'POST' });
      if (res.ok) {
        await refreshAdminData();
        await loadPromotionsData();
        triggerConfetti();
        return true;
      }
    } catch {}
    return false;
  };

  const adminRejectPromotion = async (id: string, reason?: string) => {
    try {
      const res = await fetch(`/api/admin/promotions/${id}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason }),
      });
      if (res.ok) {
        await refreshAdminData();
        await loadPromotionsData();
        return true;
      }
    } catch {}
    return false;
  };

  const adminTogglePausePromotion = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/promotions/${id}/toggle-pause`, { method: 'POST' });
      if (res.ok) {
        await refreshAdminData();
        await loadPromotionsData();
        return true;
      }
    } catch {}
    return false;
  };

  const adminTogglePinPromotion = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/promotions/${id}/toggle-pin`, { method: 'POST' });
      if (res.ok) {
        await refreshAdminData();
        await loadPromotionsData();
        triggerConfetti();
        return true;
      }
    } catch {}
    return false;
  };

  const adminBlockPromotion = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/promotions/${id}/block`, { method: 'POST' });
      if (res.ok) {
        await refreshAdminData();
        await loadPromotionsData();
        return true;
      }
    } catch {}
    return false;
  };

  const adminDeletePromotion = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/promotions/${id}`, { method: 'DELETE' });
      if (res.ok) {
        await refreshAdminData();
        await loadPromotionsData();
        return true;
      }
    } catch {}
    return false;
  };

  const adminCreatePackage = async (pkg: Partial<PromotionPackage>) => {
    try {
      const res = await fetch('/api/admin/packages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pkg),
      });
      if (res.ok) {
        await refreshAdminData();
        await loadPromotionsData();
        triggerConfetti();
        return true;
      }
    } catch {}
    return false;
  };

  const adminUpdatePackage = async (id: string, pkg: Partial<PromotionPackage>) => {
    try {
      const res = await fetch(`/api/admin/packages/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pkg),
      });
      if (res.ok) {
        await refreshAdminData();
        await loadPromotionsData();
        triggerConfetti();
        return true;
      }
    } catch {}
    return false;
  };

  const adminTogglePackage = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/packages/${id}/toggle`, { method: 'POST' });
      if (res.ok) {
        await refreshAdminData();
        await loadPromotionsData();
        return true;
      }
    } catch {}
    return false;
  };

  const currentEarners =
    earnerPeriod === 'weekly' ? weeklyEarners : earnerPeriod === 'monthly' ? monthlyEarners : allTimeEarners;

  return (
    <AppContext.Provider
      value={{
        screen,
        setScreen,
        goBack,
        user,
        setUser,
        isLoggedIn,
        isAdmin: user.role === 'admin',
        login,
        loginWithGoogle,
        register,
        logout,
        transactions,
        addDeposit,
        addWithdraw,
        earners: currentEarners,
        earnerPeriod,
        setEarnerPeriod,
        posts,
        addPost,
        toggleLikePost,
        adTasks,
        watchAd,
        completeCustomTask,
        toggleFollowUser,
        isDrawerOpen,
        setIsDrawerOpen,
        isNotificationOpen,
        setIsNotificationOpen,
        isSupportOpen,
        setIsSupportOpen,
        isDesignModalOpen,
        setIsDesignModalOpen,
        selectedWalletTab,
        setSelectedWalletTab,
        triggerConfetti,
        systemSettings,
        adminAllUsers,
        adminAllTransactions,
        adminApproveTransaction,
        adminRejectTransaction,
        adminAdjustBalance,
        adminToggleBan,
        adminCreateTask,
        refreshAdminData,
        // Panda Promotion
        promotions,
        packages,
        myPromotions,
        loadPromotionsData,
        createPromotionPost,
        boostPost,
        trackClick,
        trackView,
        likePromotionPost,
        reportPromotionPost,
        adminAllPromotions,
        adminAllPackages,
        adminApprovePromotion,
        adminRejectPromotion,
        adminTogglePausePromotion,
        adminTogglePinPromotion,
        adminBlockPromotion,
        adminDeletePromotion,
        adminCreatePackage,
        adminUpdatePackage,
        adminTogglePackage,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
