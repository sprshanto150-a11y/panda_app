import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Users,
  CheckCircle,
  XCircle,
  PlusCircle,
  Settings,
  DollarSign,
  TrendingUp,
  RefreshCw,
  Search,
  Check,
  AlertTriangle,
  Lock,
  Rocket,
  Flame,
  Pin,
  Pause,
  Play,
  Trash2,
  Ban,
  ExternalLink,
  Sparkles,
  Zap,
  Globe,
  Tag,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Transaction, UserProfile, AdTask, PromotionPackage, PromotionPost } from '../types';

export const AdminScreen: React.FC = () => {
  const {
    adminAllUsers,
    adminAllTransactions,
    adminApproveTransaction,
    adminRejectTransaction,
    adminAdjustBalance,
    adminToggleBan,
    adminCreateTask,
    refreshAdminData,
    systemSettings,
    adminAllPromotions,
    adminAllPackages,
    adminApprovePromotion,
    adminRejectPromotion,
    adminTogglePausePromotion,
    adminTogglePinPromotion,
    adminBlockPromotion,
    adminDeletePromotion,
    adminCreatePackage,
    adminUpdatePackage,
    adminTogglePackage,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'overview' | 'txns' | 'users' | 'promotions' | 'packages' | 'tasks'>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [isProcessing, setIsProcessing] = useState<string | null>(null);

  // New Package form state
  const [pkgName, setPkgName] = useState('');
  const [pkgDuration, setPkgDuration] = useState('7');
  const [pkgPriceBdt, setPkgPriceBdt] = useState('5');
  const [pkgPriceUsd, setPkgPriceUsd] = useState('0.05');
  const [pkgReach, setPkgReach] = useState('5,000+ Users');
  const [pkgFeatures, setPkgFeatures] = useState('Sponsored Badge, Top Feed Priority, Click Tracking');
  const [isCreatingPkg, setIsCreatingPkg] = useState(false);
  const [pkgSuccessMsg, setPkgSuccessMsg] = useState(false);

  // Balance adjustment modal state
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [adjustBdt, setAdjustBdt] = useState('100');
  const [adjustUsd, setAdjustUsd] = useState('0');
  const [adjustNote, setAdjustNote] = useState('Admin test credit');

  // New task form state
  const [taskTitle, setTaskTitle] = useState('');
  const [taskType, setTaskType] = useState<'video_ad' | 'spin_wheel' | 'math_quiz' | 'social_task'>('video_ad');
  const [taskReward, setTaskReward] = useState('15');
  const [taskCurrency, setTaskCurrency] = useState<'BDT' | 'USD'>('BDT');
  const [taskCategory, setTaskCategory] = useState('Special Offer');
  const [taskCreatedSuccess, setTaskCreatedSuccess] = useState(false);

  useEffect(() => {
    refreshAdminData();
  }, []);

  const pendingTxns = adminAllTransactions.filter((t) => t.status === 'Pending');
  const totalUsers = adminAllUsers.length;
  const totalBdtLiability = adminAllUsers.reduce((sum, u) => sum + (u.bdtBalance || 0), 0);
  const totalUsdLiability = adminAllUsers.reduce((sum, u) => sum + (u.usdBalance || 0), 0);

  const handleApprove = async (id: string) => {
    setIsProcessing(id);
    await adminApproveTransaction(id);
    setIsProcessing(null);
  };

  const handleReject = async (id: string) => {
    setIsProcessing(id);
    await adminRejectTransaction(id, 'Invalid payment reference (Admin review)');
    setIsProcessing(null);
  };

  const handleSaveBalanceAdjustment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) return;
    await adminAdjustBalance(
      selectedUser.id,
      parseFloat(adjustBdt) || 0,
      parseFloat(adjustUsd) || 0,
      adjustNote
    );
    setSelectedUser(null);
  };

  const handleCreateNewTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim() || !taskReward) return;

    const success = await adminCreateTask({
      title: taskTitle.trim(),
      type: taskType,
      rewardAmount: parseFloat(taskReward),
      currency: taskCurrency,
      category: taskCategory,
      sponsor: 'Panda Partner Network',
      durationSec: 10,
      isActive: true,
    });

    if (success) {
      setTaskCreatedSuccess(true);
      setTaskTitle('');
      setTimeout(() => setTaskCreatedSuccess(false), 2000);
    }
  };

  const handleCreatePackage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pkgName.trim()) return;
    setIsCreatingPkg(true);
    const success = await adminCreatePackage({
      name: pkgName.trim(),
      durationDays: parseInt(pkgDuration) || 7,
      priceBDT: parseFloat(pkgPriceBdt) || 5,
      priceUSD: parseFloat(pkgPriceUsd) || 0.05,
      estimatedReach: pkgReach.trim() || '5,000+ Users',
      features: pkgFeatures.split(',').map((s) => s.trim()).filter(Boolean),
      isActive: true,
    });
    setIsCreatingPkg(false);
    if (success) {
      setPkgSuccessMsg(true);
      setPkgName('');
      setTimeout(() => setPkgSuccessMsg(false), 2000);
    }
  };

  return (
    <div className="px-4 py-4 space-y-4 pb-20 select-none">
      {/* Admin Header with Sandbox Notice */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-red-950/60 via-[#1a0826] to-[#0a1438] border border-red-500/40 shadow-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-red-500/20 border border-red-400 flex items-center justify-center text-red-400 shrink-0">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-heading font-black text-base text-white">Admin Control Portal</h2>
            <p className="text-[11px] text-amber-300 font-medium">
              Sandbox Testnet Mode: All balances & gateways simulated
            </p>
          </div>
        </div>

        <button
          onClick={refreshAdminData}
          className="p-2 rounded-xl bg-blue-900/40 border border-blue-500/30 text-slate-300 hover:text-white"
          title="Refresh Data"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* Admin Sub-navigation Tabs */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-1 p-1 bg-[#06143b] border border-[#163884] rounded-2xl text-[11px] font-bold">
        <button
          onClick={() => setActiveTab('overview')}
          className={`py-2 px-1 rounded-xl transition-all ${
            activeTab === 'overview' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white'
          }`}
        >
          Overview
        </button>
        <button
          onClick={() => setActiveTab('txns')}
          className={`py-2 px-1 rounded-xl relative transition-all ${
            activeTab === 'txns' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white'
          }`}
        >
          Approvals
          {pendingTxns.length > 0 && (
            <span className="ml-1 px-1.5 py-0.2 rounded-full bg-red-500 text-white text-[9px]">
              {pendingTxns.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('promotions')}
          className={`py-2 px-1 rounded-xl relative transition-all flex items-center justify-center gap-1 ${
            activeTab === 'promotions' ? 'bg-cyan-600 text-white' : 'text-slate-300 hover:text-white'
          }`}
        >
          <Rocket className="w-3 h-3" />
          <span>Promos</span>
          {adminAllPromotions.filter((p) => p.promotionStatus === 'pending_approval').length > 0 && (
            <span className="ml-0.5 px-1 py-0.2 rounded-full bg-amber-400 text-slate-950 font-extrabold text-[9px]">
              {adminAllPromotions.filter((p) => p.promotionStatus === 'pending_approval').length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('packages')}
          className={`py-2 px-1 rounded-xl transition-all flex items-center justify-center gap-1 ${
            activeTab === 'packages' ? 'bg-cyan-600 text-white' : 'text-slate-300 hover:text-white'
          }`}
        >
          <Zap className="w-3 h-3 text-amber-300" />
          <span>Packages</span>
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`py-2 px-1 rounded-xl transition-all ${
            activeTab === 'users' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white'
          }`}
        >
          Users
        </button>
        <button
          onClick={() => setActiveTab('tasks')}
          className={`py-2 px-1 rounded-xl transition-all ${
            activeTab === 'tasks' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white'
          }`}
        >
          Add Task
        </button>
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3.5 rounded-2xl bg-[#07143e]/90 border border-[#163884]">
              <div className="text-slate-400 text-[11px] font-medium flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-blue-400" />
                <span>Total Users</span>
              </div>
              <div className="text-xl font-heading font-black text-white mt-1 tabular-nums">
                {totalUsers}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#07143e]/90 border border-amber-500/30">
              <div className="text-slate-400 text-[11px] font-medium flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                <span>Pending Approvals</span>
              </div>
              <div className="text-xl font-heading font-black text-amber-300 mt-1 tabular-nums">
                {pendingTxns.length}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#07143e]/90 border border-emerald-500/30">
              <div className="text-slate-400 text-[11px] font-medium flex items-center gap-1.5">
                <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                <span>Total Demo BDT</span>
              </div>
              <div className="text-lg font-heading font-black text-emerald-400 mt-1 tabular-nums">
                ৳{totalBdtLiability.toLocaleString()}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#07143e]/90 border border-cyan-500/30">
              <div className="text-slate-400 text-[11px] font-medium flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
                <span>Total Demo USD</span>
              </div>
              <div className="text-lg font-heading font-black text-cyan-300 mt-1 tabular-nums">
                ${totalUsdLiability.toFixed(2)}
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-[#07143e]/90 border border-[#163884] space-y-2">
            <h3 className="font-heading font-bold text-xs text-white uppercase tracking-wider">
              Payment Gateway Safety Enforcer
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              {systemSettings.sandboxNotice}
            </p>
            <div className="pt-2 flex items-center gap-2 text-xs text-emerald-400 font-mono">
              <Lock className="w-3.5 h-3.5" />
              <span>Real merchant credentials locked until server verification.</span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: TRANSACTION APPROVALS */}
      {activeTab === 'txns' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-heading font-bold text-sm text-white">
              Transactions & Approvals ({adminAllTransactions.length})
            </h3>
            <span className="text-xs text-amber-300 font-mono">{pendingTxns.length} Pending</span>
          </div>

          {adminAllTransactions.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-400">No transactions recorded yet.</div>
          ) : (
            <div className="space-y-2.5">
              {adminAllTransactions.map((tx) => (
                <div
                  key={tx.id}
                  className="p-3.5 rounded-2xl bg-[#07143e]/90 border border-[#163884] space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-white block">{tx.title}</span>
                      <span className="text-[10px] text-cyan-300 font-mono">
                        User: {tx.userName || tx.userId} • Trx: {tx.trxId || tx.id}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-heading font-black text-[#ffcc00] tabular-nums block">
                        {tx.currency === 'BDT' ? `৳${tx.amount}` : `$${tx.amount}`}
                      </span>
                      <span
                        className={`text-[10px] font-bold ${
                          tx.status === 'Completed' || tx.status === 'Approved'
                            ? 'text-emerald-400'
                            : tx.status === 'Pending'
                            ? 'text-amber-400'
                            : 'text-red-400'
                        }`}
                      >
                        {tx.status}
                      </span>
                    </div>
                  </div>

                  {tx.accountNumber && (
                    <div className="text-[11px] text-slate-300 bg-[#061233] p-1.5 rounded-lg font-mono">
                      Account: {tx.accountNumber}
                    </div>
                  )}

                  {/* Actions for Pending */}
                  {tx.status === 'Pending' && (
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => handleApprove(tx.id)}
                        disabled={isProcessing === tx.id}
                        className="flex-1 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1 shadow-md shadow-emerald-600/30"
                      >
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Approve</span>
                      </button>

                      <button
                        onClick={() => handleReject(tx.id)}
                        disabled={isProcessing === tx.id}
                        className="flex-1 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center justify-center gap-1 shadow-md shadow-red-600/30"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Reject</span>
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: USER MANAGEMENT */}
      {activeTab === 'users' && (
        <div className="space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute top-3 left-3 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search user by name or ID..."
              className="w-full pl-9 pr-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs placeholder-slate-400 focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div className="space-y-2">
            {adminAllUsers
              .filter(
                (u) =>
                  u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                  u.id.toLowerCase().includes(searchQuery.toLowerCase())
              )
              .map((u) => (
                <div
                  key={u.id}
                  className="p-3 rounded-2xl bg-[#07143e]/90 border border-[#163884] flex items-center justify-between"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-white">{u.name}</span>
                      <span className="text-[10px] text-cyan-300 font-mono">({u.id})</span>
                      {u.isBanned && (
                        <span className="text-[9px] bg-red-500/20 text-red-400 px-1 rounded">
                          Banned
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-300 font-mono">
                      ৳{u.bdtBalance.toFixed(2)} • ${u.usdBalance.toFixed(2)}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setSelectedUser(u)}
                      className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium"
                    >
                      Adjust
                    </button>
                    <button
                      onClick={() => adminToggleBan(u.id)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium ${
                        u.isBanned
                          ? 'bg-emerald-600 text-white'
                          : 'bg-red-900/60 text-red-300 hover:bg-red-800'
                      }`}
                    >
                      {u.isBanned ? 'Unban' : 'Ban'}
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* TAB 4: ADD TASK (Expandable Earning Methods!) */}
      {activeTab === 'tasks' && (
        <form onSubmit={handleCreateNewTask} className="p-4 rounded-3xl bg-[#07143e]/90 border border-[#163884] shadow-lg space-y-3">
          <h3 className="font-heading font-bold text-sm text-white flex items-center gap-1.5">
            <PlusCircle className="w-4 h-4 text-cyan-400" />
            <span>Add New Earning Method or Task</span>
          </h3>

          {taskCreatedSuccess && (
            <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs">
              Task created! Appears live for all users instantly.
            </div>
          )}

          <div>
            <label className="text-[11px] text-slate-300 block mb-1">Task Title</label>
            <input
              type="text"
              value={taskTitle}
              onChange={(e) => setTaskTitle(e.target.value)}
              placeholder="e.g. Subscribe to Official YouTube Channel"
              className="w-full px-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] text-slate-300 block mb-1">Task Type</label>
              <select
                value={taskType}
                onChange={(e: any) => setTaskType(e.target.value)}
                className="w-full px-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs focus:outline-none focus:border-cyan-400"
              >
                <option value="video_ad">Video Ad</option>
                <option value="spin_wheel">Spin Wheel Game</option>
                <option value="math_quiz">Math Challenge</option>
                <option value="social_task">Social & Community</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] text-slate-300 block mb-1">Category</label>
              <input
                type="text"
                value={taskCategory}
                onChange={(e) => setTaskCategory(e.target.value)}
                className="w-full px-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] text-slate-300 block mb-1">Reward Amount</label>
              <input
                type="number"
                value={taskReward}
                onChange={(e) => setTaskReward(e.target.value)}
                className="w-full px-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs focus:outline-none focus:border-cyan-400 font-mono"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-300 block mb-1">Currency</label>
              <select
                value={taskCurrency}
                onChange={(e: any) => setTaskCurrency(e.target.value)}
                className="w-full px-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs focus:outline-none focus:border-cyan-400"
              >
                <option value="BDT">BDT (৳)</option>
                <option value="USD">USD ($)</option>
              </select>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-bold text-xs uppercase tracking-wider shadow-md shadow-blue-500/30 transition-all"
          >
            Publish New Earning Task
          </button>
        </form>
      )}

      {/* TAB 4: PROMOTIONS MANAGEMENT */}
      {activeTab === 'promotions' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-heading font-bold text-sm text-white flex items-center gap-1.5">
                <Rocket className="w-4 h-4 text-cyan-400" />
                <span>Panda Promotions Management</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Manage user boosted posts, approve campaigns, pin to feed, or block phishing
              </p>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold">
              Total: {adminAllPromotions.length}
            </span>
          </div>

          {adminAllPromotions.length === 0 ? (
            <div className="text-center py-10 rounded-2xl bg-[#07143e]/70 border border-[#163884] text-xs text-slate-400">
              No promotions submitted yet.
            </div>
          ) : (
            <div className="space-y-3">
              {adminAllPromotions.map((post) => (
                <div
                  key={post.id}
                  className={`p-4 rounded-2xl border transition space-y-3 ${
                    post.isBlocked
                      ? 'bg-red-950/40 border-red-500/40'
                      : post.isPinnedToTop
                      ? 'bg-gradient-to-b from-[#0f1f3d] to-[#07143e] border-amber-500/40'
                      : 'bg-[#07143e]/90 border-[#163884]'
                  }`}
                >
                  {/* Top user bar & status */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <img
                        src={post.userAvatar}
                        alt={post.userName}
                        className="w-8 h-8 rounded-full border border-cyan-400/30 object-cover"
                      />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-white">{post.userName}</span>
                          <span className="text-[10px] text-slate-400 font-mono">({post.userId})</span>
                        </div>
                        <span className="text-[10px] text-slate-400 capitalize">
                          {post.linkType} • {new Date(post.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {post.isPinnedToTop && (
                        <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold flex items-center gap-1">
                          <Pin className="w-3 h-3" />
                          Pinned
                        </span>
                      )}

                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          post.isBlocked
                            ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                            : post.promotionStatus === 'active'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : post.promotionStatus === 'pending_approval'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            : post.promotionStatus === 'paused'
                            ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/40'
                            : 'bg-slate-700/50 text-slate-400'
                        }`}
                      >
                        {post.isBlocked ? 'Blocked (Anti-Phishing)' : post.promotionStatus}
                      </span>
                    </div>
                  </div>

                  {/* Post copy & link */}
                  <p className="text-xs text-slate-200 line-clamp-3 bg-black/20 p-2.5 rounded-xl border border-white/5">
                    {post.content}
                  </p>

                  <div className="flex items-center justify-between gap-2 p-2 rounded-xl bg-slate-950/60 border border-white/5 text-xs">
                    <div className="overflow-hidden">
                      <span className="text-[10px] text-slate-400 block font-mono">Destination URL:</span>
                      <a
                        href={post.linkUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-cyan-400 hover:underline truncate block"
                      >
                        {post.linkUrl}
                      </a>
                    </div>
                    <a
                      href={post.linkUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500 hover:text-white transition shrink-0"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>

                  {/* Metrics bar */}
                  <div className="grid grid-cols-4 gap-2 text-center text-[10px] p-2 rounded-xl bg-black/30 border border-white/5">
                    <div>
                      <span className="text-slate-400 block">Package</span>
                      <span className="font-bold text-cyan-300">{post.packageName || 'Free Post'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Days Left</span>
                      <span className="font-bold text-white">{post.daysRemaining ?? '-'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Views / Clicks</span>
                      <span className="font-bold text-amber-300">{post.viewsCount} / {post.clicksCount}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Reports</span>
                      <span className={`font-bold ${post.reportsCount > 0 ? 'text-rose-400' : 'text-slate-400'}`}>
                        {post.reportsCount}
                      </span>
                    </div>
                  </div>

                  {/* Admin action buttons */}
                  <div className="pt-1 flex flex-wrap items-center gap-1.5 text-xs">
                    {post.promotionStatus === 'pending_approval' && (
                      <button
                        onClick={() => adminApprovePromotion(post.id)}
                        className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1 transition"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Approve Boost</span>
                      </button>
                    )}

                    {post.promotionStatus === 'active' && (
                      <button
                        onClick={() => adminTogglePausePromotion(post.id)}
                        className="px-2.5 py-1.5 rounded-lg bg-yellow-600/80 hover:bg-yellow-500 text-white font-semibold flex items-center gap-1 transition"
                      >
                        <Pause className="w-3.5 h-3.5" />
                        <span>Pause</span>
                      </button>
                    )}

                    {post.promotionStatus === 'paused' && (
                      <button
                        onClick={() => adminTogglePausePromotion(post.id)}
                        className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold flex items-center gap-1 transition"
                      >
                        <Play className="w-3.5 h-3.5" />
                        <span>Resume</span>
                      </button>
                    )}

                    <button
                      onClick={() => adminTogglePinPromotion(post.id)}
                      className={`px-2.5 py-1.5 rounded-lg font-semibold flex items-center gap-1 transition ${
                        post.isPinnedToTop
                          ? 'bg-amber-600 text-white'
                          : 'bg-white/10 text-slate-300 hover:bg-white/20'
                      }`}
                    >
                      <Pin className="w-3.5 h-3.5" />
                      <span>{post.isPinnedToTop ? 'Unpin Feed' : 'Pin to Top'}</span>
                    </button>

                    <button
                      onClick={() => adminRejectPromotion(post.id, 'Terms violation (Refunded)')}
                      className="px-2.5 py-1.5 rounded-lg bg-red-600/30 hover:bg-red-600 text-red-200 hover:text-white font-semibold flex items-center gap-1 transition"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Reject & Refund</span>
                    </button>

                    <button
                      onClick={() => adminBlockPromotion(post.id)}
                      className="px-2.5 py-1.5 rounded-lg bg-rose-950 border border-rose-500/40 text-rose-300 hover:bg-rose-900 font-semibold flex items-center gap-1 transition"
                    >
                      <Ban className="w-3.5 h-3.5" />
                      <span>{post.isBlocked ? 'Unblock' : 'Block Spam'}</span>
                    </button>

                    <button
                      onClick={() => adminDeletePromotion(post.id)}
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-red-600/50 text-slate-400 hover:text-white transition ml-auto"
                      title="Delete Post"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 5: PACKAGES MANAGEMENT */}
      {activeTab === 'packages' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-heading font-bold text-sm text-white flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Promotion Packages Control</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Configure boost durations, prices (BDT/USD), and add custom promotional plans
              </p>
            </div>
          </div>

          {/* Create New Package Form */}
          <form
            onSubmit={handleCreatePackage}
            className="p-4 rounded-2xl bg-[#07143e]/90 border border-cyan-500/30 shadow-lg space-y-3"
          >
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <PlusCircle className="w-4 h-4 text-cyan-400" />
                <span>Add New Promotion Package</span>
              </h4>
              {pkgSuccessMsg && (
                <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" /> Created Successfully!
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Package Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 7 Days Starter Boost"
                  value={pkgName}
                  onChange={(e) => setPkgName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Duration (Days)</label>
                <input
                  type="number"
                  required
                  min={1}
                  value={pkgDuration}
                  onChange={(e) => setPkgDuration(e.target.value)}
                  className="w-full px-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Price (BDT ৳)</label>
                <input
                  type="number"
                  required
                  step="0.5"
                  value={pkgPriceBdt}
                  onChange={(e) => setPkgPriceBdt(e.target.value)}
                  className="w-full px-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Price (USD $)</label>
                <input
                  type="number"
                  required
                  step="0.01"
                  value={pkgPriceUsd}
                  onChange={(e) => setPkgPriceUsd(e.target.value)}
                  className="w-full px-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Estimated Reach</label>
                <input
                  type="text"
                  value={pkgReach}
                  onChange={(e) => setPkgReach(e.target.value)}
                  placeholder="e.g. 5,000+ Active Users"
                  className="w-full px-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-[11px] text-slate-300 block mb-1">Features (comma-separated)</label>
                <input
                  type="text"
                  value={pkgFeatures}
                  onChange={(e) => setPkgFeatures(e.target.value)}
                  placeholder="Sponsored Badge, Top Feed Priority"
                  className="w-full px-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isCreatingPkg}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs uppercase tracking-wider shadow-md transition-all cursor-pointer"
            >
              {isCreatingPkg ? 'Creating...' : 'Save & Publish Package'}
            </button>
          </form>

          {/* Existing Packages List */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-slate-300">Active & Configured Packages ({adminAllPackages.length})</h4>
            {adminAllPackages.map((pkg) => (
              <div
                key={pkg.id}
                className="p-3.5 rounded-2xl bg-[#07143e]/90 border border-[#163884] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">{pkg.name}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-white/5 text-amber-300 border border-white/10 font-bold">
                      {pkg.durationDays} Days
                    </span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                        pkg.isActive
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : 'bg-slate-700 text-slate-400'
                      }`}
                    >
                      {pkg.isActive ? 'Active' : 'Disabled'}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-xs mt-1 text-slate-300">
                    <span className="font-extrabold text-cyan-300">৳{pkg.priceBDT} BDT</span>
                    <span className="text-slate-400">/ ${pkg.priceUSD} USD</span>
                    <span className="text-slate-400">• Reach: {pkg.estimatedReach}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => adminTogglePackage(pkg.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                      pkg.isActive
                        ? 'bg-yellow-600/30 text-yellow-300 hover:bg-yellow-600/50'
                        : 'bg-emerald-600/30 text-emerald-300 hover:bg-emerald-600/50'
                    }`}
                  >
                    {pkg.isActive ? 'Disable' : 'Enable'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Balance Adjustment Modal */}
      {selectedUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setSelectedUser(null)} />
          <form
            onSubmit={handleSaveBalanceAdjustment}
            className="relative w-full max-w-sm bg-[#061238] border border-blue-500/50 rounded-3xl p-5 shadow-2xl z-10 space-y-3"
          >
            <h3 className="font-heading font-black text-sm text-white">
              Adjust Test Balance: {selectedUser.name}
            </h3>

            <div>
              <label className="text-[11px] text-slate-300 block mb-1">BDT Delta (+/-)</label>
              <input
                type="number"
                value={adjustBdt}
                onChange={(e) => setAdjustBdt(e.target.value)}
                className="w-full px-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs font-mono"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-300 block mb-1">USD Delta (+/-)</label>
              <input
                type="number"
                value={adjustUsd}
                onChange={(e) => setAdjustUsd(e.target.value)}
                className="w-full px-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs font-mono"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-300 block mb-1">Admin Reason / Note</label>
              <input
                type="text"
                value={adjustNote}
                onChange={(e) => setAdjustNote(e.target.value)}
                className="w-full px-3 py-2 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedUser(null)}
                className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-600/30"
              >
                Apply
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
