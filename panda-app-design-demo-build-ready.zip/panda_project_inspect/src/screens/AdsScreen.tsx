import React, { useState, useEffect } from 'react';
import { Play, Sparkles, CheckCircle, Clock, Gift, ShieldAlert } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { AdTask } from '../types';

export const AdsScreen: React.FC = () => {
  const { adTasks, watchAd, user, setScreen } = useApp();
  const [activeAd, setActiveAd] = useState<AdTask | null>(null);
  const [countdown, setCountdown] = useState(0);
  const [isWatching, setIsWatching] = useState(false);
  const [rewardClaimed, setRewardClaimed] = useState(false);

  useEffect(() => {
    let timer: any;
    if (isWatching && countdown > 0) {
      timer = setInterval(() => {
        setCountdown((c) => c - 1);
      }, 1000);
    } else if (isWatching && countdown === 0 && activeAd) {
      setIsWatching(false);
      setRewardClaimed(true);
      watchAd(activeAd.id);
    }
    return () => clearInterval(timer);
  }, [isWatching, countdown, activeAd]);

  const handleStartWatch = (ad: AdTask) => {
    if (ad.type === 'spin_wheel') {
      setScreen('spin');
      return;
    }
    if (ad.type === 'math_quiz') {
      setScreen('quiz');
      return;
    }
    setActiveAd(ad);
    setCountdown(ad.durationSec || 10);
    setIsWatching(true);
    setRewardClaimed(false);
  };

  return (
    <div className="px-4 py-4 space-y-4 pb-20 select-none">
      {/* Top Banner */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-[#2c0b6b] via-[#3a1288] to-[#14236e] border border-purple-500/40 shadow-xl space-y-1">
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-yellow-400/20 text-yellow-300 text-xs font-bold">
          <Gift className="w-3.5 h-3.5" />
          <span>Daily Ads & Tasks</span>
        </div>
        <h2 className="font-heading font-black text-lg text-white">
          Watch Short Ads, Earn Real Cash
        </h2>
        <p className="text-xs text-slate-200">
          Earn up to ৳100 BDT & $2 USD daily directly into your wallet balance.
        </p>
      </div>

      {/* Expandable Earning Methods Bar */}
      <div className="grid grid-cols-2 gap-2.5">
        <button
          onClick={() => setScreen('spin')}
          className="p-3 rounded-2xl bg-gradient-to-br from-amber-600/30 to-amber-950/50 border border-amber-500/40 text-left hover:border-amber-400 transition-all group active:scale-95 shadow-md"
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] uppercase font-bold text-amber-300">Daily Game</span>
            <Sparkles className="w-4 h-4 text-amber-400 group-hover:rotate-12 transition-transform" />
          </div>
          <h3 className="font-heading font-black text-sm text-white">Lucky Spin Wheel</h3>
          <p className="text-[10px] text-slate-300 mt-0.5">Win up to ৳50 BDT test reward!</p>
        </button>

        <button
          onClick={() => setScreen('quiz')}
          className="p-3 rounded-2xl bg-gradient-to-br from-purple-600/30 to-purple-950/50 border border-purple-500/40 text-left hover:border-purple-400 transition-all group active:scale-95 shadow-md"
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] uppercase font-bold text-purple-300">Skill Test</span>
            <Sparkles className="w-4 h-4 text-purple-400 group-hover:rotate-12 transition-transform" />
          </div>
          <h3 className="font-heading font-black text-sm text-white">Math Brain Quiz</h3>
          <p className="text-[10px] text-slate-300 mt-0.5">Solve 3 fast equations for ৳12!</p>
        </button>
      </div>

      {/* Ad Tasks List */}
      <div className="space-y-3">
        <h3 className="font-heading font-bold text-sm text-white flex items-center justify-between">
          <span>Available Video Ads ({adTasks.length})</span>
          <span className="text-xs text-cyan-300 font-mono">Refreshes every 24h</span>
        </h3>

        {adTasks.map((ad) => (
          <div
            key={ad.id}
            className="p-3.5 rounded-2xl bg-[#07143e]/90 border border-[#163884] shadow-md flex items-center justify-between gap-3 hover:border-blue-400/50 transition-colors"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-md bg-blue-900/60 border border-blue-500/30 text-[10px] font-semibold text-cyan-300">
                  {ad.category}
                </span>
                <span className="flex items-center gap-1 text-[11px] text-slate-400 font-mono">
                  <Clock className="w-3 h-3 text-slate-400" />
                  {ad.durationSec}s
                </span>
              </div>
              <h4 className="text-sm font-bold text-white leading-tight">{ad.title}</h4>
              <p className="text-[11px] text-slate-300">Sponsor: {ad.sponsor}</p>
            </div>

            <div className="text-right shrink-0">
              <div className="text-sm font-heading font-black text-[#ffcc00] tabular-nums mb-1.5 drop-shadow-[0_0_6px_rgba(255,204,0,0.5)]">
                +{ad.currency === 'BDT' ? `৳${ad.rewardAmount}` : `$${ad.rewardAmount}`}
              </div>

              <button
                onClick={() => handleStartWatch(ad)}
                disabled={ad.watched}
                className={`px-3 py-1.5 rounded-xl text-xs font-heading font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95 ${
                  ad.watched
                    ? 'bg-slate-800 text-slate-400 border border-slate-700 cursor-not-allowed'
                    : 'bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-black shadow-orange-500/30'
                }`}
              >
                {ad.watched ? (
                  <>
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Watched</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-black" />
                    <span>Watch Ad</span>
                  </>
                )}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Video Ad Player Modal Simulation */}
      {activeAd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/85 backdrop-blur-md" />

          <div className="relative w-full max-w-sm bg-[#061239] border border-blue-500/60 rounded-3xl p-5 shadow-2xl z-10 space-y-4 text-center">
            {rewardClaimed ? (
              <div className="py-6 space-y-3">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center mx-auto text-emerald-400 animate-bounce">
                  <CheckCircle className="w-10 h-10" />
                </div>
                <h3 className="font-heading font-black text-xl text-white">
                  Reward Credited! 🎉
                </h3>
                <p className="text-sm text-[#ffcc00] font-bold font-heading">
                  +{activeAd.currency === 'BDT' ? `৳${activeAd.rewardAmount}` : `$${activeAd.rewardAmount}`}{' '}
                  Added to Your Balance
                </p>
                <p className="text-xs text-slate-300">
                  New Balance: {activeAd.currency === 'BDT' ? `৳${user.bdtBalance.toFixed(2)}` : `$${user.usdBalance.toFixed(2)}`}
                </p>
                <button
                  onClick={() => {
                    setActiveAd(null);
                    setRewardClaimed(false);
                  }}
                  className="w-full mt-3 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg shadow-blue-600/30"
                >
                  Collect & Continue
                </button>
              </div>
            ) : (
              <>
                <div className="relative aspect-video rounded-2xl overflow-hidden bg-gradient-to-br from-indigo-950 via-slate-900 to-blue-950 border border-blue-500/40 flex flex-col items-center justify-center p-4 shadow-inner">
                  {/* Glowing Mascot */}
                  <img
                    src="/assets/app/panda_head.png"
                    alt="Panda"
                    className="w-16 h-16 object-contain animate-pulse filter drop-shadow-[0_0_12px_rgba(0,180,255,0.7)]"
                  />
                  <div className="absolute top-2 right-2 px-2.5 py-1 rounded-full bg-black/60 border border-white/20 text-xs font-mono font-bold text-amber-300">
                    ⏱ {countdown}s
                  </div>
                  <p className="text-xs font-semibold text-white mt-2">{activeAd.title}</p>
                  <p className="text-[10px] text-cyan-300">Sponsored by {activeAd.sponsor}</p>
                </div>

                <div className="w-full bg-[#050e28] rounded-full h-2 border border-blue-500/30 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-cyan-400 to-blue-500 h-full transition-all duration-1000"
                    style={{
                      width: `${(((activeAd.durationSec || 10) - countdown) / (activeAd.durationSec || 10)) * 100}%`,
                    }}
                  />
                </div>

                <p className="text-xs text-slate-300">
                  Please watch the full sponsor video to unlock your reward!
                </p>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
