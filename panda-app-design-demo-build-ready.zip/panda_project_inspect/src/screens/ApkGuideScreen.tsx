import React, { useState } from 'react';
import {
  Smartphone,
  CheckCircle,
  Copy,
  Check,
  Terminal,
  ExternalLink,
  ShieldCheck,
  FolderGit2,
  Cpu,
  Download,
  Package,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ApkGuideScreen: React.FC = () => {
  const { triggerConfetti } = useApp();
  const [copiedStep, setCopiedStep] = useState<number | null>(null);

  const copyCommand = (cmd: string, stepIndex: number) => {
    navigator.clipboard.writeText(cmd);
    setCopiedStep(stepIndex);
    triggerConfetti();
    setTimeout(() => setCopiedStep(null), 2000);
  };

  const steps = [
    {
      title: 'Step 1: Build the Web App Production Bundle',
      desc: 'Compiles and generates the optimized production build into the dist/ directory.',
      cmd: 'npm run build',
    },
    {
      title: 'Step 2: Sync Capacitor Android Project',
      desc: 'Synchronizes web assets and plugins to the native Android Gradle project.',
      cmd: 'npx cap sync android',
    },
    {
      title: 'Step 3: Open in Android Studio & Generate APK',
      desc: 'Opens the project in Android Studio or compiles the debug/release APK directly with Gradle.',
      cmd: 'npx cap open android',
    },
    {
      title: 'Step 4: Build Direct Debug APK via Terminal (Optional)',
      desc: 'If Android SDK/CLI is installed, generates app-debug.apk in one command without GUI.',
      cmd: 'cd android && ./gradlew assembleDebug',
    },
  ];

  return (
    <div className="px-4 py-4 space-y-4 pb-20 select-none">
      {/* Top Banner */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-emerald-950/70 via-[#0a1e4a] to-[#040e2b] border border-emerald-500/40 shadow-xl space-y-1.5">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-400/20 text-emerald-300 text-xs font-bold">
          <Smartphone className="w-3.5 h-3.5" />
          <span>Capacitor Android Native Ready</span>
        </div>
        <h2 className="font-heading font-black text-lg text-white">
          Android APK Conversion Hub
        </h2>
        <p className="text-xs text-slate-300 leading-relaxed">
          Your source code is fully structured with <code className="text-cyan-300 font-mono">capacitor.config.ts</code>,
          touch ergonomics, safe-area paddings, and background capabilities.
        </p>

        {/* Direct Download ZIP Button */}
        <div className="pt-2">
          <a
            href="/panda-app-android-project.zip"
            download="panda-app-android-project.zip"
            onClick={triggerConfetti}
            className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-extrabold text-xs shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer text-center"
          >
            <Download className="w-4 h-4" />
            <span>সম্পূর্ণ Android Project ZIP ডাউনলোড করুন (.ZIP)</span>
          </a>
          <span className="text-[10px] text-slate-400 text-center block mt-1">
            (Includes Android Studio project, Capacitor configs, backend server & frontend)
          </span>
        </div>
      </div>

      {/* App Configuration Manifest Box */}
      <div className="p-4 rounded-3xl bg-[#07143e]/90 border border-[#163884] shadow-lg space-y-2.5">
        <h3 className="font-heading font-bold text-xs text-white uppercase tracking-wider flex items-center gap-1.5">
          <Cpu className="w-4 h-4 text-cyan-400" />
          <span>Configured Android Specifications</span>
        </h3>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="p-2.5 rounded-xl bg-[#091a4e] border border-[#163884]">
            <span className="text-slate-400 text-[10px] block">Application ID:</span>
            <span className="font-mono text-cyan-300 font-bold text-[11px] truncate block">
              com.pandaapp.earnsharegrow
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-[#091a4e] border border-[#163884]">
            <span className="text-slate-400 text-[10px] block">App Label:</span>
            <span className="font-heading text-white font-bold text-[11px] truncate block">
              PANDA APP
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-[#091a4e] border border-[#163884]">
            <span className="text-slate-400 text-[10px] block">Splash / Theme:</span>
            <span className="font-mono text-amber-300 font-bold text-[11px] block">
              #03091e (Midnight Cyber)
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-[#091a4e] border border-[#163884]">
            <span className="text-slate-400 text-[10px] block">Output Directory:</span>
            <span className="font-mono text-emerald-400 font-bold text-[11px] block">
              dist/
            </span>
          </div>
        </div>
      </div>

      {/* Step by Step Commands */}
      <div className="space-y-3">
        <h3 className="font-heading font-bold text-sm text-white flex items-center gap-1.5">
          <Terminal className="w-4 h-4 text-amber-400" />
          <span>Export Steps for APK Generation</span>
        </h3>

        {steps.map((s, idx) => (
          <div
            key={idx}
            className="p-3.5 rounded-2xl bg-[#07143e]/90 border border-[#163884] space-y-2 hover:border-blue-400/40 transition-colors"
          >
            <div>
              <h4 className="text-xs font-bold text-white leading-tight">{s.title}</h4>
              <p className="text-[11px] text-slate-300 mt-0.5">{s.desc}</p>
            </div>

            <div className="flex items-center justify-between p-2 rounded-xl bg-[#040c26] border border-blue-500/30">
              <code className="text-xs font-mono text-cyan-300 font-semibold">{s.cmd}</code>
              <button
                onClick={() => copyCommand(s.cmd, idx)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-semibold transition-colors"
              >
                {copiedStep === idx ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-300" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Verification Notice */}
      <div className="p-3.5 rounded-2xl bg-[#07153a] border border-[#123170] text-xs text-slate-300 space-y-1.5">
        <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
          <ShieldCheck className="w-4 h-4" />
          <span>APK Production Checklist</span>
        </div>
        <p className="text-[11px] leading-relaxed">
          • All HTTP calls use relative API routes (<code className="text-cyan-300">/api/*</code>), which work out of the box when packaged.<br />
          • Splash screen duration is configured to 2000ms in <code className="text-cyan-300">capacitor.config.ts</code>.<br />
          • Demo balance disclaimer is displayed on all wallet flows for compliance.
        </p>
      </div>
    </div>
  );
};
