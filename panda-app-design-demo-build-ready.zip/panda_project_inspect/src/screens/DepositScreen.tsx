import React, { useState } from 'react';
import {
  ChevronLeft,
  CheckCircle2,
  Copy,
  Check,
  ShieldCheck,
  Info,
  QrCode,
  ArrowRight,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const DepositScreen: React.FC = () => {
  const { goBack, addDeposit, setScreen, triggerConfetti } = useApp();

  // Inputs for direct deposit cards
  const [bdtAmount, setBdtAmount] = useState<string>('500');
  const [usdAmount, setUsdAmount] = useState<string>('10');

  // Confirmation modal state
  const [modalMethod, setModalMethod] = useState<'Nagad' | 'Binance' | null>(null);
  const [senderAccount, setSenderAccount] = useState<string>('01712345678');
  const [trxId, setTrxId] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const NAGAD_AGENT_NUMBER = '01887654321';
  const BINANCE_PAY_ID = '92817402';

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleNagadInitiate = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(bdtAmount);
    if (isNaN(amt) || amt < 50) {
      setErrorMsg('Minimum deposit with Nagad is ৳50');
      return;
    }
    if (amt > 50000) {
      setErrorMsg('Maximum deposit with Nagad is ৳50,000');
      return;
    }
    setErrorMsg('');
    setModalMethod('Nagad');
  };

  const handleBinanceInitiate = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(usdAmount);
    if (isNaN(amt) || amt < 5) {
      setErrorMsg('Minimum deposit with Binance is $5');
      return;
    }
    setErrorMsg('');
    setModalMethod('Binance');
  };

  const handleConfirmDeposit = () => {
    if (!senderAccount.trim()) {
      alert('Please enter your sender mobile number or Binance Pay ID');
      return;
    }

    if (modalMethod === 'Nagad') {
      const amt = parseFloat(bdtAmount);
      addDeposit(amt, 'Nagad', senderAccount, trxId || undefined);
    } else if (modalMethod === 'Binance') {
      const amt = parseFloat(usdAmount);
      addDeposit(amt, 'Binance', senderAccount, trxId || undefined);
    }

    setIsSuccess(true);
    triggerConfetti();

    setTimeout(() => {
      setIsSuccess(false);
      setModalMethod(null);
      setScreen('wallet');
    }, 1800);
  };

  return (
    <div className="px-4 py-4 space-y-4 pb-20 select-none">
      {/* Sandbox Testnet Demo Banner */}
      <div className="p-3 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs flex items-center gap-2">
        <Info className="w-4 h-4 shrink-0 text-amber-400" />
        <span>
          <strong>SANDBOX SIMULATION:</strong> Test deposit requests are recorded in demo mode. Real money will not be charged.
        </span>
      </div>

      {/* Header bar */}
      <div className="flex items-center justify-between pb-1">
        <h2 className="font-heading font-extrabold text-base text-white">
          Choose Payment Method
        </h2>
        <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono border border-cyan-400/40">
          TESTNET DEMO
        </span>
      </div>

      {errorMsg && (
        <div className="p-3 rounded-xl bg-red-500/20 border border-red-500/40 text-red-200 text-xs">
          {errorMsg}
        </div>
      )}

      {/* 1. Nagad Deposit Card (matches mockup exactly) */}
      <div className="p-4 rounded-3xl bg-gradient-to-b from-[#091e4f] to-[#051131] border border-blue-500/40 shadow-xl space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-red-600 via-orange-500 to-amber-500 p-2 flex items-center justify-center shadow-[0_0_12px_rgba(235,28,36,0.5)]">
              <img
                src="/assets/app/nagad_logo.png"
                alt="Nagad"
                className="w-full h-full object-contain filter brightness-110"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
            <div>
              <h3 className="font-heading font-black text-lg text-white leading-tight">
                Nagad
              </h3>
              <p className="text-xs font-semibold text-emerald-400">৳50 - ৳50,000</p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-slate-300 font-medium">Min: ৳50 | Max: ৳50,000</span>
          </div>
        </div>

        {/* Input */}
        <div className="relative">
          <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center font-bold text-slate-400">
            ৳
          </span>
          <input
            type="number"
            value={bdtAmount}
            onChange={(e) => setBdtAmount(e.target.value)}
            placeholder="Enter Amount (BDT)"
            className="w-full pl-8 pr-4 py-3 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white placeholder-slate-400 text-sm font-semibold focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition-all"
          />
        </div>

        {/* Quick amounts */}
        <div className="flex items-center gap-2 overflow-x-auto text-xs">
          {[100, 500, 1000, 2500, 5000].map((amt) => (
            <button
              key={amt}
              type="button"
              onClick={() => setBdtAmount(amt.toString())}
              className={`px-3 py-1.5 rounded-lg border text-xs font-bold transition-all ${
                bdtAmount === amt.toString()
                  ? 'bg-emerald-500 text-black border-emerald-400'
                  : 'bg-[#0a1a45] text-slate-300 border-[#143477] hover:border-emerald-500/50'
              }`}
            >
              ৳{amt}
            </button>
          ))}
        </div>

        {/* Green Button */}
        <button
          type="button"
          onClick={handleNagadInitiate}
          className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#00c853] to-[#00e676] hover:from-[#00b248] hover:to-[#00d069] text-black font-heading font-black text-sm tracking-wide shadow-lg shadow-emerald-500/30 active:scale-98 transition-all flex items-center justify-center gap-2"
        >
          <span>Deposit with Nagad</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* 2. Binance Deposit Card (matches mockup exactly) */}
      <div className="p-4 rounded-3xl bg-gradient-to-b from-[#091e4f] to-[#051131] border border-blue-500/40 shadow-xl space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-yellow-500 via-amber-500 to-yellow-600 p-2 flex items-center justify-center shadow-[0_0_12px_rgba(240,185,11,0.5)]">
              <img
                src="/assets/app/binance_logo.png"
                alt="Binance"
                className="w-full h-full object-contain filter brightness-110"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
            <div>
              <h3 className="font-heading font-black text-lg text-white leading-tight">
                Binance
              </h3>
              <p className="text-xs font-semibold text-yellow-400">$5 Minimum</p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-slate-300 font-medium">Min: $5</span>
          </div>
        </div>

        {/* Input */}
        <div className="relative">
          <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center font-bold text-slate-400">
            $
          </span>
          <input
            type="number"
            value={usdAmount}
            onChange={(e) => setUsdAmount(e.target.value)}
            placeholder="Enter Amount (USD)"
            className="w-full pl-8 pr-4 py-3 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white placeholder-slate-400 text-sm font-semibold focus:outline-none focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 transition-all"
          />
        </div>

        {/* Quick amounts */}
        <div className="flex items-center gap-2 overflow-x-auto text-xs">
          {[5, 10, 20, 50, 100].map((amt) => (
            <button
              key={amt}
              type="button"
              onClick={() => setUsdAmount(amt.toString())}
              className={`px-3 py-1.5 rounded-lg border text-xs font-bold transition-all ${
                usdAmount === amt.toString()
                  ? 'bg-yellow-400 text-black border-yellow-300'
                  : 'bg-[#0a1a45] text-slate-300 border-[#143477] hover:border-yellow-500/50'
              }`}
            >
              ${amt}
            </button>
          ))}
        </div>

        {/* Yellow Button */}
        <button
          type="button"
          onClick={handleBinanceInitiate}
          className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#f0b90b] to-[#f8d33a] hover:from-[#dfab08] hover:to-[#eec92c] text-black font-heading font-black text-sm tracking-wide shadow-lg shadow-yellow-500/30 active:scale-98 transition-all flex items-center justify-center gap-2"
        >
          <span>Deposit with Binance</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Security notice */}
      <div className="flex items-center gap-2 p-3 rounded-2xl bg-[#07153a] border border-[#123170] text-slate-300 text-xs">
        <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
        <span>Official encrypted payment gateway. 100% Secure & Guaranteed.</span>
      </div>

      {/* Confirmation & Payment Gateway Modal */}
      {modalMethod && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            onClick={() => !isSuccess && setModalMethod(null)}
          />

          <div className="relative w-full max-w-sm bg-[#061238] border border-blue-500/50 rounded-3xl p-5 shadow-2xl z-10 space-y-4">
            {isSuccess ? (
              <div className="text-center py-6 space-y-3">
                <CheckCircle2 className="w-16 h-16 text-emerald-400 mx-auto animate-bounce" />
                <h3 className="font-heading font-black text-lg text-white">
                  Deposit Submitted!
                </h3>
                <p className="text-xs text-slate-300">
                  {modalMethod === 'Nagad'
                    ? `৳${bdtAmount} BDT request sent! Auto-verifying in seconds.`
                    : `$${usdAmount} USD request sent! Crediting wallet.`}
                </p>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between pb-2 border-b border-[#143477]">
                  <div className="flex items-center gap-2">
                    <span className="font-heading font-black text-white text-base">
                      {modalMethod === 'Nagad' ? 'Nagad Pay' : 'Binance Pay'}
                    </span>
                  </div>
                  <button
                    onClick={() => setModalMethod(null)}
                    className="text-slate-400 hover:text-white text-xs"
                  >
                    Cancel
                  </button>
                </div>

                {/* Receiver Info */}
                <div className="p-3.5 rounded-2xl bg-[#091a4e] border border-[#183d8e] space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-300">
                    <span>
                      {modalMethod === 'Nagad' ? 'Nagad Personal/Agent No:' : 'Binance Pay ID:'}
                    </span>
                    <span className="text-emerald-400 font-bold">Panda Official</span>
                  </div>

                  <div className="flex items-center justify-between p-2 rounded-xl bg-[#061233] border border-blue-500/30">
                    <span className="font-mono font-bold text-white text-sm">
                      {modalMethod === 'Nagad' ? NAGAD_AGENT_NUMBER : BINANCE_PAY_ID}
                    </span>
                    <button
                      onClick={() =>
                        copyToClipboard(
                          modalMethod === 'Nagad' ? NAGAD_AGENT_NUMBER : BINANCE_PAY_ID
                        )
                      }
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-semibold transition-colors"
                    >
                      {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      {copied ? 'Copied' : 'Copy'}
                    </button>
                  </div>

                  <p className="text-[11px] text-cyan-300">
                    Amount to send:{' '}
                    <strong className="text-white text-xs">
                      {modalMethod === 'Nagad' ? `৳${bdtAmount} BDT` : `$${usdAmount} USD`}
                    </strong>
                  </p>
                </div>

                {/* Sender fields */}
                <div className="space-y-3">
                  <div>
                    <label className="text-xs text-slate-300 block mb-1">
                      {modalMethod === 'Nagad' ? 'Your Nagad Number' : 'Your Binance Pay ID / Email'}
                    </label>
                    <input
                      type="text"
                      value={senderAccount}
                      onChange={(e) => setSenderAccount(e.target.value)}
                      placeholder={modalMethod === 'Nagad' ? 'e.g. 01712345678' : 'e.g. 19283746'}
                      className="w-full px-3 py-2.5 bg-[#061233] border border-[#193a80] rounded-xl text-white text-xs focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-slate-300 block mb-1">
                      Transaction ID (TrxID)
                    </label>
                    <input
                      type="text"
                      value={trxId}
                      onChange={(e) => setTrxId(e.target.value)}
                      placeholder="e.g. 9J8A7K6L5M (Optional/Auto)"
                      className="w-full px-3 py-2.5 bg-[#061233] border border-[#193a80] rounded-xl text-white text-xs focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleConfirmDeposit}
                  className={`w-full py-3 rounded-xl font-heading font-black text-xs uppercase tracking-wider text-black shadow-lg transition-all ${
                    modalMethod === 'Nagad'
                      ? 'bg-gradient-to-r from-emerald-400 to-green-500 shadow-emerald-500/30'
                      : 'bg-gradient-to-r from-yellow-400 to-amber-500 shadow-yellow-500/30'
                  }`}
                >
                  Confirm & Submit Deposit
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
