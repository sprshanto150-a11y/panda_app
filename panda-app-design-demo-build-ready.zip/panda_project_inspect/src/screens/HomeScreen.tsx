import React from 'react';
import {
  ArrowDownCircle,
  ArrowUpCircle,
  Users,
  Megaphone,
  Trophy,
  UserCheck,
  ChevronRight,
  TrendingUp,
  Rocket,
  Flame,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const HomeScreen: React.FC = () => {
  const { user, setScreen, earners } = useApp();

  const quickActions = [
    {
      id: 'deposit',
      label: 'Deposit',
      icon: <ArrowDownCircle className="w-6 h-6 text-emerald-400" />,
      bg: 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400',
      action: () => setScreen('deposit'),
    },
    {
      id: 'withdraw',
      label: 'Withdraw',
      icon: <ArrowUpCircle className="w-6 h-6 text-amber-400" />,
      bg: 'bg-amber-500/20 border-amber-500/40 text-amber-400',
      action: () => setScreen('withdraw'),
    },
    {
      id: 'referral',
      label: 'Referral',
      icon: <Users className="w-6 h-6 text-blue-400" />,
      bg: 'bg-blue-500/20 border-blue-500/40 text-blue-400',
      action: () => setScreen('referral'),
    },
    {
      id: 'ads',
      label: 'Ads',
      icon: <Megaphone className="w-6 h-6 text-orange-400" />,
      bg: 'bg-orange-500/20 border-orange-500/40 text-orange-400',
      action: () => setScreen('ads'),
    },
    {
      id: 'leaderboard',
      label: 'Leaderboard',
      icon: <Trophy className="w-6 h-6 text-yellow-400" />,
      bg: 'bg-yellow-500/20 border-yellow-500/40 text-yellow-400',
      action: () => setScreen('leaderboard'),
    },
    {
      id: 'follow',
      label: 'Follow',
      icon: <UserCheck className="w-6 h-6 text-cyan-400" />,
      bg: 'bg-cyan-500/20 border-cyan-500/40 text-cyan-400',
      action: () => setScreen('people'),
    },
  ];

  return (
    <div className="px-4 py-4 space-y-4 pb-20 select-none">
      {/* 1. User Header Profile Bar */}
      <div className="flex items-center justify-between p-3 rounded-2xl bg-[#07143e]/90 border border-[#163884] shadow-lg shadow-blue-950/50">
        <div className="flex items-center gap-3">
          <div className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-cyan-400 shadow-[0_0_12px_rgba(0,229,255,0.4)]">
            <img
              src={user.avatar}
              alt={user.name}
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/assets/app/panda_head.png';
              }}
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-white font-heading font-extrabold text-base">
                Hello, {user.name}
              </h2>
              <span className="text-sm">👋</span>
            </div>
            <p className="text-xs text-cyan-300 font-mono font-medium">ID: {user.id}</p>
          </div>
        </div>

        <button
          onClick={() => setScreen('profile')}
          className="text-xs text-slate-300 hover:text-white px-2.5 py-1 rounded-lg bg-blue-900/40 border border-blue-600/30 active:scale-95 transition-all"
        >
          View Profile
        </button>
      </div>

      {/* 2. Dual Balance Cards (BDT & USD) */}
      <div className="grid grid-cols-2 gap-3">
        {/* BDT Balance Card */}
        <div
          onClick={() => setScreen('wallet')}
          className="p-3.5 rounded-2xl bg-gradient-to-br from-[#061e47] to-[#041235] border border-emerald-500/30 hover:border-emerald-400/60 transition-all cursor-pointer shadow-lg shadow-emerald-950/20 group"
        >
          <div className="flex items-center gap-2 mb-1.5">
            <div className="w-7 h-7 rounded-full bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center text-emerald-400 font-bold text-sm shadow-[0_0_8px_rgba(0,200,83,0.3)]">
              ৳
            </div>
            <span className="text-xs text-slate-300 font-medium">BDT Balance</span>
          </div>
          <div className="text-lg sm:text-xl font-heading font-extrabold text-white tracking-tight tabular-nums group-hover:text-emerald-300 transition-colors">
            ৳{user.bdtBalance.toFixed(2)}
          </div>
        </div>

        {/* USD Balance Card */}
        <div
          onClick={() => setScreen('wallet')}
          className="p-3.5 rounded-2xl bg-gradient-to-br from-[#061e47] to-[#041235] border border-cyan-500/30 hover:border-cyan-400/60 transition-all cursor-pointer shadow-lg shadow-cyan-950/20 group"
        >
          <div className="flex items-center gap-2 mb-1.5">
            <div className="w-7 h-7 rounded-full bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center text-cyan-400 font-bold text-sm shadow-[0_0_8px_rgba(0,229,255,0.3)]">
              $
            </div>
            <span className="text-xs text-slate-300 font-medium">USD Balance</span>
          </div>
          <div className="text-lg sm:text-xl font-heading font-extrabold text-white tracking-tight tabular-nums group-hover:text-cyan-300 transition-colors">
            ${user.usdBalance.toFixed(2)}
          </div>
        </div>
      </div>

      {/* 3. Promo Banner Card */}
      <div
        onClick={() => setScreen('ads')}
        className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#2c0b6b] via-[#3a1288] to-[#14236e] border border-purple-500/40 p-4 shadow-xl cursor-pointer group active:scale-[0.99] transition-all"
      >
        <div className="absolute top-0 right-0 w-36 h-36 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between relative z-10">
          <div className="space-y-1 max-w-[65%]">
            <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-yellow-400/20 border border-yellow-400/40 text-[10px] font-bold text-yellow-300 uppercase tracking-wider">
              <TrendingUp className="w-3 h-3" />
              Daily Rewards
            </div>
            <h3 className="font-heading font-black text-white text-base sm:text-lg leading-tight">
              Welcome to Panda App
            </h3>
            <p className="text-yellow-300 font-semibold text-xs tracking-wide">
              Earn More, Grow More!
            </p>
          </div>

          <div className="w-20 h-20 relative shrink-0">
            <img
              src="/assets/app/home_banner.png"
              alt="Panda promo"
              className="w-full h-full object-contain filter drop-shadow-[0_0_12px_rgba(255,200,0,0.5)] group-hover:scale-105 transition-transform"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/assets/app/panda_head.png';
              }}
            />
          </div>
        </div>
      </div>

      {/* 3.5 Panda Promotion Feature Spotlight */}
      <div
        onClick={() => setScreen('promotion')}
        className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#062045] via-[#091b3b] to-[#04122d] border border-cyan-400/40 p-3.5 shadow-xl cursor-pointer group active:scale-[0.99] transition-all flex items-center justify-between gap-3"
      >
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shrink-0 shadow-lg shadow-cyan-500/20 border border-cyan-300/40 group-hover:scale-105 transition-transform">
            <Rocket className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-heading font-black text-xs text-white uppercase tracking-wider flex items-center gap-1">
                Panda <span className="text-cyan-400">Promotion</span>
              </span>
              <span className="px-1.5 py-0.2 rounded-full bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950 font-extrabold text-[9px] flex items-center gap-0.5">
                <Flame className="w-2.5 h-2.5" /> ৳৫ অফার
              </span>
            </div>
            <p className="text-[11px] text-slate-300 mt-0.5 line-clamp-1">
              আপনার ওয়েবসাইট, Facebook বা YouTube চ্যানেল বুস্ট করুন
            </p>
          </div>
        </div>

        <button className="px-3 py-1.5 rounded-xl bg-cyan-500/20 group-hover:bg-cyan-500 text-cyan-300 group-hover:text-white border border-cyan-500/30 text-xs font-bold shrink-0 transition-colors flex items-center gap-1">
          <span>দেখুন</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 4. Quick Action Grid (6 Icons matching mockup) */}
      <div className="grid grid-cols-3 gap-3">
        {quickActions.map((item) => (
          <button
            key={item.id}
            onClick={item.action}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-[#07143e]/90 border border-[#163884] hover:border-blue-400/50 hover:bg-[#0a1e58] active:scale-95 transition-all shadow-md group"
          >
            <div
              className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 border transition-all ${item.bg} group-hover:scale-110 shadow-sm`}
            >
              {item.icon}
            </div>
            <span className="text-xs font-semibold text-slate-200 group-hover:text-white transition-colors">
              {item.label}
            </span>
          </button>
        ))}
      </div>

      {/* 5. Top Earners Section */}
      <div className="p-4 rounded-2xl bg-[#07143e]/90 border border-[#163884] shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-heading font-bold text-white text-sm tracking-wide">
            Top Earners
          </h3>
          <button
            onClick={() => setScreen('leaderboard')}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-0.5"
          >
            See All <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-2.5">
          {earners.slice(0, 3).map((item) => (
            <div
              key={item.id}
              className="flex items-center justify-between p-2.5 rounded-xl bg-[#0a1a4a]/60 border border-[#143477] hover:border-blue-400/40 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black ${
                    item.rank === 1
                      ? 'bg-amber-400 text-black shadow-[0_0_8px_rgba(251,191,36,0.8)]'
                      : item.rank === 2
                      ? 'bg-slate-300 text-slate-900 shadow-[0_0_6px_rgba(203,213,225,0.7)]'
                      : 'bg-amber-700 text-white shadow-[0_0_6px_rgba(180,83,9,0.7)]'
                  }`}
                >
                  {item.rank}
                </div>
                <div className="w-8 h-8 rounded-full overflow-hidden border border-blue-400/40">
                  <img
                    src={item.avatar}
                    alt={item.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/assets/app/user_rahim.png';
                    }}
                  />
                </div>
                <span className="text-sm font-semibold text-white">{item.name}</span>
              </div>

              <span className="font-heading font-bold text-sm text-[#ffcc00] tracking-tight tabular-nums drop-shadow-[0_0_6px_rgba(255,204,0,0.4)]">
                ৳{item.earningsBDT.toLocaleString()}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
