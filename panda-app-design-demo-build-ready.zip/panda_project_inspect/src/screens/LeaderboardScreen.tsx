import React from 'react';
import { Crown, Sparkles, Trophy } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const LeaderboardScreen: React.FC = () => {
  const { earners, earnerPeriod, setEarnerPeriod } = useApp();

  const top1 = earners.find((e) => e.rank === 1) || earners[0];
  const top2 = earners.find((e) => e.rank === 2) || earners[1];
  const top3 = earners.find((e) => e.rank === 3) || earners[2];

  const restEarners = earners.filter((e) => e.rank > 3);

  return (
    <div className="px-4 py-4 space-y-4 pb-20 select-none">
      {/* 1. Time Filter Tabs: [All Time] [Weekly] [Monthly] */}
      <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#06143b] border border-[#163884] rounded-2xl">
        {(['all', 'weekly', 'monthly'] as const).map((period) => (
          <button
            key={period}
            onClick={() => setEarnerPeriod(period)}
            className={`py-2 px-2 rounded-xl text-xs font-bold transition-all capitalize ${
              earnerPeriod === period
                ? 'bg-gradient-to-r from-blue-600 to-cyan-500 text-white shadow-md shadow-blue-500/30'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            {period === 'all' ? 'All Time' : period === 'weekly' ? 'Weekly' : 'Monthly'}
          </button>
        ))}
      </div>

      {/* 2. Top 3 Podium Graphic (matching mockup layout exactly) */}
      <div className="relative pt-6 pb-2">
        {/* Background ambient light */}
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-56 h-36 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-end justify-center gap-2 sm:gap-4 relative z-10">
          {/* Rank 2 (Left - Karim) */}
          {top2 && (
            <div className="flex flex-col items-center flex-1 max-w-[105px]">
              <div className="relative mb-2">
                <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-slate-300 shadow-[0_0_12px_rgba(203,213,225,0.6)]">
                  <img
                    src={top2.avatar}
                    alt={top2.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/assets/app/user_rahim.png';
                    }}
                  />
                </div>
                {/* Silver Pedestal Badge */}
                <div className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-gradient-to-b from-slate-200 to-slate-400 border border-white text-slate-900 font-heading font-black text-xs flex items-center justify-center shadow-md">
                  2
                </div>
              </div>

              <div className="text-center mt-2 w-full">
                <h4 className="text-xs font-bold text-white truncate">{top2.name}</h4>
                <p className="text-xs font-bold text-[#ffcc00] font-heading tabular-nums">
                  ৳{top2.earningsBDT.toLocaleString()}
                </p>
              </div>

              {/* Pedestal Stand */}
              <div className="w-full h-16 mt-2 rounded-t-xl bg-gradient-to-t from-[#06143c] to-[#0d2870] border-t-2 border-slate-300 flex items-center justify-center">
                <Trophy className="w-5 h-5 text-slate-300 opacity-60" />
              </div>
            </div>
          )}

          {/* Rank 1 (Center - Elevated - Rahim) */}
          {top1 && (
            <div className="flex flex-col items-center flex-1 max-w-[125px] -mt-5 z-20">
              {/* Crown Icon */}
              <Crown className="w-7 h-7 text-amber-400 filter drop-shadow-[0_0_8px_rgba(251,191,36,0.9)] animate-bounce" />

              <div className="relative mb-2">
                <div className="w-18 h-18 rounded-full overflow-hidden border-2 border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.8)]">
                  <img
                    src={top1.avatar}
                    alt={top1.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/assets/app/user_rahim.png';
                    }}
                  />
                </div>
                {/* Gold Pedestal Badge */}
                <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-7 h-7 rounded-full bg-gradient-to-b from-yellow-300 via-amber-400 to-amber-600 border border-white text-black font-heading font-black text-sm flex items-center justify-center shadow-lg shadow-amber-500/50">
                  1
                </div>
              </div>

              <div className="text-center mt-2.5 w-full">
                <h4 className="text-sm font-extrabold text-white truncate flex items-center justify-center gap-1">
                  {top1.name}
                  {top1.isCurrentUser && (
                    <span className="text-[9px] bg-cyan-500/30 text-cyan-300 px-1 rounded font-normal">
                      You
                    </span>
                  )}
                </h4>
                <p className="text-sm font-extrabold text-[#ffcc00] font-heading tabular-nums drop-shadow-[0_0_8px_rgba(255,204,0,0.6)]">
                  ৳{top1.earningsBDT.toLocaleString()}
                </p>
              </div>

              {/* Elevated Pedestal Stand */}
              <div className="w-full h-24 mt-2 rounded-t-2xl bg-gradient-to-t from-[#06143c] via-[#10348f] to-[#1c4ab8] border-t-2 border-amber-400 flex flex-col items-center justify-center shadow-lg shadow-blue-600/30">
                <Trophy className="w-7 h-7 text-amber-300" />
                <span className="text-[10px] font-bold text-amber-300 uppercase tracking-widest mt-1">
                  Champion
                </span>
              </div>
            </div>
          )}

          {/* Rank 3 (Right - Asif) */}
          {top3 && (
            <div className="flex flex-col items-center flex-1 max-w-[105px]">
              <div className="relative mb-2">
                <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-amber-700 shadow-[0_0_12px_rgba(180,83,9,0.6)]">
                  <img
                    src={top3.avatar}
                    alt={top3.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/assets/app/user_rahim.png';
                    }}
                  />
                </div>
                {/* Bronze Pedestal Badge */}
                <div className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-gradient-to-b from-amber-600 to-amber-900 border border-white text-white font-heading font-black text-xs flex items-center justify-center shadow-md">
                  3
                </div>
              </div>

              <div className="text-center mt-2 w-full">
                <h4 className="text-xs font-bold text-white truncate">{top3.name}</h4>
                <p className="text-xs font-bold text-[#ffcc00] font-heading tabular-nums">
                  ৳{top3.earningsBDT.toLocaleString()}
                </p>
              </div>

              {/* Pedestal Stand */}
              <div className="w-full h-12 mt-2 rounded-t-xl bg-gradient-to-t from-[#06143c] to-[#0b215c] border-t-2 border-amber-700 flex items-center justify-center">
                <Trophy className="w-4 h-4 text-amber-600 opacity-60" />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 3. Ranked List (Ranks 4 to 8+ matching mockup) */}
      <div className="p-3 rounded-2xl bg-[#07143e]/90 border border-[#163884] shadow-lg space-y-2">
        {restEarners.map((item) => (
          <div
            key={item.id}
            className={`flex items-center justify-between p-2.5 rounded-xl border transition-colors ${
              item.isCurrentUser
                ? 'bg-blue-600/20 border-cyan-400'
                : 'bg-[#0a1a4a]/60 border-[#143477] hover:border-blue-400/40'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="w-6 text-center font-heading font-extrabold text-sm text-slate-300">
                {item.rank}
              </span>
              <div className="w-8 h-8 rounded-full overflow-hidden border border-blue-400/40">
                <img
                  src={item.avatar}
                  alt={item.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/assets/app/user_rahim.png';
                  }}
                />
              </div>
              <div>
                <span className="text-sm font-semibold text-white">{item.name}</span>
                <span className="text-[10px] text-slate-400 block font-mono">ID: {item.id}</span>
              </div>
            </div>

            <span className="font-heading font-bold text-sm text-[#ffcc00] tracking-tight tabular-nums">
              ৳{item.earningsBDT.toLocaleString()}
            </span>
          </div>
        ))}

        {/* Footer Note */}
        <div className="text-center pt-2">
          <span className="text-xs text-slate-400 font-medium">Top 100 Members</span>
        </div>
      </div>
    </div>
  );
};
