import React, { useState } from 'react';
import { Mail, Lock, Eye, EyeOff, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const LoginScreen: React.FC = () => {
  const { setScreen, login, loginWithGoogle } = useApp();
  const [emailOrUser, setEmailOrUser] = useState('rahim@panda.app');
  const [password, setPassword] = useState('panda123');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailOrUser.trim()) {
      setError('Please enter your email or username');
      return;
    }
    if (!password.trim()) {
      setError('Please enter your password');
      return;
    }
    setError('');
    login(emailOrUser, password);
  };

  return (
    <div className="min-h-[85vh] flex flex-col justify-center px-6 py-6 select-none relative">
      {/* Background glow */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-64 h-64 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />

      {/* Mascot & Header */}
      <div className="flex flex-col items-center text-center mb-6 z-10">
        <div className="relative w-28 h-28 mb-2">
          <div className="absolute inset-0 bg-blue-500/25 rounded-full blur-lg" />
          <img
            src="/assets/app/panda_head.png"
            alt="Panda King Mascot"
            className="w-full h-full object-contain relative filter drop-shadow-[0_0_12px_rgba(0,140,255,0.6)]"
          />
        </div>
        <h1 className="font-heading text-2xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white via-blue-100 to-blue-200 tracking-wider">
          PANDA APP
        </h1>
        <p className="text-white text-base font-bold mt-1">Welcome Back!</p>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="w-full max-w-sm mx-auto space-y-4 z-10">
        {error && (
          <div className="p-2.5 rounded-xl bg-red-500/20 border border-red-500/40 text-red-200 text-xs text-center">
            {error}
          </div>
        )}

        {/* Email or Username */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Mail className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={emailOrUser}
            onChange={(e) => setEmailOrUser(e.target.value)}
            placeholder="Email or Username"
            className="w-full pl-10 pr-4 py-3 bg-[#08153c]/90 border border-[#1b3d88] rounded-xl text-white placeholder-slate-400 text-sm focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all shadow-inner"
          />
        </div>

        {/* Password */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Lock className="w-4 h-4" />
          </div>
          <input
            type={showPassword ? 'text' : 'password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="w-full pl-10 pr-10 py-3 bg-[#08153c]/90 border border-[#1b3d88] rounded-xl text-white placeholder-slate-400 text-sm focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all shadow-inner"
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200"
          >
            {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>

        {/* Login Button */}
        <button
          type="submit"
          className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#0062ff] to-[#0099ff] hover:from-[#0052df] hover:to-[#0088ee] text-white font-bold text-sm tracking-wide shadow-lg shadow-blue-600/40 active:scale-98 transition-all"
        >
          Login
        </button>

        {/* Divider */}
        <div className="flex items-center justify-center gap-3 my-2">
          <div className="h-px bg-[#153477] flex-1" />
          <span className="text-xs text-slate-400">or</span>
          <div className="h-px bg-[#153477] flex-1" />
        </div>

        {/* Google Login */}
        <button
          type="button"
          onClick={loginWithGoogle}
          className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-slate-100 text-slate-800 font-semibold text-xs tracking-wide shadow-md active:scale-98 transition-all flex items-center justify-center gap-2.5"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          <span>Login with Google</span>
        </button>

        {/* Demo Fast Fill Button */}
        <div className="pt-2 text-center">
          <button
            type="button"
            onClick={() => {
              setEmailOrUser('rahim@panda.app');
              setPassword('panda123');
            }}
            className="text-[11px] text-cyan-300 hover:text-cyan-200 underline inline-flex items-center gap-1"
          >
            <Sparkles className="w-3 h-3" />
            Autofill Demo Account (Rahim)
          </button>
        </div>

        {/* Footer Links */}
        <div className="text-center text-xs text-slate-300 pt-3 space-y-2">
          <div>
            Don't have an account?{' '}
            <button
              type="button"
              onClick={() => setScreen('register')}
              className="text-cyan-400 hover:underline font-bold"
            >
              Register
            </button>
          </div>
          <div>
            <button
              type="button"
              onClick={() => alert('Password reset link sent to registered email!')}
              className="text-slate-400 hover:text-slate-200 text-xs"
            >
              Forgot Password?
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
