import React, { useState, useEffect } from 'react';
import { Brain, CheckCircle2, XCircle, Clock, Trophy, AlertTriangle, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const MathQuizScreen: React.FC = () => {
  const { completeCustomTask, goBack, triggerConfetti } = useApp();

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(15);
  const [isFinished, setIsFinished] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);

  const questions = [
    { num1: 24, num2: 18, op: '+', answer: 42, options: [38, 42, 44, 40] },
    { num1: 15, num2: 6, op: '×', answer: 90, options: [80, 85, 90, 95] },
    { num1: 120, num2: 45, op: '-', answer: 75, options: [65, 75, 80, 70] },
  ];

  useEffect(() => {
    if (isFinished || timeLeft <= 0) {
      if (timeLeft <= 0 && !isFinished) {
        finishQuiz(score);
      }
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((t) => t - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, isFinished, score]);

  const handleSelectOption = (opt: number) => {
    if (selectedOption !== null || isFinished) return;
    setSelectedOption(opt);

    const isCorrect = opt === questions[currentQuestion].answer;
    const newScore = isCorrect ? score + 1 : score;
    setScore(newScore);

    setTimeout(() => {
      setSelectedOption(null);
      if (currentQuestion + 1 < questions.length) {
        setCurrentQuestion((c) => c + 1);
      } else {
        finishQuiz(newScore);
      }
    }, 800);
  };

  const finishQuiz = async (finalScore: number) => {
    setIsFinished(true);
    if (finalScore >= 2) {
      triggerConfetti();
      await completeCustomTask('TASK-04', 12);
    }
  };

  const q = questions[currentQuestion];

  return (
    <div className="px-4 py-4 space-y-4 pb-20 select-none">
      {/* Sandbox Test Banner */}
      <div className="p-3 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs flex items-center gap-2">
        <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
        <span>DEMO TEST DATA: Earning rewards are test credits in sandbox mode.</span>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-purple-400" />
          <h2 className="font-heading font-black text-lg text-white">Math Brain Quiz</h2>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-900/60 border border-blue-500/30 text-xs font-mono font-bold text-cyan-300">
          <Clock className="w-3.5 h-3.5 text-amber-400" />
          <span>{timeLeft}s</span>
        </div>
      </div>

      {!isFinished ? (
        <div className="p-5 rounded-3xl bg-[#07143e]/90 border border-[#163884] shadow-xl space-y-4 text-center">
          <div className="text-xs text-slate-400 font-medium">
            Question {currentQuestion + 1} of {questions.length} • Score: {score}
          </div>

          {/* Equation Box */}
          <div className="py-6 px-4 rounded-2xl bg-gradient-to-r from-[#091f54] to-[#06153a] border border-blue-500/40 text-3xl font-heading font-black text-white tracking-widest font-mono shadow-inner">
            {q.num1} {q.op} {q.num2} = ?
          </div>

          {/* 4 Choices Grid */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            {q.options.map((opt) => {
              const isSelected = selectedOption === opt;
              const isAnswer = opt === q.answer;

              let btnStyle = 'bg-[#091a4e] border-[#183d8e] text-white hover:border-cyan-400';
              if (isSelected) {
                btnStyle = isAnswer
                  ? 'bg-emerald-600 border-emerald-400 text-white'
                  : 'bg-red-600 border-red-400 text-white';
              }

              return (
                <button
                  key={opt}
                  onClick={() => handleSelectOption(opt)}
                  disabled={selectedOption !== null}
                  className={`py-3.5 px-4 rounded-xl border font-heading font-extrabold text-base transition-all active:scale-95 shadow-md ${btnStyle}`}
                >
                  {opt}
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="p-6 rounded-3xl bg-[#07143e]/90 border border-[#163884] shadow-xl text-center space-y-3">
          {score >= 2 ? (
            <>
              <Trophy className="w-12 h-12 text-amber-400 mx-auto animate-bounce" />
              <h3 className="font-heading font-black text-xl text-white">Quiz Passed! 🎉</h3>
              <p className="text-xs text-slate-300">
                You scored {score}/{questions.length} correct answers!
              </p>
              <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 font-bold text-sm">
                +৳12 BDT Test Reward Added to Wallet!
              </div>
            </>
          ) : (
            <>
              <XCircle className="w-12 h-12 text-red-400 mx-auto" />
              <h3 className="font-heading font-black text-xl text-white">Keep Practicing!</h3>
              <p className="text-xs text-slate-300">
                You scored {score}/{questions.length}. Minimum 2 required to earn.
              </p>
            </>
          )}

          <div className="pt-2">
            <button
              onClick={goBack}
              className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-600/30 transition-colors"
            >
              Continue to Dashboard
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
