import React, { useState, useEffect } from 'react';
import {
  Rocket,
  Flame,
  Globe,
  Youtube,
  Instagram,
  Facebook,
  Send,
  Eye,
  MousePointerClick,
  Heart,
  Share2,
  Clock,
  ShieldAlert,
  ShieldCheck,
  PlusCircle,
  Sparkles,
  CheckCircle2,
  ExternalLink,
  MoreVertical,
  Flag,
  DollarSign,
  AlertCircle,
  RefreshCw,
  Zap,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PromotionPackage, PromotionPost } from '../types';

export const PandaPromotionScreen: React.FC = () => {
  const {
    user,
    promotions,
    packages,
    myPromotions,
    loadPromotionsData,
    createPromotionPost,
    boostPost,
    trackClick,
    trackView,
    likePromotionPost,
    reportPromotionPost,
    setScreen,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'feed' | 'create' | 'my_promotions' | 'packages'>('feed');
  const [filterPlatform, setFilterPlatform] = useState<string>('all');

  // Create Post Form State
  const [content, setContent] = useState('');
  const [linkType, setLinkType] = useState<'website' | 'facebook' | 'youtube' | 'instagram' | 'telegram' | 'other'>('website');
  const [linkUrl, setLinkUrl] = useState('');
  const [linkTitle, setLinkTitle] = useState('');
  const [mediaUrl, setMediaUrl] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createMsg, setCreateMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Boost Modal State
  const [selectedPostToBoost, setSelectedPostToBoost] = useState<PromotionPost | null>(null);
  const [selectedPackageId, setSelectedPackageId] = useState<string>('');
  const [isBoosting, setIsBoosting] = useState(false);
  const [boostMsg, setBoostMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Report Modal State
  const [reportingPost, setReportingPost] = useState<PromotionPost | null>(null);
  const [reportReason, setReportReason] = useState('Spam or Scam');
  const [reportSuccessMsg, setReportSuccessMsg] = useState<string | null>(null);

  // Track impressions on mount & feed switch
  useEffect(() => {
    loadPromotionsData();
  }, [loadPromotionsData]);

  // Set default package selection when packages load
  useEffect(() => {
    if (packages.length > 0 && !selectedPackageId) {
      setSelectedPackageId(packages[0].id);
    }
  }, [packages, selectedPackageId]);

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() || !linkUrl.trim()) {
      setCreateMsg({ type: 'error', text: 'অনুগ্রহ করে বিবরণ এবং বৈধ লিংক প্রদান করুন।' });
      return;
    }

    setIsSubmitting(true);
    setCreateMsg(null);

    const res = await createPromotionPost(content, linkType, linkUrl, linkTitle, mediaUrl);
    setIsSubmitting(false);

    if (res.success) {
      setCreateMsg({ type: 'success', text: res.message || 'পোস্ট সফলভাবে পাবলিশ হয়েছে!' });
      setContent('');
      setLinkUrl('');
      setLinkTitle('');
      setMediaUrl('');
      setTimeout(() => {
        setActiveTab('feed');
        setCreateMsg(null);
      }, 1500);
    } else {
      setCreateMsg({ type: 'error', text: res.error || 'পোস্ট তৈরিতে ব্যর্থ হয়েছে' });
    }
  };

  const handleOpenBoostModal = (post: PromotionPost) => {
    setSelectedPostToBoost(post);
    setBoostMsg(null);
  };

  const handleConfirmBoost = async () => {
    if (!selectedPostToBoost || !selectedPackageId) return;

    const pkg = packages.find((p) => p.id === selectedPackageId);
    if (!pkg) return;

    if (user.bdtBalance < pkg.priceBDT) {
      setBoostMsg({
        type: 'error',
        text: `আপনার ব্যালেন্স অপর্যাপ্ত! প্যাকেজের দাম ৳${pkg.priceBDT}, কিন্তু আপনার ব্যালেন্স ৳${user.bdtBalance.toFixed(2)}। অনুগ্রহ করে ওয়ালেট রিচার্জ করুন।`,
      });
      return;
    }

    setIsBoosting(true);
    setBoostMsg(null);

    const res = await boostPost(selectedPostToBoost.id, selectedPackageId);
    setIsBoosting(false);

    if (res.success) {
      setBoostMsg({ type: 'success', text: res.message || 'বুস্টিং সফলভাবে সক্রিয় করা হয়েছে!' });
      setTimeout(() => {
        setSelectedPostToBoost(null);
        setBoostMsg(null);
        setActiveTab('my_promotions');
      }, 1600);
    } else {
      setBoostMsg({ type: 'error', text: res.error || 'বুস্টিং ব্যর্থ হয়েছে' });
    }
  };

  const handleOpenLink = (post: PromotionPost) => {
    trackClick(post.id);
    window.open(post.linkUrl, '_blank', 'noopener,noreferrer');
  };

  const handleReport = async () => {
    if (!reportingPost) return;
    const res = await reportPromotionPost(reportingPost.id, reportReason);
    setReportSuccessMsg(res.message);
    setTimeout(() => {
      setReportingPost(null);
      setReportSuccessMsg(null);
    }, 1500);
  };

  const getPlatformIcon = (type: string) => {
    switch (type) {
      case 'facebook':
        return <Facebook className="w-4 h-4 text-blue-500" />;
      case 'youtube':
        return <Youtube className="w-4 h-4 text-red-500" />;
      case 'instagram':
        return <Instagram className="w-4 h-4 text-pink-500" />;
      case 'telegram':
        return <Send className="w-4 h-4 text-sky-400" />;
      default:
        return <Globe className="w-4 h-4 text-emerald-400" />;
    }
  };

  const filteredFeed = promotions.filter((p) => {
    if (filterPlatform === 'all') return true;
    if (filterPlatform === 'sponsored') return p.isPromoted;
    return p.linkType === filterPlatform;
  });

  return (
    <div className="min-safe-area pb-24 text-white">
      {/* Top Hero Banner */}
      <div className="relative overflow-hidden bg-gradient-to-br from-[#0c1a30] via-[#091322] to-[#040810] p-4 sm:p-5 rounded-2xl border border-cyan-500/20 shadow-xl mb-4">
        <div className="absolute top-0 right-0 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-yellow-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 border border-cyan-300/30">
              <Rocket className="w-6 h-6 text-white animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-1.5">
                  PANDA <span className="text-cyan-400">PROMOTION</span>
                </h1>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Boost & Feed
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                আপনার ওয়েবসাইট, YouTube, FB পেজ প্রচার করুন মাত্র ৳৫ টাকায়!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('create')}
              className="flex-1 sm:flex-initial px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-xs font-semibold text-white shadow-md shadow-cyan-500/20 flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>পোস্ট শেয়ার করুন</span>
            </button>
            <button
              onClick={() => setActiveTab('packages')}
              className="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-amber-300 flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>প্যাকেজ</span>
            </button>
          </div>
        </div>

        {/* Security & Anti-Phishing Guarantee Badge */}
        <div className="mt-3.5 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5 text-emerald-400">
            <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
            <span>AI স্প্যাম ও ফিশিং প্রোটেকশন সক্রিয় • নিরাপদ লিংক যাচাই</span>
          </div>
          <span className="text-slate-400 hidden sm:inline">ব্যালেন্স: ৳{user.bdtBalance.toFixed(2)}</span>
        </div>
      </div>

      {/* Single-line Navigation Tabs */}
      <div className="grid grid-cols-4 gap-1 p-1 bg-slate-900/80 backdrop-blur-md rounded-xl border border-white/10 mb-4 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('feed')}
          className={`py-2 px-1 text-center rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'feed'
              ? 'bg-cyan-500 text-white shadow-md shadow-cyan-500/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Flame className="w-3.5 h-3.5" />
          <span>ফিড</span>
        </button>

        <button
          onClick={() => setActiveTab('create')}
          className={`py-2 px-1 text-center rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'create'
              ? 'bg-cyan-500 text-white shadow-md shadow-cyan-500/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <PlusCircle className="w-3.5 h-3.5" />
          <span>শেয়ার লিংক</span>
        </button>

        <button
          onClick={() => setActiveTab('my_promotions')}
          className={`py-2 px-1 text-center rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'my_promotions'
              ? 'bg-cyan-500 text-white shadow-md shadow-cyan-500/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Rocket className="w-3.5 h-3.5" />
          <span>আমার বুস্ট</span>
        </button>

        <button
          onClick={() => setActiveTab('packages')}
          className={`py-2 px-1 text-center rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'packages'
              ? 'bg-cyan-500 text-white shadow-md shadow-cyan-500/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-amber-300" />
          <span>প্যাকেজ</span>
        </button>
      </div>

      {/* TAB 1: FEED */}
      {activeTab === 'feed' && (
        <div className="space-y-4">
          {/* Sub-filter chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
            {[
              { id: 'all', label: 'সব পোস্ট' },
              { id: 'sponsored', label: '🔥 Sponsored' },
              { id: 'youtube', label: 'YouTube' },
              { id: 'facebook', label: 'Facebook' },
              { id: 'website', label: 'Website' },
              { id: 'instagram', label: 'Instagram' },
            ].map((chip) => (
              <button
                key={chip.id}
                onClick={() => setFilterPlatform(chip.id)}
                className={`px-3 py-1.5 rounded-lg shrink-0 transition text-[11px] font-medium cursor-pointer ${
                  filterPlatform === chip.id
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'bg-white/5 text-slate-400 hover:bg-white/10 border border-white/5'
                }`}
              >
                {chip.label}
              </button>
            ))}
          </div>

          {/* Quick Create Prompt Card */}
          <div
            onClick={() => setActiveTab('create')}
            className="p-3.5 rounded-xl bg-slate-900/60 border border-white/10 hover:border-cyan-500/40 flex items-center gap-3 cursor-pointer transition"
          >
            <img
              src={user.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80'}
              alt={user.name}
              className="w-9 h-9 rounded-full object-cover border border-cyan-400/40"
            />
            <div className="flex-1 bg-white/5 rounded-xl px-3.5 py-2 text-xs text-slate-400 flex items-center justify-between">
              <span>আপনার ওয়েবসাইট, ইউটিউব বা ফেসবুক লিংক শেয়ার করুন...</span>
              <Share2 className="w-3.5 h-3.5 text-cyan-400" />
            </div>
          </div>

          {/* Post Feed List */}
          {filteredFeed.length === 0 ? (
            <div className="text-center py-12 px-4 rounded-2xl bg-slate-900/40 border border-white/5">
              <Rocket className="w-10 h-10 text-slate-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-300">কোনো পোস্ট পাওয়া যায়নি</p>
              <p className="text-xs text-slate-500 mt-1">প্রথম পোস্টটি আপনার নিজের লিংক শেয়ার করে শুরু করুন!</p>
              <button
                onClick={() => setActiveTab('create')}
                className="mt-3.5 px-4 py-1.5 rounded-xl bg-cyan-500 text-xs font-semibold text-white shadow cursor-pointer"
              >
                পোস্ট তৈরি করুন
              </button>
            </div>
          ) : (
            filteredFeed.map((post) => {
              const isLiked = post.likedBy && post.likedBy.includes(user.id);
              const isOwner = post.userId === user.id;

              return (
                <div
                  key={post.id}
                  className={`relative rounded-2xl p-4 transition border ${
                    post.isPinnedToTop
                      ? 'bg-gradient-to-b from-[#101c33] to-[#0a1222] border-amber-500/40 shadow-lg shadow-amber-500/10'
                      : post.isPromoted
                      ? 'bg-gradient-to-b from-[#0e1a2f] to-[#070e1c] border-cyan-500/30 shadow-md shadow-cyan-500/5'
                      : 'bg-slate-900/70 border-white/10'
                  }`}
                >
                  {/* Pinned / Sponsored Header Badges */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <img
                        src={post.userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80'}
                        alt={post.userName}
                        className="w-10 h-10 rounded-full object-cover border border-cyan-400/40"
                      />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-white">{post.userName}</span>
                          <span className="text-[10px] text-slate-400">• {new Date(post.createdAt).toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          {getPlatformIcon(post.linkType)}
                          <span className="text-[10px] text-slate-300 capitalize">{post.linkType}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {post.isPinnedToTop && (
                        <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold flex items-center gap-1">
                          <Sparkles className="w-3 h-3" />
                          পিন্ড পোস্ট
                        </span>
                      )}

                      {post.isPromoted ? (
                        <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-emerald-500/20 to-cyan-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-bold animate-pulse">
                          <Flame className="w-3 h-3 text-emerald-400" />
                          <span>SPONSORED</span>
                          {post.daysRemaining !== undefined && (
                            <span className="text-slate-400 font-normal">({post.daysRemaining} দিন বাকি)</span>
                          )}
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-400 font-medium px-2 py-0.5 rounded bg-white/5">
                          পাবলিক
                        </span>
                      )}

                      {/* Dropdown / Report Trigger */}
                      <button
                        onClick={() => setReportingPost(post)}
                        title="রিপোর্ট বা স্প্যাম ফ্ল্যাগ"
                        className="p-1 rounded-lg text-slate-400 hover:text-red-400 hover:bg-white/5 transition cursor-pointer"
                      >
                        <Flag className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Post Content */}
                  <p className="text-xs text-slate-200 leading-relaxed mb-3 whitespace-pre-wrap">
                    {post.content}
                  </p>

                  {/* Media attachment if any */}
                  {post.mediaUrl && (
                    <div className="mb-3 rounded-xl overflow-hidden max-h-60 border border-white/10">
                      <img src={post.mediaUrl} alt="Post media" className="w-full h-full object-cover" />
                    </div>
                  )}

                  {/* Link Preview Card */}
                  <div
                    onClick={() => handleOpenLink(post)}
                    className="group mb-3 p-3 rounded-xl bg-slate-950/70 border border-white/10 hover:border-cyan-500/50 hover:bg-slate-950 transition cursor-pointer flex items-center justify-between gap-3 shadow-inner"
                  >
                    <div className="flex items-center gap-2.5 overflow-hidden">
                      <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center shrink-0 group-hover:scale-105 transition">
                        {getPlatformIcon(post.linkType)}
                      </div>
                      <div className="overflow-hidden">
                        <p className="text-xs font-semibold text-white truncate group-hover:text-cyan-300 transition">
                          {post.linkTitle || post.linkUrl}
                        </p>
                        <p className="text-[10px] text-slate-400 truncate flex items-center gap-1">
                          <span>{post.linkUrl}</span>
                        </p>
                      </div>
                    </div>

                    <button className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500 text-cyan-300 hover:text-white border border-cyan-500/30 text-[11px] font-semibold shrink-0 flex items-center gap-1 transition">
                      <span>ভিজিট করুন</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>

                  {/* Metrics & Actions */}
                  <div className="pt-2.5 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-400">
                    <div className="flex items-center gap-4">
                      {/* Like button */}
                      <button
                        onClick={() => likePromotionPost(post.id)}
                        className={`flex items-center gap-1 transition cursor-pointer ${
                          isLiked ? 'text-rose-400 font-semibold' : 'hover:text-slate-200'
                        }`}
                      >
                        <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
                        <span>{post.likesCount || 0}</span>
                      </button>

                      {/* Views Count */}
                      <div className="flex items-center gap-1 text-slate-400">
                        <Eye className="w-3.5 h-3.5 text-cyan-400" />
                        <span>{post.viewsCount || 0} ভিউ</span>
                      </div>

                      {/* Clicks Count */}
                      <div className="flex items-center gap-1 text-slate-400">
                        <MousePointerClick className="w-3.5 h-3.5 text-amber-400" />
                        <span>{post.clicksCount || 0} ক্লিক</span>
                      </div>
                    </div>

                    {/* Boost Button if owner and not yet promoted */}
                    {isOwner && (
                      <button
                        onClick={() => handleOpenBoostModal(post)}
                        className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-[10px] flex items-center gap-1 shadow-sm transition active:scale-95 cursor-pointer"
                      >
                        <Rocket className="w-3 h-3" />
                        <span>{post.isPromoted ? 'বুস্ট রিনিউ করুন' : 'বুস্ট করুন'}</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* TAB 2: CREATE / SHARE LINK */}
      {activeTab === 'create' && (
        <div className="bg-slate-900/80 backdrop-blur-md rounded-2xl p-4 sm:p-5 border border-white/10 shadow-xl">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-white/10">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <PlusCircle className="w-4 h-4 text-cyan-400" />
                <span>নতুন লিংক শেয়ার ও পাবলিশ করুন</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                আপনার ওয়েবসাইট, ফেসবুক, ইউটিউব বা ইনস্টাগ্রাম লিংক সবার মাঝে ছড়িয়ে দিন
              </p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              ফ্রি শেয়ার
            </span>
          </div>

          {createMsg && (
            <div
              className={`p-3 rounded-xl mb-4 text-xs font-semibold flex items-center gap-2 ${
                createMsg.type === 'success'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
              }`}
            >
              {createMsg.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              <span>{createMsg.text}</span>
            </div>
          )}

          <form onSubmit={handleCreatePost} className="space-y-4">
            {/* Platform Selector */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                প্ল্যাটফর্ম নির্বাচন করুন
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {[
                  { id: 'website', label: 'Website', icon: Globe, color: 'text-emerald-400' },
                  { id: 'facebook', label: 'Facebook', icon: Facebook, color: 'text-blue-500' },
                  { id: 'youtube', label: 'YouTube', icon: Youtube, color: 'text-red-500' },
                  { id: 'instagram', label: 'Instagram', icon: Instagram, color: 'text-pink-500' },
                  { id: 'telegram', label: 'Telegram', icon: Send, color: 'text-sky-400' },
                  { id: 'other', label: 'Other', icon: ExternalLink, color: 'text-cyan-400' },
                ].map((item) => {
                  const Icon = item.icon;
                  const isSelected = linkType === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setLinkType(item.id as any)}
                      className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 transition text-xs cursor-pointer ${
                        isSelected
                          ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow-sm'
                          : 'bg-slate-950/50 border-white/10 text-slate-400 hover:bg-white/5'
                      }`}
                    >
                      <Icon className={`w-4 h-4 ${item.color}`} />
                      <span className="text-[11px] font-medium">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Link URL */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                লিংক URL (https://...) <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <input
                  type="url"
                  required
                  placeholder="https://example.com বা https://youtube.com/@channel"
                  value={linkUrl}
                  onChange={(e) => setLinkUrl(e.target.value)}
                  className="w-full bg-slate-950/80 border border-white/10 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none transition"
                />
              </div>
              <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                ফিশিং, স্প্যাম ও অবৈধ সাইট স্বয়ংক্রিয়ভাবে ফিল্টার করা হবে
              </p>
            </div>

            {/* Link Title */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                লিংকের শিরোনাম বা বাটন টেক্সট (ঐচ্ছিক)
              </label>
              <input
                type="text"
                placeholder="যেমন: আমার চ্যানেল সাবস্ক্রাইব করুন / ৫০% অফার"
                value={linkTitle}
                onChange={(e) => setLinkTitle(e.target.value)}
                className="w-full bg-slate-950/80 border border-white/10 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none transition"
              />
            </div>

            {/* Post Description */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                পোস্টের বিবরণ ও ক্যাপশন <span className="text-rose-400">*</span>
              </label>
              <textarea
                required
                rows={3}
                placeholder="আপনার অফার, সাইট বা সার্ভিস সম্পর্কে বিস্তারিত লিখুন..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full bg-slate-950/80 border border-white/10 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none transition resize-none"
              />
            </div>

            {/* Media Image URL (Optional) */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                ব্যানার বা ছবির লিংক (ঐচ্ছিক)
              </label>
              <input
                type="url"
                placeholder="https://images.unsplash.com/... (ইমেজ লিংক)"
                value={mediaUrl}
                onChange={(e) => setMediaUrl(e.target.value)}
                className="w-full bg-slate-950/80 border border-white/10 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 outline-none transition"
              />
            </div>

            {/* Submit Buttons */}
            <div className="pt-2 flex items-center gap-3">
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-xs font-bold text-white shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 transition active:scale-95 disabled:opacity-50 cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>পোস্ট হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>পাবলিশ করুন</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  setContent('');
                  setLinkUrl('');
                  setActiveTab('feed');
                }}
                className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs text-slate-400 transition cursor-pointer"
              >
                বাতিল
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 3: MY PROMOTIONS & ANALYTICS */}
      {activeTab === 'my_promotions' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950/40 to-blue-950/40 border border-cyan-500/20 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Rocket className="w-4 h-4 text-cyan-400" />
                <span>আমার ক্যাম্পেইন ও লাইভ অ্যানালিটিক্স</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                আপনার পোস্টের ভিউ, ক্লিক এবং বুস্টিং মেয়াদ দেখুন
              </p>
            </div>
            <button
              onClick={() => setActiveTab('create')}
              className="px-3 py-1.5 rounded-xl bg-cyan-500 text-xs font-semibold text-white cursor-pointer"
            >
              নতুন পোস্ট
            </button>
          </div>

          {myPromotions.length === 0 ? (
            <div className="text-center py-12 px-4 rounded-2xl bg-slate-900/40 border border-white/5">
              <Sparkles className="w-10 h-10 text-slate-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-300">আপনি এখনও কোনো পোস্ট করেননি</p>
              <p className="text-xs text-slate-500 mt-1">
                আপনার চ্যানেল বা ওয়েবসাইট পোস্ট করুন এবং মাত্র ৫ টাকায় ৭ দিনের বুস্ট নিন!
              </p>
              <button
                onClick={() => setActiveTab('create')}
                className="mt-3 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-xs font-semibold text-white shadow cursor-pointer"
              >
                প্রথম পোস্ট করুন
              </button>
            </div>
          ) : (
            myPromotions.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-slate-900/80 border border-white/10 shadow-lg space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {getPlatformIcon(item.linkType)}
                    <span className="text-xs font-bold text-white capitalize">{item.linkType} পোস্ট</span>
                    <span className="text-[10px] text-slate-400">• {new Date(item.createdAt).toLocaleDateString()}</span>
                  </div>

                  <div>
                    {item.isPromoted ? (
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold flex items-center gap-1">
                        <Flame className="w-3 h-3 text-emerald-400" />
                        <span>সক্রিয় বুস্ট ({item.daysRemaining} দিন বাকি)</span>
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full bg-white/5 text-slate-400 border border-white/10 text-[10px] font-semibold">
                        অপ্রমোটকৃত (নরমাল)
                      </span>
                    )}
                  </div>
                </div>

                <p className="text-xs text-slate-300 line-clamp-2">{item.content}</p>

                {/* Performance Analytics Grid */}
                <div className="grid grid-cols-3 gap-2 p-2.5 rounded-xl bg-slate-950/60 border border-white/5 text-center">
                  <div>
                    <span className="text-[10px] text-slate-400 block">মোট ভিউ</span>
                    <span className="text-sm font-bold text-cyan-400">{item.viewsCount}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">মোট ক্লিক</span>
                    <span className="text-sm font-bold text-amber-400">{item.clicksCount}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">খরচ</span>
                    <span className="text-sm font-bold text-emerald-400">
                      {item.totalCostBDT ? `৳${item.totalCostBDT}` : 'ফ্রি'}
                    </span>
                  </div>
                </div>

                {/* Action button */}
                <div className="flex items-center justify-between pt-1">
                  <a
                    href={item.linkUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-cyan-400 hover:underline flex items-center gap-1 truncate max-w-[200px]"
                  >
                    <span>{item.linkUrl}</span>
                    <ExternalLink className="w-3 h-3 shrink-0" />
                  </a>

                  <button
                    onClick={() => handleOpenBoostModal(item)}
                    className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 shadow transition active:scale-95 cursor-pointer"
                  >
                    <Rocket className="w-3.5 h-3.5" />
                    <span>{item.isPromoted ? 'বুস্ট বাড়ান' : 'এখনই বুস্ট করুন'}</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB 4: PACKAGES */}
      {activeTab === 'packages' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/30 to-yellow-950/30 border border-amber-500/20">
            <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>PANDA প্রমোশন প্যাকেজ তালিকা</span>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              স্বল্প খরচে সর্বোচ্চ রিচ ও আসল ট্রাফিক পান। প্রতিটি প্যাকেজে রয়েছে লাইভ ক্লিক ও ভিউ ট্র্যাকিং সুবিধা।
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            {packages.map((pkg) => (
              <div
                key={pkg.id}
                className={`relative rounded-2xl p-4 flex flex-col justify-between border transition ${
                  pkg.id === 'pkg-7days'
                    ? 'bg-gradient-to-b from-[#14233c] to-[#0a1324] border-cyan-400/50 shadow-lg shadow-cyan-500/10'
                    : 'bg-slate-900/80 border-white/10 hover:border-white/20'
                }`}
              >
                {pkg.id === 'pkg-7days' && (
                  <div className="absolute -top-2.5 right-4 px-2 py-0.5 rounded-full bg-cyan-500 text-slate-950 text-[10px] font-extrabold uppercase tracking-wider shadow">
                    সেরা অফার
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-bold text-white">{pkg.name}</h3>
                    <span className="text-[10px] px-2 py-0.5 rounded-md bg-white/5 text-cyan-300 border border-white/10">
                      {pkg.durationDays} দিন মেয়াদ
                    </span>
                  </div>

                  <div className="flex items-baseline gap-1 my-3">
                    <span className="text-2xl font-extrabold text-white">৳{pkg.priceBDT}</span>
                    <span className="text-xs text-slate-400 font-medium">/ {pkg.durationDays} দিন</span>
                  </div>

                  <p className="text-xs text-amber-300 font-semibold mb-3 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>আনুমানিক রিচ: {pkg.estimatedReach}</span>
                  </p>

                  <ul className="space-y-1.5 text-xs text-slate-300 mb-4">
                    {pkg.features.map((feat, i) => (
                      <li key={i} className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  onClick={() => {
                    if (myPromotions.length > 0) {
                      setSelectedPostToBoost(myPromotions[0]);
                      setSelectedPackageId(pkg.id);
                    } else {
                      setActiveTab('create');
                    }
                  }}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold shadow-md shadow-cyan-500/20 flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer"
                >
                  <Rocket className="w-3.5 h-3.5" />
                  <span>এই প্যাকেজটি নিন</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* BOOST MODAL */}
      {selectedPostToBoost && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0a1222] border border-cyan-500/40 rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Rocket className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-bold text-white">পোস্ট বুস্ট করুন</h3>
              </div>
              <button
                onClick={() => setSelectedPostToBoost(null)}
                className="text-slate-400 hover:text-white text-sm font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Selected Post Preview */}
            <div className="p-3 rounded-xl bg-slate-900 border border-white/10 text-xs">
              <span className="text-[10px] text-slate-400 block mb-1">নির্বাচিত পোস্ট:</span>
              <p className="text-white font-medium line-clamp-2">{selectedPostToBoost.content}</p>
              <p className="text-[11px] text-cyan-400 truncate mt-1">{selectedPostToBoost.linkUrl}</p>
            </div>

            {boostMsg && (
              <div
                className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 ${
                  boostMsg.type === 'success'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                }`}
              >
                {boostMsg.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{boostMsg.text}</span>
              </div>
            )}

            {/* Package Selection */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-2">
                প্যাকেজ নির্বাচন করুন:
              </label>
              <div className="space-y-2">
                {packages.map((pkg) => {
                  const isSelected = selectedPackageId === pkg.id;
                  return (
                    <div
                      key={pkg.id}
                      onClick={() => setSelectedPackageId(pkg.id)}
                      className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition ${
                        isSelected
                          ? 'bg-cyan-500/20 border-cyan-500 text-white shadow-md'
                          : 'bg-slate-900 border-white/5 text-slate-300 hover:bg-white/5'
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold">{pkg.name}</span>
                          <span className="text-[10px] text-amber-300 font-semibold">({pkg.durationDays} দিন)</span>
                        </div>
                        <span className="text-[10px] text-slate-400">রিচ: {pkg.estimatedReach}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-sm font-extrabold text-cyan-300">৳{pkg.priceBDT}</span>
                        <span className="text-[10px] text-slate-400 block">ওয়ালেট কর্তন</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* User Wallet Balance Checker */}
            <div className="p-3 rounded-xl bg-slate-950 border border-white/10 flex items-center justify-between text-xs">
              <span className="text-slate-400">আপনার বর্তমান ব্যালেন্স:</span>
              <span className="font-bold text-emerald-400">৳{user.bdtBalance.toFixed(2)} BDT</span>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleConfirmBoost}
                disabled={isBoosting}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-xs font-extrabold shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition active:scale-95 disabled:opacity-50 cursor-pointer"
              >
                {isBoosting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>প্রসেসিং হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <Rocket className="w-4 h-4" />
                    <span>পেমেন্ট নিশ্চিত করুন ও বুস্ট চালু করুন</span>
                  </>
                )}
              </button>

              <button
                onClick={() => setSelectedPostToBoost(null)}
                className="px-4 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-slate-400 cursor-pointer"
              >
                বাতিল
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REPORT / SPAM MODAL */}
      {reportingPost && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#0d1525] border border-rose-500/30 rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2 text-rose-400">
                <ShieldAlert className="w-5 h-5" />
                <h3 className="text-sm font-bold text-white">পোস্ট রিপোর্ট করুন</h3>
              </div>
              <button
                onClick={() => setReportingPost(null)}
                className="text-slate-400 hover:text-white text-sm font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {reportSuccessMsg ? (
              <div className="p-3 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold text-center">
                {reportSuccessMsg}
              </div>
            ) : (
              <>
                <p className="text-xs text-slate-300">
                  ভুল বা প্রতারণামূলক লিংক রিপোর্ট করে কমিউনিটিকে নিরাপদ রাখতে সাহায্য করুন। ৩টি রিপোর্ট আসলে পোস্টটি স্বয়ংক্রিয়ভাবে স্থগিত হবে।
                </p>

                <div className="space-y-1.5">
                  {[
                    'Spam or Scam (স্প্যাম বা প্রতারণা)',
                    'Phishing Link (ফিশিং বা বিপজ্জনক সাইট)',
                    'Misleading Info (ভুল তথ্য)',
                    'Inappropriate Content (অনুপযুক্ত কনটেন্ট)',
                    'Broken or Dead Link (অকার্যকর লিংক)',
                  ].map((reason) => (
                    <label
                      key={reason}
                      className="flex items-center gap-2 p-2 rounded-lg bg-slate-900 border border-white/5 text-xs text-slate-300 cursor-pointer hover:bg-white/5"
                    >
                      <input
                        type="radio"
                        name="report_reason"
                        checked={reportReason === reason}
                        onChange={() => setReportReason(reason)}
                        className="text-cyan-500"
                      />
                      <span>{reason}</span>
                    </label>
                  ))}
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    onClick={handleReport}
                    className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition active:scale-95 cursor-pointer"
                  >
                    রিপোর্ট জমা দিন
                  </button>
                  <button
                    onClick={() => setReportingPost(null)}
                    className="px-3 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs text-slate-400 cursor-pointer"
                  >
                    বাতিল
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
