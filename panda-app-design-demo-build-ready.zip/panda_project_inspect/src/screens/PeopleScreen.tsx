import React, { useState } from 'react';
import { Heart, Send, MessageSquare, Share2, Sparkles, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const PeopleScreen: React.FC = () => {
  const { posts, addPost, toggleLikePost, user } = useApp();
  const [newPostText, setNewPostText] = useState('');
  const [postedSuccess, setPostedSuccess] = useState(false);

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostText.trim()) return;
    addPost(newPostText.trim());
    setNewPostText('');
    setPostedSuccess(true);
    setTimeout(() => setPostedSuccess(false), 2000);
  };

  return (
    <div className="px-4 py-4 space-y-4 pb-20 select-none">
      {/* Create Post Card */}
      <div className="p-4 rounded-3xl bg-[#07143e]/90 border border-[#163884] shadow-lg space-y-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full overflow-hidden border border-cyan-400">
            <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white">{user.name}</h4>
            <span className="text-[10px] text-cyan-300">Share your earnings & tips</span>
          </div>
        </div>

        <form onSubmit={handlePostSubmit} className="space-y-2">
          <textarea
            value={newPostText}
            onChange={(e) => setNewPostText(e.target.value)}
            rows={2}
            placeholder="Share your payment proof, daily ads routine or tips with the community..."
            className="w-full p-3 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white placeholder-slate-400 text-xs focus:outline-none focus:border-cyan-400 resize-none"
          />

          <div className="flex items-center justify-between">
            {postedSuccess && (
              <span className="text-xs text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Published!
              </span>
            )}
            <div className="ml-auto">
              <button
                type="submit"
                disabled={!newPostText.trim()}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-blue-500/30 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Post Update</span>
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Community Feed */}
      <div className="space-y-3">
        <h3 className="font-heading font-bold text-sm text-white flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>Community Feed & Proofs</span>
        </h3>

        {posts.map((post) => (
          <div
            key={post.id}
            className="p-4 rounded-2xl bg-[#07143e]/90 border border-[#163884] shadow-md space-y-2.5"
          >
            {/* Author info */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full overflow-hidden border border-blue-400/50">
                  <img
                    src={post.authorAvatar}
                    alt={post.authorName}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/assets/app/user_rahim.png';
                    }}
                  />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">{post.authorName}</h4>
                  <span className="text-[10px] text-slate-400 font-mono">
                    ID: {post.authorId} • {post.timeAgo}
                  </span>
                </div>
              </div>

              {post.tag && (
                <span className="px-2 py-0.5 rounded-full bg-blue-900/50 border border-blue-500/30 text-[10px] font-semibold text-cyan-300">
                  {post.tag}
                </span>
              )}
            </div>

            {/* Post text */}
            <p className="text-xs text-slate-200 leading-relaxed">{post.content}</p>

            {/* Proof badge if exists */}
            {post.proofAmount && (
              <div className="p-2 rounded-xl bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-between text-xs text-emerald-300 font-semibold">
                <span>Verified Payout</span>
                <span className="font-heading font-bold text-[#ffcc00]">{post.proofAmount}</span>
              </div>
            )}

            {/* Actions: Like, Comment, Share */}
            <div className="flex items-center justify-between pt-2 border-t border-[#143477] text-xs text-slate-400">
              <button
                onClick={() => toggleLikePost(post.id)}
                className={`flex items-center gap-1.5 transition-colors ${
                  post.isLiked ? 'text-red-400 font-bold' : 'hover:text-slate-200'
                }`}
              >
                <Heart className={`w-4 h-4 ${post.isLiked ? 'fill-red-400' : ''}`} />
                <span>{post.likes}</span>
              </button>

              <button
                onClick={() => alert('Comments will open in next update!')}
                className="flex items-center gap-1.5 hover:text-slate-200 transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Comment</span>
              </button>

              <button
                onClick={() => alert('Post link copied to clipboard!')}
                className="flex items-center gap-1.5 hover:text-slate-200 transition-colors"
              >
                <Share2 className="w-4 h-4" />
                <span>Share</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
