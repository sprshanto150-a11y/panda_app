import React, { useState } from 'react';
import {
  FileText,
  Users,
  DollarSign,
  Settings,
  HelpCircle,
  LogOut,
  ChevronRight,
  Copy,
  Check,
  UserPlus,
  UserCheck,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ProfileScreen: React.FC = () => {
  const {
    user,
    setScreen,
    logout,
    setIsSupportOpen,
    toggleFollowUser,
    triggerConfetti,
  } = useApp();

  const [copied, setCopied] = useState(false);

  const copyReferralCode = () => {
    navigator.clipboard.writeText(user.referralCode);
    setCopied(true);
    triggerConfetti();
    setTimeout(() => setCopied(false), 2000);
  };

  const menuItems = [
    {
      id: 'posts',
      title: 'My Posts',
      icon: <FileText className="w-4 h-4 text-cyan-400" />,
      action: () => setScreen('people'),
    },
    {
      id: 'referrals',
      title: 'My Referrals',
      icon: <Users className="w-4 h-4 text-purple-400" />,
      action: () => setScreen('referral'),
    },
    {
      id: 'earnings',
      title: 'My Earnings',
      icon: <DollarSign className="w-4 h-4 text-emerald-400" />,
      action: () => setScreen('wallet'),
    },
    {
      id: 'settings',
      title: 'Settings',
      icon: <Settings className="w-4 h-4 text-slate-300" />,
      action: () => setScreen('settings'),
    },
    {
      id: 'support',
      title: 'Support',
      icon: <HelpCircle className="w-4 h-4 text-amber-400" />,
      action: () => setIsSupportOpen(true),
    },
    {
      id: 'logout',
      title: 'Logout',
      icon: <LogOut className="w-4 h-4 text-red-400" />,
      action: logout,
      danger: true,
    },
  ];

  return (
    <div className="px-4 py-4 space-y-4 pb-20 select-none">
      {/* 1. Profile Avatar & ID Card (matching mockup screen 9) */}
      <div className="flex flex-col items-center text-center p-5 rounded-3xl bg-gradient-to-b from-[#091e52] via-[#06153e] to-[#040e2b] border border-blue-500/40 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-24 bg-cyan-400/20 rounded-full blur-2xl pointer-events-none" />

        {/* Panda Head Avatar in glowing ring */}
        <div className="relative mb-3">
          <div className="w-24 h-24 rounded-full overflow-hidden border-3 border-cyan-400 p-0.5 shadow-[0_0_20px_rgba(0,229,255,0.6)]">
            <img
              src="/assets/app/panda_head.png"
              alt="Panda King"
              className="w-full h-full object-cover rounded-full"
            />
          </div>
        </div>

        {/* User Name */}
        <h2 className="font-heading font-black text-xl text-white tracking-wide">
          {user.name}
        </h2>

        {/* Referral Code Badge with Copy button */}
        <button
          onClick={copyReferralCode}
          className="mt-1 px-3 py-1 rounded-lg bg-[#0b266d] border border-cyan-400/50 hover:border-cyan-400 flex items-center gap-1.5 text-xs text-cyan-300 font-mono shadow-sm active:scale-95 transition-all group"
        >
          <span>[{user.referralCode}]</span>
          {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 group-hover:text-white" />}
          {copied && <span className="text-[10px] text-emerald-300">Copied!</span>}
        </button>

        {/* Follow Button (matches cyan pill button in mockup) */}
        <button
          onClick={toggleFollowUser}
          className={`mt-3 px-6 py-2 rounded-full text-xs font-bold transition-all shadow-md active:scale-95 flex items-center gap-1.5 ${
            user.isFollowing
              ? 'bg-blue-600 text-white shadow-blue-600/30'
              : 'bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-heading font-black shadow-cyan-400/30'
          }`}
        >
          {user.isFollowing ? (
            <>
              <UserCheck className="w-3.5 h-3.5" />
              <span>Following</span>
            </>
          ) : (
            <>
              <UserPlus className="w-3.5 h-3.5" />
              <span>+ Follow</span>
            </>
          )}
        </button>

        {/* 2. Stats Row: 120 Followers | 50 Following | 25 Posts */}
        <div className="grid grid-cols-3 divide-x divide-[#153477] w-full mt-5 pt-4 border-t border-[#153477]/80">
          <div className="text-center px-1">
            <div className="font-heading font-black text-base text-white tabular-nums">
              {user.followers}
            </div>
            <div className="text-[11px] text-slate-300 font-medium">Followers</div>
          </div>

          <div className="text-center px-1">
            <div className="font-heading font-black text-base text-white tabular-nums">
              {user.following}
            </div>
            <div className="text-[11px] text-slate-300 font-medium">Following</div>
          </div>

          <div className="text-center px-1">
            <div className="font-heading font-black text-base text-white tabular-nums">
              {user.postsCount}
            </div>
            <div className="text-[11px] text-slate-300 font-medium">Posts</div>
          </div>
        </div>
      </div>

      {/* 3. Menu list items matching mockup */}
      <div className="rounded-2xl bg-[#07143e]/90 border border-[#163884] shadow-lg divide-y divide-[#143477] overflow-hidden">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={item.action}
            className={`w-full flex items-center justify-between p-3.5 text-left transition-colors ${
              item.danger
                ? 'hover:bg-red-500/10 text-red-300'
                : 'hover:bg-[#0a1e58] text-slate-200'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-[#091a4e] flex items-center justify-center shrink-0">
                {item.icon}
              </div>
              <span className="text-sm font-semibold">{item.title}</span>
            </div>

            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>
        ))}
      </div>
    </div>
  );
};
