import React, { useState } from 'react';
import { Copy, Check, Users, Gift, Share2, Sparkles, Award } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ReferralScreen: React.FC = () => {
  const { user, triggerConfetti } = useApp();
  const [copied, setCopied] = useState(false);

  const referralLink = `https://panda.app/join?ref=${user.referralCode}`;

  const copyCode = () => {
    navigator.clipboard.writeText(user.referralCode);
    setCopied(true);
    triggerConfetti();
    setTimeout(() => setCopied(false), 2000);
  };

  const copyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    triggerConfetti();
    setTimeout(() => setCopied(false), 2000);
  };

  const referredUsers = [
    { name: 'Sakib Al Hasan', date: 'Yesterday', earned: '৳50', status: 'Active' },
    { name: 'Tanvir Ahmed', date: '2 days ago', earned: '৳50', status: 'Active' },
    { name: 'Minhazul Islam', date: 'Nov 02', earned: '৳50', status: 'Active' },
    { name: 'Rifat Hossain', date: 'Oct 28', earned: '৳50', status: 'Active' },
  ];

  return (
    <div className="px-4 py-4 space-y-4 pb-20 select-none">
      {/* 1. Header Banner */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-[#172554] via-[#1e3a8a] to-[#0f172a] border border-blue-500/40 shadow-xl space-y-2 text-center relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-400/10 rounded-full blur-2xl" />
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-400/20 text-cyan-300 text-xs font-bold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Lifetime Passive Income</span>
        </div>
        <h2 className="font-heading font-black text-xl text-white">
          Refer Friends, Earn Together!
        </h2>
        <p className="text-xs text-slate-300 max-w-xs mx-auto">
          Get 10% instant commission on every deposit and ad earnings of your referrals!
        </p>
      </div>

      {/* 2. Referral Code & Link Box */}
      <div className="p-4 rounded-3xl bg-[#07143e]/90 border border-[#163884] shadow-lg space-y-3">
        <div className="text-center">
          <span className="text-xs text-slate-300 font-medium">Your Unique Referral Code</span>
          <div className="mt-1 flex items-center justify-center gap-2">
            <div className="px-5 py-2.5 rounded-xl bg-[#091a4e] border-2 border-cyan-400 text-cyan-300 font-mono font-black text-lg tracking-widest shadow-[0_0_15px_rgba(0,229,255,0.3)]">
              {user.referralCode}
            </div>
            <button
              onClick={copyCode}
              className="p-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white shadow-md active:scale-95 transition-all"
            >
              {copied ? <Check className="w-5 h-5 text-emerald-300" /> : <Copy className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Share buttons */}
        <div className="grid grid-cols-2 gap-2 pt-2">
          <button
            onClick={copyLink}
            className="py-2.5 px-3 rounded-xl bg-[#0a1e58] border border-blue-500/40 text-xs text-cyan-300 font-bold hover:bg-[#0e2a7a] transition-all flex items-center justify-center gap-2"
          >
            <Share2 className="w-4 h-4" />
            <span>Copy Link</span>
          </button>

          <a
            href={`https://api.whatsapp.com/send?text=Join%20Panda%20App%20and%20earn%20BDT%20and%20USD%20daily!%20Use%20my%20referral%20code:%20${user.referralCode}`}
            target="_blank"
            rel="noreferrer"
            className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs text-white font-bold transition-all flex items-center justify-center gap-2 shadow-md shadow-emerald-600/30"
          >
            <Users className="w-4 h-4" />
            <span>Share WhatsApp</span>
          </a>
        </div>
      </div>

      {/* 3. Multi-tier commission breakdown */}
      <div className="grid grid-cols-3 gap-2">
        <div className="p-3 rounded-2xl bg-[#091a4e] border border-[#163884] text-center">
          <Award className="w-5 h-5 text-amber-400 mx-auto mb-1" />
          <div className="text-base font-heading font-black text-white">10%</div>
          <div className="text-[10px] text-slate-300">Level 1 (Direct)</div>
        </div>

        <div className="p-3 rounded-2xl bg-[#091a4e] border border-[#163884] text-center">
          <Award className="w-5 h-5 text-slate-300 mx-auto mb-1" />
          <div className="text-base font-heading font-black text-white">5%</div>
          <div className="text-[10px] text-slate-300">Level 2 (Friends)</div>
        </div>

        <div className="p-3 rounded-2xl bg-[#091a4e] border border-[#163884] text-center">
          <Award className="w-5 h-5 text-amber-700 mx-auto mb-1" />
          <div className="text-base font-heading font-black text-white">2%</div>
          <div className="text-[10px] text-slate-300">Level 3 (Network)</div>
        </div>
      </div>

      {/* 4. Invited Members List */}
      <div className="p-4 rounded-2xl bg-[#07143e]/90 border border-[#163884] shadow-lg space-y-2.5">
        <div className="flex items-center justify-between">
          <h3 className="font-heading font-bold text-white text-sm">
            My Referral Team ({referredUsers.length})
          </h3>
          <span className="text-xs text-emerald-400 font-bold font-mono">Total: ৳200 BDT</span>
        </div>

        <div className="space-y-2">
          {referredUsers.map((item, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between p-2.5 rounded-xl bg-[#091a4e]/70 border border-[#143477]"
            >
              <div>
                <h4 className="text-xs font-bold text-white">{item.name}</h4>
                <p className="text-[10px] text-slate-400">Joined {item.date}</p>
              </div>

              <div className="text-right">
                <span className="text-xs font-bold text-[#ffcc00] font-heading block">
                  +{item.earned}
                </span>
                <span className="text-[9px] text-emerald-400 font-medium">{item.status}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
