import React, { useState } from 'react';
import { ChevronLeft, User, Phone, Mail, Lock, Gift, Eye, EyeOff } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const RegisterScreen: React.FC = () => {
  const { setScreen, register } = useApp();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [refCode, setRefCode] = useState('PANDA1025');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please enter your full name');
      return;
    }
    if (!phone.trim()) {
      setError('Please enter your phone number');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setError('');
    register(name, phone, email, password, refCode);
  };

  return (
    <div className="min-h-[90vh] flex flex-col justify-center px-6 py-4 select-none relative">
      {/* Back button */}
      <div className="absolute top-4 left-4 z-20">
        <button
          onClick={() => setScreen('login')}
          className="w-10 h-10 flex items-center justify-center text-slate-300 hover:text-white rounded-xl active:bg-blue-900/30 transition-colors"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
      </div>

      {/* Background glow */}
      <div className="absolute top-12 left-1/2 -translate-x-1/2 w-64 h-64 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />

      {/* Mascot & Header */}
      <div className="flex flex-col items-center text-center mb-4 z-10">
        <div className="relative w-24 h-24 mb-1">
          <div className="absolute inset-0 bg-blue-500/25 rounded-full blur-md" />
          <img
            src="/assets/app/panda_head.png"
            alt="Panda King Mascot"
            className="w-full h-full object-contain relative filter drop-shadow-[0_0_12px_rgba(0,140,255,0.6)]"
          />
        </div>
        <h1 className="font-heading text-2xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white via-blue-100 to-blue-200 tracking-wider">
          PANDA APP
        </h1>
        <p className="text-white text-base font-bold mt-0.5">Create Account</p>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="w-full max-w-sm mx-auto space-y-3 z-10">
        {error && (
          <div className="p-2.5 rounded-xl bg-red-500/20 border border-red-500/40 text-red-200 text-xs text-center">
            {error}
          </div>
        )}

        {/* Full Name */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <User className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Full Name"
            className="w-full pl-10 pr-4 py-2.5 bg-[#08153c]/90 border border-[#1b3d88] rounded-xl text-white placeholder-slate-400 text-sm focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all shadow-inner"
          />
        </div>

        {/* Phone Number */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Phone className="w-4 h-4" />
          </div>
          <input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="Phone Number"
            className="w-full pl-10 pr-4 py-2.5 bg-[#08153c]/90 border border-[#1b3d88] rounded-xl text-white placeholder-slate-400 text-sm focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all shadow-inner"
          />
        </div>

        {/* Email Address */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Mail className="w-4 h-4" />
          </div>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email Address"
            className="w-full pl-10 pr-4 py-2.5 bg-[#08153c]/90 border border-[#1b3d88] rounded-xl text-white placeholder-slate-400 text-sm focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all shadow-inner"
          />
        </div>

        {/* Password */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Lock className="w-4 h-4" />
          </div>
          <input
            type={showPassword ? 'text' : 'password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="w-full pl-10 pr-10 py-2.5 bg-[#08153c]/90 border border-[#1b3d88] rounded-xl text-white placeholder-slate-400 text-sm focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all shadow-inner"
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200"
          >
            {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>

        {/* Referral Code (Optional) */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Gift className="w-4 h-4 text-amber-400" />
          </div>
          <input
            type="text"
            value={refCode}
            onChange={(e) => setRefCode(e.target.value)}
            placeholder="Referral Code (Optional)"
            className="w-full pl-10 pr-4 py-2.5 bg-[#08153c]/90 border border-[#1b3d88] rounded-xl text-white placeholder-slate-400 text-sm focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all shadow-inner"
          />
        </div>

        {/* Register Button */}
        <button
          type="submit"
          className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#0062ff] to-[#0099ff] hover:from-[#0052df] hover:to-[#0088ee] text-white font-bold text-sm tracking-wide shadow-lg shadow-blue-600/40 active:scale-98 transition-all mt-2"
        >
          Register
        </button>

        {/* Switch to Login */}
        <div className="text-center text-xs text-slate-300 pt-3">
          Already have an account?{' '}
          <button
            type="button"
            onClick={() => setScreen('login')}
            className="text-cyan-400 hover:underline font-bold"
          >
            Login
          </button>
        </div>
      </form>
    </div>
  );
};
