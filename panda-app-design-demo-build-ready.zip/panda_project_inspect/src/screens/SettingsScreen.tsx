import React, { useState } from 'react';
import { User, Phone, Mail, Shield, CheckCircle2, Globe, Bell } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const SettingsScreen: React.FC = () => {
  const { user, setUser, goBack, triggerConfetti } = useApp();
  const [name, setName] = useState(user.name);
  const [phone, setPhone] = useState(user.phone);
  const [email, setEmail] = useState(user.email);
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setUser((prev) => ({
      ...prev,
      name: name.trim() || prev.name,
      phone: phone.trim() || prev.phone,
      email: email.trim() || prev.email,
    }));
    setSavedSuccess(true);
    triggerConfetti();
    setTimeout(() => {
      setSavedSuccess(false);
      goBack();
    }, 1500);
  };

  return (
    <div className="px-4 py-4 space-y-4 pb-20 select-none">
      {savedSuccess && (
        <div className="p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>Profile settings updated successfully!</span>
        </div>
      )}

      {/* Account Settings */}
      <form onSubmit={handleSave} className="p-4 rounded-3xl bg-[#07143e]/90 border border-[#163884] shadow-lg space-y-3.5">
        <h3 className="font-heading font-bold text-sm text-white flex items-center gap-2">
          <User className="w-4 h-4 text-cyan-400" />
          <span>Edit Profile Information</span>
        </h3>

        <div>
          <label className="text-[11px] text-slate-300 block mb-1">Full Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3.5 py-2.5 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs focus:outline-none focus:border-cyan-400"
          />
        </div>

        <div>
          <label className="text-[11px] text-slate-300 block mb-1">Phone Number</label>
          <input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full px-3.5 py-2.5 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs focus:outline-none focus:border-cyan-400 font-mono"
          />
        </div>

        <div>
          <label className="text-[11px] text-slate-300 block mb-1">Email Address</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-3.5 py-2.5 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white text-xs focus:outline-none focus:border-cyan-400"
          />
        </div>

        <button
          type="submit"
          className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-heading font-black text-xs uppercase tracking-wider shadow-lg shadow-blue-500/30 transition-all"
        >
          Save Changes
        </button>
      </form>

      {/* Preferences */}
      <div className="p-4 rounded-3xl bg-[#07143e]/90 border border-[#163884] shadow-lg space-y-3">
        <h3 className="font-heading font-bold text-sm text-white flex items-center gap-2">
          <Globe className="w-4 h-4 text-amber-400" />
          <span>App Preferences</span>
        </h3>

        {/* Language switch */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-[#091a4e]/70 border border-[#143477]">
          <div>
            <span className="text-xs font-semibold text-white block">Language</span>
            <span className="text-[10px] text-slate-400">English / বাংলা</span>
          </div>

          <div className="flex items-center gap-1 bg-[#061233] p-1 rounded-lg border border-blue-500/30">
            <button
              type="button"
              onClick={() => setLanguage('en')}
              className={`px-2.5 py-1 rounded text-xs font-bold ${
                language === 'en' ? 'bg-blue-600 text-white' : 'text-slate-400'
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => setLanguage('bn')}
              className={`px-2.5 py-1 rounded text-xs font-bold ${
                language === 'bn' ? 'bg-blue-600 text-white' : 'text-slate-400'
              }`}
            >
              বাংলা
            </button>
          </div>
        </div>

        {/* Notification toggle */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-[#091a4e]/70 border border-[#143477]">
          <div>
            <span className="text-xs font-semibold text-white block">Push Notifications</span>
            <span className="text-[10px] text-slate-400">Payout and referral alerts</span>
          </div>

          <button
            type="button"
            onClick={() => setNotificationsEnabled(!notificationsEnabled)}
            className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
              notificationsEnabled ? 'bg-cyan-500' : 'bg-slate-700'
            }`}
          >
            <div
              className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                notificationsEnabled ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  );
};
