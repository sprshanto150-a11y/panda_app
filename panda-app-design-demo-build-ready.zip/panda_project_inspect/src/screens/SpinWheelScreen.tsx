import React, { useState } from 'react';
import { Sparkles, Trophy, RotateCcw, AlertTriangle, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const SpinWheelScreen: React.FC = () => {
  const { completeCustomTask, goBack, triggerConfetti } = useApp();
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [wonPrize, setWonPrize] = useState<number | null>(null);
  const [spinsLeft, setSpinsLeft] = useState(1);

  const prizes = [5, 10, 15, 20, 25, 50, 8, 12];

  const handleSpin = () => {
    if (spinning || spinsLeft <= 0) return;

    setSpinning(true);
    setWonPrize(null);

    // Pick random prize index
    const randomIndex = Math.floor(Math.random() * prizes.length);
    const selectedPrize = prizes[randomIndex];

    // Calculate rotation: 5 full turns (1800 deg) + prize angle
    const segmentAngle = 360 / prizes.length;
    const finalAngle = 1800 + randomIndex * segmentAngle + segmentAngle / 2;

    setRotation((prev) => prev + finalAngle);

    setTimeout(async () => {
      setSpinning(false);
      setWonPrize(selectedPrize);
      setSpinsLeft((prev) => prev - 1);
      triggerConfetti();

      // Submit to backend
      await completeCustomTask('TASK-03', selectedPrize);
    }, 3500);
  };

  return (
    <div className="px-4 py-4 space-y-4 pb-20 select-none text-center">
      {/* Sandbox Test Banner */}
      <div className="p-3 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs flex items-center gap-2">
        <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
        <span>DEMO TEST DATA: Earning rewards are test credits in sandbox mode.</span>
      </div>

      {/* Header */}
      <div className="space-y-1">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-400/20 text-cyan-300 text-xs font-bold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Lucky Spin & Win</span>
        </div>
        <h2 className="font-heading font-black text-xl text-white">Daily Lucky Wheel</h2>
        <p className="text-xs text-slate-300">
          Spin once daily to win up to ৳50 BDT test reward instantly!
        </p>
      </div>

      {/* Spin Wheel Graphic Container */}
      <div className="relative w-64 h-64 mx-auto my-6 flex items-center justify-center">
        {/* Outer Ring Glow */}
        <div className="absolute inset-0 rounded-full border-4 border-amber-400/60 shadow-[0_0_30px_rgba(245,158,11,0.4)] pointer-events-none" />

        {/* Top Marker Arrow */}
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-20 w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[20px] border-t-amber-400 filter drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]" />

        {/* Rotating Wheel */}
        <div
          className="w-56 h-56 rounded-full overflow-hidden relative shadow-2xl transition-transform duration-[3500ms] cubic-bezier(0.15, 0.9, 0.2, 1)"
          style={{ transform: `rotate(${rotation}deg)` }}
        >
          {prizes.map((prize, idx) => {
            const angle = idx * (360 / prizes.length);
            const isGold = idx % 2 === 0;
            return (
              <div
                key={idx}
                className={`absolute w-full h-full top-0 left-0 flex justify-center items-start pt-3 ${
                  isGold
                    ? 'bg-gradient-to-b from-[#f0b90b] to-[#b8860b] text-black'
                    : 'bg-gradient-to-b from-[#0b246a] to-[#040e2d] text-white'
                }`}
                style={{
                  clipPath: 'polygon(50% 50%, 30% 0%, 70% 0%)',
                  transform: `rotate(${angle}deg)`,
                  transformOrigin: '50% 50%',
                }}
              >
                <span className="font-heading font-black text-xs font-mono drop-shadow">
                  ৳{prize}
                </span>
              </div>
            );
          })}

          {/* Wheel Center Button / Panda */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-14 h-14 rounded-full bg-[#050e2d] border-2 border-amber-400 flex items-center justify-center shadow-lg">
            <img src="/assets/app/panda_head.png" alt="Panda" className="w-10 h-10 object-contain" />
          </div>
        </div>
      </div>

      {/* Won Prize Banner */}
      {wonPrize && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/80 to-emerald-900/60 border border-emerald-400 text-center space-y-1 animate-bounce">
          <Trophy className="w-8 h-8 text-amber-300 mx-auto" />
          <h3 className="font-heading font-black text-lg text-white">Congratulations! 🎉</h3>
          <p className="text-sm font-bold text-[#ffcc00]">You won ৳{wonPrize} BDT Test Reward!</p>
          <p className="text-[11px] text-emerald-200">Amount has been credited to your wallet balance.</p>
        </div>
      )}

      {/* Controls */}
      <div className="space-y-2">
        <button
          onClick={handleSpin}
          disabled={spinning || spinsLeft <= 0}
          className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 text-black font-heading font-black text-sm tracking-wide shadow-lg shadow-amber-500/30 active:scale-98 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          <RotateCcw className={`w-4 h-4 ${spinning ? 'animate-spin' : ''}`} />
          <span>{spinning ? 'Spinning...' : spinsLeft > 0 ? 'Spin the Wheel Now' : 'Come Back Tomorrow'}</span>
        </button>

        <button
          onClick={goBack}
          className="text-xs text-slate-400 hover:text-white pt-2 inline-flex items-center gap-1"
        >
          <span>Back to Earning Tasks</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
