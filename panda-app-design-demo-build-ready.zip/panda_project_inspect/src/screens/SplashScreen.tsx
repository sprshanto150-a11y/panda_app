import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { ArrowRight, Sparkles } from 'lucide-react';

export const SplashScreen: React.FC = () => {
  const { setScreen, isLoggedIn } = useApp();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          return 100;
        }
        return prev + 15;
      });
    }, 200);

    return () => clearInterval(timer);
  }, []);

  const handleContinue = () => {
    if (isLoggedIn) {
      setScreen('home');
    } else {
      setScreen('login');
    }
  };

  return (
    <div className="min-h-[85vh] flex flex-col items-center justify-between p-6 text-center relative overflow-hidden select-none">
      {/* Background Glowing Rings & Atmosphere */}
      <div className="absolute top-1/4 -translate-y-1/2 left-1/2 -translate-x-1/2 w-80 h-80 bg-blue-600/25 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-64 h-64 border border-blue-500/20 rounded-full animate-pulse pointer-events-none" />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-72 h-72 border border-cyan-400/15 rounded-full pointer-events-none" />

      {/* Top spacer */}
      <div className="h-6" />

      {/* Center Mascot & Branding */}
      <div className="flex flex-col items-center z-10 w-full max-w-xs">
        {/* Mascot with glowing circle */}
        <div className="relative mb-6">
          <div className="absolute inset-0 rounded-full bg-blue-500/30 blur-xl animate-pulse" />
          <div className="relative w-44 h-48 mx-auto flex items-center justify-center">
            <img
              src="/assets/app/panda_mascot_full.png"
              alt="Panda King Mascot"
              className="w-full h-full object-contain filter drop-shadow-[0_0_20px_rgba(0,140,255,0.7)]"
              onError={(e) => {
                // fallback to head
                (e.target as HTMLImageElement).src = '/assets/app/panda_head.png';
              }}
            />
          </div>
        </div>

        {/* Titles matching mockup */}
        <h1 className="font-heading text-4xl sm:text-5xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-b from-white via-blue-100 to-blue-300 drop-shadow-[0_0_20px_rgba(0,140,255,0.8)]">
          PANDA APP
        </h1>
        <p className="mt-2 text-base font-semibold italic tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400 drop-shadow-[0_0_8px_rgba(255,200,0,0.5)]">
          Earn • Share • Grow
        </p>
      </div>

      {/* Bottom Loading Progress Bar */}
      <div className="w-full max-w-xs z-10 space-y-3 pb-6">
        <div className="relative w-full h-3.5 bg-[#071338] rounded-full border border-blue-500/40 p-0.5 overflow-hidden shadow-[0_0_15px_rgba(0,102,255,0.3)]">
          <div
            className="h-full bg-gradient-to-r from-cyan-400 via-blue-500 to-blue-400 rounded-full transition-all duration-300 shadow-[0_0_12px_rgba(0,229,255,0.8)]"
            style={{ width: `${Math.min(progress, 100)}%` }}
          />
        </div>

        <div className="flex items-center justify-between text-xs text-slate-300 px-1 font-medium">
          <span className="flex items-center gap-1.5 text-blue-200">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
            Loading...
          </span>
          <span className="font-mono text-cyan-300">{progress}%</span>
        </div>

        <button
          onClick={handleContinue}
          className="w-full mt-4 py-3 px-4 rounded-xl bg-gradient-to-r from-[#0062ff] to-[#0099ff] hover:from-[#0052df] hover:to-[#0088ee] text-white font-bold text-sm tracking-wide shadow-lg shadow-blue-600/40 active:scale-98 transition-all flex items-center justify-center gap-2 group"
        >
          <span>Enter Panda App</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
};
