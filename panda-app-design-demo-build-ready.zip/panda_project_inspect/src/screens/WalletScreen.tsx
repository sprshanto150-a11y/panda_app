import React, { useState } from 'react';
import {
  ChevronRight,
  ArrowDownCircle,
  Clock,
  CheckCircle2,
  AlertCircle,
  PlusCircle,
  CreditCard,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CurrencyType } from '../types';

export const WalletScreen: React.FC = () => {
  const {
    user,
    setScreen,
    transactions,
    selectedWalletTab,
    setSelectedWalletTab,
  } = useApp();

  const [filterType, setFilterType] = useState<'all' | 'deposit' | 'withdraw' | 'rewards'>('all');

  const filteredTransactions = transactions.filter((t) => {
    if (filterType === 'deposit') return t.type === 'deposit';
    if (filterType === 'withdraw') return t.type === 'withdraw';
    if (filterType === 'rewards') return t.type === 'referral' || t.type === 'ads_reward';
    return true;
  });

  return (
    <div className="px-4 py-4 space-y-4 pb-20 select-none">
      {/* Sandbox Testnet Demo Banner */}
      <div className="p-3 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs flex items-center gap-2">
        <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
        <span>
          <strong>DEMO DATA ONLY:</strong> Real deposits & cashouts are disabled until merchant APIs are integrated.
        </span>
      </div>

      {/* 1. Large Glowing Total Balance Card */}
      <div className="relative overflow-hidden p-6 rounded-3xl bg-gradient-to-b from-[#0b2569] via-[#07194d] to-[#040e2d] border border-blue-500/40 text-center shadow-2xl shadow-blue-900/40">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-20 bg-cyan-400/15 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-center gap-2 mb-1">
          <p className="text-xs font-semibold text-blue-200 uppercase tracking-widest">
            Total Balance
          </p>
          <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 font-mono border border-cyan-400/40">
            TESTNET
          </span>
        </div>

        <div className="text-3xl sm:text-4xl font-heading font-black text-white tracking-tight tabular-nums drop-shadow-[0_0_15px_rgba(0,180,255,0.6)]">
          {selectedWalletTab === 'BDT'
            ? `৳${user.bdtBalance.toFixed(2)}`
            : `$${user.usdBalance.toFixed(2)}`}
        </div>

        <p className="text-[11px] text-cyan-300 mt-1 font-mono">
          {selectedWalletTab === 'BDT'
            ? `≈ $${(user.bdtBalance / 120).toFixed(2)} USD`
            : `≈ ৳${(user.usdBalance * 120).toFixed(2)} BDT`}
        </p>
      </div>

      {/* 2. Currency Selector Tabs [BDT (Nagad)] [USD (Binance)] */}
      <div className="grid grid-cols-2 gap-2 p-1 bg-[#06143b] border border-[#163884] rounded-2xl">
        <button
          onClick={() => setSelectedWalletTab('BDT')}
          className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            selectedWalletTab === 'BDT'
              ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-lg shadow-blue-600/30'
              : 'text-slate-300 hover:text-white'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          BDT (Nagad)
        </button>

        <button
          onClick={() => setSelectedWalletTab('USD')}
          className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            selectedWalletTab === 'USD'
              ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-black shadow-lg shadow-yellow-500/30'
              : 'text-slate-300 hover:text-white'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-yellow-400" />
          USD (Binance)
        </button>
      </div>

      {/* 3. Two Large Action Cards: Deposit (Nagad) & Deposit (Binance) */}
      <div className="grid grid-cols-2 gap-3">
        {/* Deposit Nagad Button Card */}
        <button
          onClick={() => {
            setSelectedWalletTab('BDT');
            setScreen('deposit');
          }}
          className="flex flex-col items-center justify-center p-4 rounded-2xl bg-[#091f52]/90 border border-emerald-500/40 hover:border-emerald-400 hover:bg-[#0c2b70] active:scale-95 transition-all shadow-lg group"
        >
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-red-600 to-orange-500 p-2 mb-2 flex items-center justify-center shadow-[0_0_12px_rgba(235,28,36,0.4)] group-hover:scale-105 transition-transform">
            <img
              src="/assets/app/nagad_logo.png"
              alt="Nagad"
              className="w-full h-full object-contain filter brightness-110"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </div>
          <span className="font-heading font-extrabold text-sm text-emerald-300 group-hover:text-white">
            Deposit
          </span>
          <span className="text-[11px] text-slate-300 font-medium">(Nagad)</span>
        </button>

        {/* Deposit Binance Button Card */}
        <button
          onClick={() => {
            setSelectedWalletTab('USD');
            setScreen('deposit');
          }}
          className="flex flex-col items-center justify-center p-4 rounded-2xl bg-[#091f52]/90 border border-yellow-500/40 hover:border-yellow-400 hover:bg-[#0c2b70] active:scale-95 transition-all shadow-lg group"
        >
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-yellow-500 to-amber-600 p-2 mb-2 flex items-center justify-center shadow-[0_0_12px_rgba(240,185,11,0.4)] group-hover:scale-105 transition-transform">
            <img
              src="/assets/app/binance_logo.png"
              alt="Binance"
              className="w-full h-full object-contain filter brightness-110"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </div>
          <span className="font-heading font-extrabold text-sm text-yellow-300 group-hover:text-white">
            Deposit
          </span>
          <span className="text-[11px] text-slate-300 font-medium">(Binance)</span>
        </button>
      </div>

      {/* Quick Withdraw Bar */}
      <div className="flex items-center justify-between p-3 rounded-xl bg-[#071744] border border-[#173b88]">
        <div className="flex items-center gap-2">
          <CreditCard className="w-4 h-4 text-cyan-400" />
          <span className="text-xs text-slate-200">Need to withdraw your funds?</span>
        </div>
        <button
          onClick={() => setScreen('withdraw')}
          className="px-3 py-1.5 rounded-lg bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-bold text-xs shadow-md transition-colors"
        >
          Withdraw
        </button>
      </div>

      {/* 4. Transaction History Section */}
      <div className="p-4 rounded-2xl bg-[#07143e]/90 border border-[#163884] shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-heading font-bold text-white text-sm tracking-wide">
            Transaction History
          </h3>
          <div className="flex items-center gap-1.5 text-xs text-cyan-400">
            <span>Live Sync</span>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 pb-2 mb-2 overflow-x-auto text-[11px]">
          {(['all', 'deposit', 'withdraw', 'rewards'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setFilterType(tab)}
              className={`px-2.5 py-1 rounded-lg capitalize font-medium transition-colors ${
                filterType === tab
                  ? 'bg-blue-600 text-white'
                  : 'bg-[#0a1e54] text-slate-300 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Transaction Items */}
        <div className="space-y-2">
          {filteredTransactions.length === 0 ? (
            <div className="text-center py-6 text-xs text-slate-400">
              No transactions found in this category.
            </div>
          ) : (
            filteredTransactions.map((tx) => {
              const isPositive = tx.type === 'deposit' || tx.type === 'referral' || tx.type === 'ads_reward';
              return (
                <div
                  key={tx.id}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-[#091a4e]/70 border border-[#143477] hover:border-blue-400/40 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        tx.type === 'deposit'
                          ? 'bg-blue-500/20 text-cyan-400 border border-blue-500/30'
                          : tx.type === 'withdraw'
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      {tx.type === 'deposit' ? (
                        <ArrowDownCircle className="w-5 h-5" />
                      ) : tx.type === 'withdraw' ? (
                        <CreditCard className="w-5 h-5" />
                      ) : (
                        <PlusCircle className="w-5 h-5" />
                      )}
                    </div>

                    <div>
                      <h4 className="text-xs font-bold text-white leading-tight">{tx.title}</h4>
                      <p className="text-[10px] text-slate-400 mt-0.5 font-mono">
                        {tx.timestamp} {tx.method ? `• ${tx.method}` : ''}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <div
                      className={`text-xs font-bold font-heading tabular-nums ${
                        isPositive ? 'text-[#ffcc00]' : 'text-slate-100'
                      }`}
                    >
                      {isPositive ? '+' : '-'}
                      {tx.currency === 'BDT' ? `৳${tx.amount.toLocaleString()}` : `$${tx.amount.toFixed(2)}`}
                    </div>

                    <span
                      className={`inline-block text-[10px] font-semibold mt-0.5 ${
                        tx.status === 'Completed' || tx.status === 'Approved'
                          ? 'text-emerald-400'
                          : tx.status === 'Pending'
                          ? 'text-amber-400'
                          : 'text-red-400'
                      }`}
                    >
                      {tx.status}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
