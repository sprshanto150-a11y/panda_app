import React, { useState } from 'react';
import { ShieldCheck, ArrowRight, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const WithdrawScreen: React.FC = () => {
  const { user, addWithdraw, setScreen } = useApp();

  // Nagad form state
  const [nagadNumber, setNagadNumber] = useState(user.phone || '01712345678');
  const [nagadAmount, setNagadAmount] = useState('200');

  // Binance form state
  const [binancePayId, setBinancePayId] = useState('83920194');
  const [binanceAmount, setBinanceAmount] = useState('10');

  // Status message
  const [statusMsg, setStatusMsg] = useState<{ text: string; isError: boolean } | null>(null);

  const handleNagadWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg(null);

    if (!nagadNumber.trim() || nagadNumber.length < 11) {
      setStatusMsg({ text: 'Please enter a valid 11-digit Nagad number', isError: true });
      return;
    }

    const amt = parseFloat(nagadAmount);
    if (isNaN(amt) || amt <= 0) {
      setStatusMsg({ text: 'Please enter a valid withdrawal amount', isError: true });
      return;
    }

    const res = await addWithdraw(amt, 'Nagad', nagadNumber);
    if (res.success) {
      setStatusMsg({ text: res.message, isError: false });
      setTimeout(() => {
        setScreen('wallet');
      }, 1500);
    } else {
      setStatusMsg({ text: res.message, isError: true });
    }
  };

  const handleBinanceWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg(null);

    if (!binancePayId.trim()) {
      setStatusMsg({ text: 'Please enter your Binance Pay ID', isError: true });
      return;
    }

    const amt = parseFloat(binanceAmount);
    if (isNaN(amt) || amt <= 0) {
      setStatusMsg({ text: 'Please enter a valid USD amount', isError: true });
      return;
    }

    const res = await addWithdraw(amt, 'Binance', binancePayId);
    if (res.success) {
      setStatusMsg({ text: res.message, isError: false });
      setTimeout(() => {
        setScreen('wallet');
      }, 1500);
    } else {
      setStatusMsg({ text: res.message, isError: true });
    }
  };

  return (
    <div className="px-4 py-4 space-y-4 pb-20 select-none">
      {/* Sandbox Testnet Demo Banner */}
      <div className="p-3 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs flex items-center gap-2">
        <ShieldCheck className="w-4 h-4 shrink-0 text-amber-400" />
        <span>
          <strong>TESTNET CASH-OUT:</strong> Real cashouts are locked until official gateway merchant credentials are wired.
        </span>
      </div>

      {/* Feedback banner */}
      {statusMsg && (
        <div
          className={`p-3 rounded-2xl text-xs font-semibold flex items-center gap-2 ${
            statusMsg.isError
              ? 'bg-red-500/20 border border-red-500/40 text-red-200'
              : 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-300'
          }`}
        >
          {!statusMsg.isError && <CheckCircle2 className="w-4 h-4 shrink-0" />}
          <span>{statusMsg.text}</span>
        </div>
      )}

      {/* 1. Withdraw with Nagad Card (matching mockup screen 7) */}
      <div className="p-4 rounded-3xl bg-gradient-to-b from-[#091e4f] to-[#051131] border border-blue-500/40 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-red-600 via-orange-500 to-amber-500 p-2 flex items-center justify-center shadow-[0_0_12px_rgba(235,28,36,0.5)]">
              <img
                src="/assets/app/nagad_logo.png"
                alt="Nagad"
                className="w-full h-full object-contain filter brightness-110"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
            <div>
              <h3 className="font-heading font-black text-base text-white leading-tight">
                Withdraw with Nagad
              </h3>
              <p className="text-xs font-semibold text-emerald-400">৳100 - ৳10,000</p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-slate-300 block">Available:</span>
            <span className="text-xs font-bold text-emerald-400 font-mono">
              ৳{user.bdtBalance.toFixed(2)}
            </span>
          </div>
        </div>

        <form onSubmit={handleNagadWithdraw} className="space-y-3 pt-1">
          {/* Nagad Number */}
          <div>
            <label className="text-[11px] text-slate-300 block mb-1 font-medium">
              Nagad Number
            </label>
            <input
              type="tel"
              value={nagadNumber}
              onChange={(e) => setNagadNumber(e.target.value)}
              placeholder="Nagad Number"
              className="w-full px-3.5 py-2.5 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white placeholder-slate-400 text-sm font-semibold focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition-all font-mono"
            />
          </div>

          {/* Amount (BDT) */}
          <div>
            <label className="text-[11px] text-slate-300 block mb-1 font-medium">
              Amount (BDT)
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center font-bold text-slate-400">
                ৳
              </span>
              <input
                type="number"
                value={nagadAmount}
                onChange={(e) => setNagadAmount(e.target.value)}
                placeholder="Amount (BDT)"
                className="w-full pl-8 pr-4 py-2.5 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white placeholder-slate-400 text-sm font-semibold focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition-all font-mono"
              />
            </div>
          </div>

          {/* Green Button */}
          <button
            type="submit"
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#00c853] to-[#00e676] hover:from-[#00b248] hover:to-[#00d069] text-black font-heading font-black text-sm tracking-wide shadow-lg shadow-emerald-500/30 active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            <span>Withdraw to Nagad</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>

      {/* 2. Withdraw with Binance Card (matching mockup screen 7) */}
      <div className="p-4 rounded-3xl bg-gradient-to-b from-[#091e4f] to-[#051131] border border-blue-500/40 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-yellow-500 via-amber-500 to-yellow-600 p-2 flex items-center justify-center shadow-[0_0_12px_rgba(240,185,11,0.5)]">
              <img
                src="/assets/app/binance_logo.png"
                alt="Binance"
                className="w-full h-full object-contain filter brightness-110"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
            <div>
              <h3 className="font-heading font-black text-base text-white leading-tight">
                Withdraw with Binance
              </h3>
              <p className="text-xs font-semibold text-yellow-400">$5 Minimum</p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-slate-300 block">Available:</span>
            <span className="text-xs font-bold text-yellow-400 font-mono">
              ${user.usdBalance.toFixed(2)}
            </span>
          </div>
        </div>

        <form onSubmit={handleBinanceWithdraw} className="space-y-3 pt-1">
          {/* Binance Pay ID */}
          <div>
            <label className="text-[11px] text-slate-300 block mb-1 font-medium">
              Binance Pay ID
            </label>
            <input
              type="text"
              value={binancePayId}
              onChange={(e) => setBinancePayId(e.target.value)}
              placeholder="Binance Pay ID"
              className="w-full px-3.5 py-2.5 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white placeholder-slate-400 text-sm font-semibold focus:outline-none focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 transition-all font-mono"
            />
          </div>

          {/* Amount (USD) */}
          <div>
            <label className="text-[11px] text-slate-300 block mb-1 font-medium">
              Amount (USD)
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center font-bold text-slate-400">
                $
              </span>
              <input
                type="number"
                value={binanceAmount}
                onChange={(e) => setBinanceAmount(e.target.value)}
                placeholder="Amount (USD)"
                className="w-full pl-8 pr-4 py-2.5 bg-[#061234] border border-[#1b3e8b] rounded-xl text-white placeholder-slate-400 text-sm font-semibold focus:outline-none focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 transition-all font-mono"
              />
            </div>
          </div>

          {/* Yellow Button */}
          <button
            type="submit"
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#f0b90b] to-[#f8d33a] hover:from-[#dfab08] hover:to-[#eec92c] text-black font-heading font-black text-sm tracking-wide shadow-lg shadow-yellow-500/30 active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            <span>Withdraw to Binance</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>

      {/* Information card */}
      <div className="p-3 rounded-2xl bg-[#07153a] border border-[#123170] text-slate-300 text-[11px] space-y-1">
        <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
          <ShieldCheck className="w-4 h-4" />
          <span>Instant Automated Payouts</span>
        </div>
        <p>
          Withdrawals to Nagad and Binance Pay are processed automatically. 0% fee on first 3
          withdrawals every month!
        </p>
      </div>
    </div>
  );
};
