export type ScreenType =
  | 'splash'
  | 'login'
  | 'register'
  | 'home'
  | 'wallet'
  | 'deposit'
  | 'withdraw'
  | 'leaderboard'
  | 'profile'
  | 'ads'
  | 'referral'
  | 'people'
  | 'settings'
  | 'admin'
  | 'spin'
  | 'quiz'
  | 'apk_guide'
  | 'promotion';

export type CurrencyType = 'BDT' | 'USD';

export type PaymentMethod = 'nagad' | 'binance';

export interface UserProfile {
  id: string; // e.g. PANDA1025
  name: string;
  username: string;
  email: string;
  phone: string;
  avatar: string;
  bdtBalance: number;
  usdBalance: number;
  referralCode: string;
  referredBy?: string;
  role?: 'user' | 'admin';
  isBanned?: boolean;
  followers: number;
  following: number;
  postsCount: number;
  isFollowing?: boolean;
}

export interface Transaction {
  id: string;
  userId?: string;
  userName?: string;
  type: 'deposit' | 'withdraw' | 'referral' | 'ads_reward' | 'task_reward' | 'promotion_boost';
  title: string;
  method: 'Nagad' | 'Binance' | 'System' | 'Task';
  amount: number;
  currency: CurrencyType;
  status: 'Pending' | 'Completed' | 'Approved' | 'Rejected';
  timestamp: string;
  trxId?: string;
  accountNumber?: string;
  reference?: string;
  isSandboxDemo?: boolean;
  adminNote?: string;
}

export interface Earner {
  rank: number;
  id: string;
  name: string;
  earningsBDT: number;
  avatar: string;
  isCurrentUser?: boolean;
  badge?: 'gold' | 'silver' | 'bronze';
  period?: 'all' | 'weekly' | 'monthly';
}

export interface AdTask {
  id: string;
  title: string;
  type?: 'video_ad' | 'spin_wheel' | 'math_quiz' | 'social_task' | 'daily_checkin';
  sponsor: string;
  durationSec?: number;
  rewardAmount: number;
  currency: CurrencyType;
  category: string;
  linkUrl?: string;
  watched?: boolean;
  completedToday?: boolean;
  cooldownUntil?: number;
  isActive?: boolean;
}

export interface CommunityPost {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  content: string;
  timeAgo: string;
  likes: number;
  isLiked: boolean;
  tag?: string;
  proofAmount?: string;
}

export interface SystemSettings {
  isSandboxDemoMode: boolean;
  sandboxNotice: string;
  nagadAgentNumber: string;
  binancePayId: string;
  minDepositBDT: number;
  maxDepositBDT: number;
  minDepositUSD: number;
  minWithdrawBDT: number;
  maxWithdrawBDT: number;
  minWithdrawUSD: number;
}

// --- PANDA PROMOTION TYPES ---
export interface PromotionPackage {
  id: string;
  name: string;
  durationDays: number;
  priceBDT: number;
  priceUSD: number;
  estimatedReach: string;
  badgeText: string;
  features: string[];
  isActive: boolean;
}

export interface PromotionPost {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  mediaUrl?: string;
  linkType: 'website' | 'facebook' | 'youtube' | 'instagram' | 'telegram' | 'other';
  linkUrl: string;
  linkTitle?: string;
  isPromoted: boolean;
  isPinnedToTop: boolean;
  promotionPackageId?: string;
  packageName?: string;
  promotionStatus: 'none' | 'pending_approval' | 'active' | 'paused' | 'completed' | 'rejected';
  promotionStartDate?: string;
  promotionEndDate?: string;
  promotionDurationDays?: number;
  daysRemaining?: number;
  totalCostBDT?: number;
  totalCostUSD?: number;
  viewsCount: number;
  clicksCount: number;
  likesCount: number;
  likedBy: string[];
  reportsCount: number;
  reports?: { userId: string; reason: string; timestamp: string }[];
  isBlocked: boolean;
  adminNote?: string;
  createdAt: string;
}
